plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.doctruyenver2app"
    compileSdk {
        // Nên là một số nguyên (ví dụ: 34 hoặc 36)
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.example.doctruyenver2app"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        // Nên sử dụng Java 8 hoặc 17 thay vì 11 nếu bạn đang dùng các thư viện Android X mới
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Các dependencies hiện tại của bạn:
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // Các dependencies đã thêm:
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.cardview:cardview:1.0.0")

    // >>> THƯ VIỆN TẢI ẢNH ĐƯỢC CHỌN: GLIDE <<<
    implementation("com.github.bumptech.glide:glide:4.16.0")
    annotationProcessor("com.github.bumptech.glide:compiler:4.16.0")

    // ĐÃ LOẠI BỎ Picasso (không cần thiết)
    // implementation("com.squareup.picasso:picasso:2.71828")

    // Test dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
