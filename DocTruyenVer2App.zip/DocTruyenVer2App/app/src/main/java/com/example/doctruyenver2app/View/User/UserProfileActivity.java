package com.example.doctruyenver2app.View.User;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.doctruyenver2app.Controller.UserController;
import com.example.doctruyenver2app.Model.User;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.Util.PasswordHashUtil;



public class UserProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final String TAG = "UserProfileActivity";

    private ImageView imgAvatar;
    private EditText edtUsername, edtEmail, edtPassword;
    private Button btnSave, btnLogout;
    private ImageButton btnBack;

    private UserController userController;
    private int currentUserId;
    private String selectedAvatarPath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        initViews();
        userController = new UserController(this);

        // Nhận ID người dùng từ Intent hoặc từ Bundle
        if (savedInstanceState != null) {
            currentUserId = savedInstanceState.getInt("USER_ID", -1);
            Log.d(TAG, "User ID restored from savedInstanceState: " + currentUserId);
        } else {
            currentUserId = getIntent().getIntExtra("USER_ID", -1);
            Log.d(TAG, "User ID received from Intent: " + currentUserId);
        }

        if (currentUserId != -1) {
            loadUserData();
        } else {
            Log.e(TAG, "Invalid User ID: " + currentUserId);
            Toast.makeText(this, "Lỗi ID người dùng!", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Gán sự kiện
        imgAvatar.setOnClickListener(v -> openGallery());
        btnSave.setOnClickListener(v -> saveProfile());
        btnBack.setOnClickListener(v -> finish());
        btnLogout.setOnClickListener(v -> showLogoutDialog());
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("USER_ID", currentUserId);
        Log.d(TAG, "User ID saved to Bundle: " + currentUserId);
    }

    private void initViews() {
        imgAvatar = findViewById(R.id.imgAvatarProfile);
        edtUsername = findViewById(R.id.edtUsernameProfile);
        edtEmail = findViewById(R.id.edtEmailProfile);
        edtPassword = findViewById(R.id.edtPasswordProfile);
        btnSave = findViewById(R.id.btnSaveProfile);
        btnBack = findViewById(R.id.btnBackProfile);
        btnLogout = findViewById(R.id.btnLogoutProfile);
    }

    private void loadUserData() {
        Log.d(TAG, "Loading user data for ID: " + currentUserId);

        User user = userController.getUserById(currentUserId);

        if (user != null) {
            Log.d(TAG, "User found - Username: " + user.getUsername() +
                    ", Email: " + user.getEmail());

            edtUsername.setText(user.getUsername());
            edtEmail.setText(user.getEmail());
            selectedAvatarPath = user.getAvatarPath();

            if (selectedAvatarPath != null && !selectedAvatarPath.isEmpty()) {
                try {
                    imgAvatar.setImageURI(Uri.parse(selectedAvatarPath));
                    Log.d(TAG, "Avatar loaded: " + selectedAvatarPath);
                } catch (Exception e) {
                    Log.e(TAG, "Error loading avatar: " + e.getMessage());
                    setDefaultAvatar();
                }
            } else {
                Log.d(TAG, "Avatar path is empty, using default avatar");
                setDefaultAvatar();
            }
        } else {
            Log.e(TAG, "User is null! Could not load data for ID: " + currentUserId);
            Toast.makeText(this, "Không tìm thấy dữ liệu người dùng!", Toast.LENGTH_SHORT).show();
        }
    }

    private void setDefaultAvatar() {
        // Sử dụng ảnh mặc định từ drawable
        imgAvatar.setImageResource(R.drawable.ic_default_avatar);
        Log.d(TAG, "Default avatar set");
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Xác nhận")
                .setMessage("Bạn có chắc chắn muốn đăng xuất?")
                .setPositiveButton("Đăng xuất", (dialog, which) -> performLogout())
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void performLogout() {
        Log.d(TAG, "User logout initiated");
        Intent intent = new Intent(UserProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                selectedAvatarPath = imageUri.toString();
                imgAvatar.setImageURI(imageUri);
                Log.d(TAG, "Avatar selected: " + selectedAvatarPath);
            }
        }
    }

    private void saveProfile() {
        String newUsername = edtUsername.getText().toString().trim();
        String newEmail = edtEmail.getText().toString().trim();
        String newPasswordRaw = edtPassword.getText().toString().trim();

        Log.d(TAG, "Saving profile - Username: " + newUsername + ", Email: " + newEmail);

        if (newUsername.isEmpty() || newEmail.isEmpty()) {
            Toast.makeText(this, "Không được để trống Tên hoặc Email", Toast.LENGTH_SHORT).show();
            return;
        }

        // XỬ LÝ BĂM MẬT KHẨU
        String passwordToUpdate = "";
        if (!newPasswordRaw.isEmpty()) {
            passwordToUpdate = PasswordHashUtil.hashPassword(newPasswordRaw);
            Log.d(TAG, "Password will be updated");
        } else {
            Log.d(TAG, "Password field is empty, keeping old password");
        }

        // Truyền mật khẩu đã băm sang UserController
        boolean isUpdated = userController.updateUserProfile(
                currentUserId,
                newUsername,
                newEmail,
                selectedAvatarPath,
                passwordToUpdate
        );

        if (isUpdated) {
            Log.d(TAG, "Profile updated successfully");
            Toast.makeText(this, "Cập nhật hồ sơ thành công!", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
        } else {
            Log.e(TAG, "Profile update failed - Username or Email already exists");
            Toast.makeText(this, "Lỗi: Tên hoặc Email đã tồn tại!", Toast.LENGTH_SHORT).show();
        }
    }
}