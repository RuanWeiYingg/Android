package com.example.doctruyenver2app.View.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.example.doctruyenver2app.Adapter.Admin.StoryAdapter;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

import java.util.ArrayList;
import java.util.List;


public class ManageStoriesActivity extends AppCompatActivity
        implements StoryAdapter.OnItemActionListener {

    private static final String TAG = "ManageStoriesActivity";

    private RecyclerView rvStoriesList;
    private SearchView svStorySearch;
    private FloatingActionButton fabAddStory;

    private StoryAdapter adapter;
    private List<Story> storyList;
    private StoryController storyController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_stories);

        // 1. Khởi tạo Controller và Data
        storyController = new StoryController(this);
        storyList = new ArrayList<>();

        // 2. Ánh xạ các thành phần UI
        rvStoriesList = findViewById(R.id.rv_stories_list);
        svStorySearch = findViewById(R.id.sv_story_search);
        fabAddStory = findViewById(R.id.fab_add_story);

        // 3. Cấu hình Toolbar (QUAN TRỌNG!)
        Toolbar toolbar = findViewById(R.id.toolbar_stories);
        setSupportActionBar(toolbar);

        // 4. Cấu hình RecyclerView
        adapter = new StoryAdapter(this, storyList, this); // 'this' là context và listener
        rvStoriesList.setLayoutManager(new LinearLayoutManager(this));
        rvStoriesList.setAdapter(adapter);

        // 5. Hiển thị nút back trong ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 5b. Thiết lập OnBackPressedDispatcher (thay thế onBackPressed)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToAdminDashboard();
            }
        });

        // 6. Tải dữ liệu ban đầu
        loadStories(null);

        // 7. Thiết lập Listener cho nút Thêm mới
        fabAddStory.setOnClickListener(v -> {
            // Chuyển đến màn hình AddEditStoryActivity để thêm mới
            startActivity(new Intent(this, AddEditStoryActivity.class));
        });

        // 8. Thiết lập Listener cho ô Tìm kiếm
        setupSearchView();
    }

    /**
     * Tải danh sách truyện (có thể kèm theo từ khóa tìm kiếm)
     */
    private void loadStories(String keyword) {
        List<Story> allStories;
        if (keyword == null || keyword.isEmpty()) {
            allStories = storyController.getAllStories();
            Log.d(TAG, "Loaded all stories. Count: " + allStories.size());
        } else {
            allStories = storyController.searchStories(keyword);
            Log.d(TAG, "Search stories by: " + keyword + ". Count: " + allStories.size());
        }

        storyList.clear();
        storyList.addAll(allStories);
        adapter.notifyDataSetChanged();
    }

    /**
     * Cấu hình chức năng Tìm kiếm (SearchView)
     */
    private void setupSearchView() {
        svStorySearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Xử lý khi nhấn nút tìm kiếm
                loadStories(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Tải lại danh sách khi văn bản thay đổi (tìm kiếm trực tiếp)
                loadStories(newText);
                return false;
            }
        });

        // Xử lý khi đóng SearchView (quay lại hiển thị tất cả)
        svStorySearch.setOnCloseListener(() -> {
            loadStories(null);
            return false;
        });
    }

    // =========================================================
    // =============== Xử lý sự kiện nút Back ==================
    // =========================================================

    /**
     * Xử lý sự kiện nút Back trong ActionBar
     */
    @Override
    public boolean onSupportNavigateUp() {
        navigateToAdminDashboard();
        return true;
    }

    /**
     * Hàm riêng để navigate quay lại AdminDashboardActivity
     */
    private void navigateToAdminDashboard() {
        Intent intent = new Intent(this, AdminDashboardActivity.class);
        startActivity(intent);
        finish();
    }

    // =========================================================
    // =============== Xử lý sự kiện từ StoryAdapter ============
    // =========================================================

    /**
     * PHƯƠNG THỨC BỊ THIẾU: Xử lý sự kiện khi Admin nhấn nút Sửa
     */
    @Override
    public void onEditClick(Story story) {
        // Chuyển sang Activity Sửa truyện, truyền STORY_ID
        Intent intent = new Intent(this, AddEditStoryActivity.class);
        intent.putExtra("STORY_ID", story.getId());
        startActivity(intent);
    }


    @Override
    public void onDeleteClick(Story story) {
        // Hiển thị hộp thoại xác nhận xóa
        new AlertDialog.Builder(this)
                .setTitle("Xác nhận Xóa Truyện")
                .setMessage("Bạn có chắc chắn muốn xóa truyện \"" + story.getTitle() + "\"? Thao tác này sẽ xóa TẤT CẢ chương và dữ liệu liên quan.")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    performDeleteStory(story);
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    @Override
    public void onManageChaptersClick(Story story) {
        // Chuyển sang Activity Quản lý Chương, truyền STORY_ID
        Intent intent = new Intent(this, ManageChaptersActivity.class);
        intent.putExtra("STORY_ID", story.getId());
        startActivity(intent);
    }

    /**
     * Thực hiện thao tác xóa truyện thông qua Controller và cập nhật UI.
     */
    private void performDeleteStory(Story story) {
        boolean isDeleted = storyController.deleteStory(story.getId());
        if (isDeleted) {
            // Xóa thành công, cập nhật giao diện
            storyList.remove(story);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Đã xóa truyện: " + story.getTitle(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Lỗi: Không thể xóa truyện " + story.getTitle(), Toast.LENGTH_SHORT).show();
        }
    }

    // Đảm bảo dữ liệu được cập nhật nếu có thao tác Thêm/Sửa/Xóa từ màn hình khác
    @Override
    protected void onResume() {
        super.onResume();
        // Tải lại danh sách (giữ nguyên kết quả tìm kiếm nếu đang có)
        loadStories(svStorySearch.getQuery().toString());
    }
}