package com.example.doctruyenver2app.Controller;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Admin;
import com.example.doctruyenver2app.Model.ManagedAccount;
import com.example.doctruyenver2app.Model.ManagedAccount.RoleType;
import com.example.doctruyenver2app.Model.User;

import java.text.Normalizer; // <<< IMPORT MỚI
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern; // <<< IMPORT MỚI

import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class AccountManagerController {
    private static final String TAG = "AccountManagerController";
    private final DatabaseHelper dbHelper;
    private final UserController userController;
    private final AdminController adminController;

    public AccountManagerController(Context context) {
        this.dbHelper = new DatabaseHelper(context);
        this.userController = new UserController(context);
        this.adminController = new AdminController(context);
    }

    // =========================================================================
    //                            HÀM TIỆN ÍCH CHUẨN HÓA
    // =========================================================================

    /**
     * Loại bỏ dấu tiếng Việt (chuẩn hóa) để hỗ trợ tìm kiếm linh hoạt (ví dụ: "huyen" -> "Huyền").
     */
    private String removeVietnameseAccents(String s) {
        if (s == null) return null;
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(temp).replaceAll("").toLowerCase();
    }

    // =========================================================================
    //                            PHƯƠNG THỨC CHÍNH
    // =========================================================================


    /**
     * Lấy tất cả tài khoản (Admin + User) với tìm kiếm
     * Kết hợp dữ liệu từ 2 bảng ADMINS và USERS
     */
    public List<ManagedAccount> getAllAccounts(String searchQuery) {
        // ... (Giữ nguyên phần tải dữ liệu)
        List<ManagedAccount> accountList = new ArrayList<>();

        try {
            // Lấy tất cả Users
            List<User> users = userController.getAllUsers();
            for (User user : users) {
                ManagedAccount account = new ManagedAccount(
                        user.getId(),
                        user.getUsername(),
                        user.getEmail(),
                        RoleType.USER
                );
                accountList.add(account);
            }

            // Lấy tất cả Admins
            List<Admin> admins = getAllAdmins();
            for (Admin admin : admins) {
                ManagedAccount account = new ManagedAccount(
                        admin.getId(),
                        admin.getUsername(),
                        admin.getEmail(),
                        RoleType.ADMIN
                );
                accountList.add(account);
            }

            Log.d(TAG, "Total accounts loaded: " + accountList.size());

        } catch (Exception e) {
            Log.e(TAG, "Error loading accounts: " + e.getMessage());
            e.printStackTrace();
        }

        // Filter theo searchQuery nếu có
        if (searchQuery != null && !searchQuery.isEmpty()) {
            return filterAccounts(accountList, searchQuery);
        }

        return accountList;
    }

    /**
     * Tìm kiếm tài khoản theo username, email hoặc role
     * Đã áp dụng chuẩn hóa (removeVietnameseAccents) để tìm kiếm không dấu
     */
    private List<ManagedAccount> filterAccounts(List<ManagedAccount> accounts, String searchQuery) {
        List<ManagedAccount> filtered = new ArrayList<>();

        // Chuẩn hóa chuỗi tìm kiếm của người dùng
        String normalizedQuery = removeVietnameseAccents(searchQuery);

        for (ManagedAccount account : accounts) {
            // Chuẩn hóa dữ liệu của tài khoản
            String normalizedUsername = removeVietnameseAccents(account.getUsername());
            String normalizedEmail = removeVietnameseAccents(account.getEmail());
            String normalizedRole = removeVietnameseAccents(account.getRole().toString());


            if (normalizedUsername.contains(normalizedQuery) ||
                    normalizedEmail.contains(normalizedQuery) ||
                    normalizedRole.contains(normalizedQuery)) {
                filtered.add(account);
            }
        }

        Log.d(TAG, "Filtered accounts: " + filtered.size() + " (query: " + searchQuery + ")");
        return filtered;
    }

    /**
     * Lấy tất cả Admin từ Database (Giữ nguyên)
     */
    public List<Admin> getAllAdmins() {
        List<Admin> admins = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        try {
            Cursor cursor = db.query(
                    TABLE_ADMINS,
                    new String[]{COLUMN_ADMIN_ID, COLUMN_ADMIN_USERNAME, COLUMN_ADMIN_EMAIL, COLUMN_ADMIN_PASSWORD_ID},
                    null, null, null, null, COLUMN_ADMIN_USERNAME + " ASC"
            );

            if (cursor.moveToFirst()) {
                do {
                    try {
                        Admin admin = new Admin(
                                cursor.getInt(0),   // ID
                                cursor.getString(1), // Username
                                cursor.getString(2), // Email
                                cursor.getInt(3)    // Password ID
                        );
                        admins.add(admin);
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing admin: " + e.getMessage());
                    }
                } while (cursor.moveToNext());
            }
            cursor.close();
            Log.d(TAG, "Total Admins: " + admins.size());
        } catch (Exception e) {
            Log.e(TAG, "Error loading admins: " + e.getMessage());
            e.printStackTrace();
        } finally {
            db.close();
        }

        return admins;
    }

    /**
     * Xóa tài khoản (Giữ nguyên)
     */
    public boolean deleteAccount(int accountId, RoleType role) {
        try {
            if (role == RoleType.ADMIN) {
                return adminController.deleteAdmin(accountId);
            } else if (role == RoleType.USER) {
                return userController.deleteUser(accountId);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error deleting account: " + e.getMessage());
        }
        return false;
    }

    /**
     * Cập nhật thông tin tài khoản (Giữ nguyên)
     */
    public boolean updateAccount(int accountId, RoleType role, String newUsername, String newEmail) {
        try {
            if (role == RoleType.ADMIN) {
                return adminController.updateAdminInfo(accountId, newUsername, newEmail);
            } else if (role == RoleType.USER) {
                return userController.updateUserInfo(accountId, newUsername, newEmail);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating account: " + e.getMessage());
        }
        return false;
    }

    /**
     * Đếm tổng số tài khoản (Giữ nguyên)
     */
    public int getTotalAccountCount() {
        return getAllAccounts(null).size();
    }

    /**
     * Đếm số User (Giữ nguyên)
     */
    public int getUserCount() {
        return userController.getAllUsers().size();
    }

    /**
     * Đếm số Admin (Giữ nguyên)
     */
    public int getAdminCount() {
        return getAllAdmins().size();
    }
}