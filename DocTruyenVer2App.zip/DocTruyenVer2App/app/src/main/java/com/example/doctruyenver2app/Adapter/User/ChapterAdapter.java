package com.example.doctruyenver2app.Adapter.User;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.View.ReadChapterActivity;

import java.util.List;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.ChapterViewHolder> {

    private final List<Chapter> chapterList;
    private final Context context;

    public ChapterAdapter(List<Chapter> chapterList, Context context) {
        this.chapterList = chapterList;
        this.context = context;
    }

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chapter, parent, false);
        return new ChapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
        Chapter chapter = chapterList.get(position);

        // Đổ dữ liệu vào các Views
        holder.tvOrder.setText(chapter.getOrderIndex() + ".");
        holder.tvTitle.setText(chapter.getTitle());

        // Xử lý sự kiện khi nhấn vào chương
        holder.itemView.setOnClickListener(v -> {
            // Chuyển sang màn hình đọc chương
            Intent intent = new Intent(context, ReadChapterActivity.class);
            intent.putExtra("STORY_ID", chapter.getStoryId());
            intent.putExtra("CHAPTER_ORDER", chapter.getOrderIndex());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return chapterList.size();
    }

    public static class ChapterViewHolder extends RecyclerView.ViewHolder {
        final TextView tvOrder;
        final TextView tvTitle;
        final ImageView imgStatus;

        public ChapterViewHolder(@NonNull View itemView) {
            super(itemView);

            // Ánh xạ các ID từ item_chapter.xml
            tvOrder = itemView.findViewById(R.id.tv_chapter_order);
            tvTitle = itemView.findViewById(R.id.tv_chapter_list_title);  // Đổi ID để tránh conflict
            imgStatus = itemView.findViewById(R.id.img_download_status);
        }
    }
}