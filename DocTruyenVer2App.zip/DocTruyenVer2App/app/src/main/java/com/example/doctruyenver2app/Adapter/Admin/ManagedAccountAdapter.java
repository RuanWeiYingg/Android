package com.example.doctruyenver2app.Adapter.Admin;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.ManagedAccount;
import com.example.doctruyenver2app.Model.ManagedAccount.RoleType;
import com.example.doctruyenver2app.R;

import java.util.List;

public class ManagedAccountAdapter extends RecyclerView.Adapter<ManagedAccountAdapter.AccountViewHolder> {

    private static final String TAG = "ManagedAccountAdapter";
    private final Context context;
    private final List<ManagedAccount> accountList;
    private final OnAccountActionListener listener;

    /**
     * Interface để gửi sự kiện trở lại Activity (ManageUsersActivity)
     */
    public interface OnAccountActionListener {
        void onEdit(ManagedAccount account);
        void onDelete(ManagedAccount account);
    }

    public ManagedAccountAdapter(Context context, List<ManagedAccount> accountList, OnAccountActionListener listener) {
        this.context = context;
        this.accountList = accountList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public AccountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user_admin, parent, false);
        return new AccountViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AccountViewHolder holder, int position) {
        final ManagedAccount account = accountList.get(position);

        // 1. Hiển thị thông tin cơ bản
        holder.tvUsername.setText(account.getUsername());
        holder.tvEmail.setText(account.getEmail());

        // 2. HIỂN THỊ PHÂN QUYỀN VÀ XỬ LÝ NÚT
        if (account.getRole() == RoleType.ADMIN) {
            holder.tvRole.setText("QUYỀN: QUẢN TRỊ VIÊN");
            holder.tvRole.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_dark));

            // Hiện nút Edit/Delete cho Admin (Admin có thể sửa Admin khác)
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.btnEdit.setVisibility(View.VISIBLE);
        } else {
            holder.tvRole.setText("QUYỀN: Người Dùng");
            holder.tvRole.setTextColor(ContextCompat.getColor(context, android.R.color.holo_blue_light));

            // Hiện nút chức năng cho User thường
            holder.btnDelete.setVisibility(View.VISIBLE);
            holder.btnEdit.setVisibility(View.VISIBLE);
        }

        // 3. Xử lý sự kiện Sửa (Edit)
        holder.btnEdit.setOnClickListener(v -> {
            if (listener != null) {
                listener.onEdit(account);
            }
        });

        // 4. Xử lý sự kiện Xóa (Delete)
        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDelete(account);
            }
        });

        Log.d(TAG, "Bound account: " + account.getUsername() + " (" + account.getRole() + ")");
    }

    @Override
    public int getItemCount() {
        return accountList.size();
    }

    /**
     * ⭐ PHƯƠNG THỨC QUAN TRỌNG: Cập nhật danh sách tài khoản
     * Gọi từ ManageUsersActivity khi dữ liệu thay đổi
     */
    public void updateAccountList(List<ManagedAccount> newList) {
        this.accountList.clear();
        this.accountList.addAll(newList);
        notifyDataSetChanged();
        Log.d(TAG, "updateAccountList called, total items: " + accountList.size());
    }

    /**
     * Xóa một tài khoản khỏi list
     */
    public void removeAccount(ManagedAccount account) {
        int index = accountList.indexOf(account);
        if (index >= 0) {
            accountList.remove(index);
            notifyItemRemoved(index);
            Log.d(TAG, "Removed account at index: " + index);
        }
    }

    /**
     * Lớp ViewHolder
     */
    public static class AccountViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername;
        TextView tvEmail;
        TextView tvRole;
        ImageButton btnEdit;
        ImageButton btnDelete;

        public AccountViewHolder(@NonNull View itemView) {
            super(itemView);

            // Ánh xạ ID từ XML
            tvUsername = itemView.findViewById(R.id.tv_username);
            tvEmail = itemView.findViewById(R.id.tv_email);
            tvRole = itemView.findViewById(R.id.tv_role);
            btnEdit = itemView.findViewById(R.id.btn_edit_user);
            btnDelete = itemView.findViewById(R.id.btn_delete_user);
        }
    }
}