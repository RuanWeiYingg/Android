package com.example.doctruyenver2app.Util;

import android.content.Context;
import android.util.AttributeSet;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Custom GridLayoutManager để RecyclerView tự động tính chiều cao
 * phù hợp với số lượng items
 */
public class WrappingGridLayoutManager extends GridLayoutManager {

    private int[] mMeasuredDimension = new int[2];

    public WrappingGridLayoutManager(Context context, int spanCount) {
        super(context, spanCount);
    }

    public WrappingGridLayoutManager(Context context, int spanCount, int orientation, boolean reverseLayout) {
        super(context, spanCount, orientation, reverseLayout);
    }

    public WrappingGridLayoutManager(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    public void onMeasure(RecyclerView.Recycler recycler, RecyclerView.State state, int widthSpec, int heightSpec) {
        int widthMode = android.view.View.MeasureSpec.getMode(widthSpec);
        int heightMode = android.view.View.MeasureSpec.getMode(heightSpec);
        int widthSize = android.view.View.MeasureSpec.getSize(widthSpec);
        int heightSize = android.view.View.MeasureSpec.getSize(heightSpec);

        int width = 0;
        int height = 0;
        int childWidth = 0;
        int childHeight = 0;

        int itemCount = state.getItemCount();
        int spanCount = getSpanCount();

        // Tính toán số hàng cần thiết
        int rows = (itemCount + spanCount - 1) / spanCount;

        for (int i = 0; i < itemCount; i++) {
            try {
                measureScrapChild(recycler, i,
                        android.view.View.MeasureSpec.makeMeasureSpec(i, android.view.View.MeasureSpec.UNSPECIFIED),
                        android.view.View.MeasureSpec.makeMeasureSpec(i, android.view.View.MeasureSpec.UNSPECIFIED),
                        mMeasuredDimension);

                if (i % spanCount == 0) {
                    width = mMeasuredDimension[0];
                    childHeight = mMeasuredDimension[1];
                }

                if (i == 0) {
                    childWidth = mMeasuredDimension[0];
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // ✅ FIX: Tính toán chiều cao dựa trên số hàng
        height = childHeight * rows + (rows - 1) * 12; // 12dp = padding giữa các item

        switch (widthMode) {
            case android.view.View.MeasureSpec.AT_MOST:
            case android.view.View.MeasureSpec.EXACTLY:
                width = widthSize;
                break;
            case android.view.View.MeasureSpec.UNSPECIFIED:
                break;
        }

        switch (heightMode) {
            case android.view.View.MeasureSpec.AT_MOST:
            case android.view.View.MeasureSpec.EXACTLY:
                height = Math.min(height, heightSize);
                break;
            case android.view.View.MeasureSpec.UNSPECIFIED:
                break;
        }

        setMeasuredDimension(width, height);
    }

    private void measureScrapChild(RecyclerView.Recycler recycler, int position, int widthSpec,
                                   int heightSpec, int[] measuredDimension) {
        try {
            android.view.View view = recycler.getViewForPosition(position);

            if (view != null) {
                RecyclerView.LayoutParams p = (RecyclerView.LayoutParams) view.getLayoutParams();

                int widthSize = android.view.View.MeasureSpec.getSize(widthSpec);
                int wSpec = android.view.View.MeasureSpec.makeMeasureSpec(
                        widthSize / getSpanCount(),
                        android.view.View.MeasureSpec.EXACTLY);
                int hSpec = android.view.View.MeasureSpec.makeMeasureSpec(500, android.view.View.MeasureSpec.AT_MOST);

                view.measure(wSpec, hSpec);

                measuredDimension[0] = view.getMeasuredWidth() + p.leftMargin + p.rightMargin;
                measuredDimension[1] = view.getMeasuredHeight() + p.topMargin + p.bottomMargin;

                recycler.recycleView(view);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}