package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Report;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReportController {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public ReportController(Context context) {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getReadableDatabase();
    }

    // Lấy tất cả báo cáo
    public List<Report> getAllReports() {
        List<Report> reports = new ArrayList<>();
        String query = "SELECT r.*, u.username, c.content FROM reports r " +
                "LEFT JOIN users u ON r.reporter_user_id = u.id " +
                "LEFT JOIN comments c ON r.reported_comment_id = c.id " +
                "ORDER BY r.created_at DESC";

        try {
            Cursor cursor = db.rawQuery(query, null);
            if (cursor.moveToFirst()) {
                do {
                    Report report = new Report();
                    report.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                    report.setReporterUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
                    report.setReason(cursor.getString(cursor.getColumnIndexOrThrow("reason")));
                    report.setCommentContent(cursor.getString(cursor.getColumnIndexOrThrow("content")));
                    report.setCreatedAt(cursor.getString(cursor.getColumnIndexOrThrow("created_at")));
                    report.setReportedCommentId(cursor.getInt(cursor.getColumnIndexOrThrow("reported_comment_id")));
                    reports.add(report);
                } while (cursor.moveToNext());
            }
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reports;
    }

    // Xóa báo cáo (chỉ xóa báo cáo, không xóa comment)
    public boolean deleteReport(int reportId) {
        try {
            db = dbHelper.getWritableDatabase();
            return db.delete("reports", "id = ?", new String[]{String.valueOf(reportId)}) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Tạo báo cáo mới
    public boolean createReport(int reporterUserId, int reportedCommentId, String reason) {
        try {
            db = dbHelper.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("reporter_user_id", reporterUserId);
            cv.put("reported_comment_id", reportedCommentId);
            cv.put("reason", reason);
            cv.put("created_at", getDateTime());
            return db.insert("reports", null, cv) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(new Date());
    }
}