package com.example.doctruyenver2app.View.User;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.view.View;

import com.example.doctruyenver2app.Controller.UserController;
import com.example.doctruyenver2app.Controller.AdminController;
import com.example.doctruyenver2app.Model.User;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.View.HomeActivity;
import com.example.doctruyenver2app.View.Admin.AdminDashboardActivity;
import com.example.doctruyenver2app.Util.PasswordHashUtil;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private EditText etUsernameEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvRegisterLink;

    private UserController userController;
    private AdminController adminController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userController = new UserController(this);
        adminController = new AdminController(this);

        etUsernameEmail = findViewById(R.id.et_username_email);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvRegisterLink = findViewById(R.id.tv_register_link);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleLogin();
            }
        });

        tvRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    private void handleLogin() {
        String usernameOrEmail = etUsernameEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (usernameOrEmail.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ Tên đăng nhập/Email và Mật khẩu.", Toast.LENGTH_SHORT).show();
            return;
        }

        String enteredPasswordHash = PasswordHashUtil.hashPassword(password);

        if (enteredPasswordHash == null || enteredPasswordHash.equals(password)) {
            Log.e(TAG, "Lỗi khi tạo hash. Đang sử dụng fallback.");
            Toast.makeText(this, "Lỗi hệ thống: Không thể mã hóa mật khẩu.", Toast.LENGTH_LONG).show();
            return;
        }

        Log.d(TAG, "Hash đầu vào (SHA-256): " + enteredPasswordHash);

        // BƯỚC 1: Thử Đăng nhập Admin
        AdminController.AdminLoginResult adminResult = adminController.login(usernameOrEmail, enteredPasswordHash);

        if (adminResult == AdminController.AdminLoginResult.SUCCESS) {
            handleSuccessfulLogin(true, -1); // Admin không cần USER_ID
            return;
        }

        // BƯỚC 2: Nếu không phải Admin, thử Đăng nhập User
        UserController.LoginResult userResult = userController.login(usernameOrEmail, enteredPasswordHash);

        if (userResult == UserController.LoginResult.SUCCESS) {
            // ✅ LẤY USER_ID từ database
            User user = userController.getUserByUsernameOrEmail(usernameOrEmail);
            if (user != null) {
                Log.d(TAG, "User found: " + user.getUsername() + " with ID: " + user.getId());
                handleSuccessfulLogin(false, user.getId()); // Truyền USER_ID
                return;
            }
        }

        // BƯỚC 3: Xử lý các lỗi
        if (adminResult == AdminController.AdminLoginResult.INVALID_CREDENTIALS ||
                userResult == UserController.LoginResult.INVALID_CREDENTIALS) {
            Toast.makeText(this, "Mật khẩu không đúng. Vui lòng thử lại.", Toast.LENGTH_LONG).show();
        } else if (adminResult == AdminController.AdminLoginResult.ADMIN_NOT_FOUND &&
                userResult == UserController.LoginResult.USER_NOT_FOUND) {
            Toast.makeText(this, "Tài khoản không tồn tại.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Đã xảy ra lỗi hệ thống trong quá trình đăng nhập.", Toast.LENGTH_LONG).show();
        }
    }

    private void handleSuccessfulLogin(boolean isAdmin, int userId) {
        Toast.makeText(this, "Đăng nhập thành công! 👋", Toast.LENGTH_SHORT).show();
        Intent intent;

        if (isAdmin) {
            Log.d(TAG, "Đăng nhập thành công với tài khoản Admin. Chuyển hướng tới Admin Dashboard.");
            intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
        } else {
            Log.d(TAG, "Đăng nhập thành công với tài khoản User (ID: " + userId + "). Chuyển hướng tới Home Activity.");
            intent = new Intent(LoginActivity.this, HomeActivity.class);
            // ✅ GỬI USER_ID sang HomeActivity
            intent.putExtra("USER_ID", userId);
            Log.d(TAG, "Sending USER_ID: " + userId + " to HomeActivity");
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}