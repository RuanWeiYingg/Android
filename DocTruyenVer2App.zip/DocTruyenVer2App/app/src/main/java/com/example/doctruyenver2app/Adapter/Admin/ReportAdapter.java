package com.example.doctruyenver2app.Adapter.Admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.Report;
import com.example.doctruyenver2app.R; // Đảm bảo import R

import java.util.List;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {

    private final Context context;
    private final List<Report> reportList;
    private final OnReportActionListener listener;

    /**
     * Interface để xử lý hành động Sửa/Xóa từ RecyclerView item
     */
    public interface OnReportActionListener {
        void onResolveReport(Report report); // Xử lý báo cáo (ví dụ: Xóa bình luận bị báo cáo)
        void onIgnoreReport(Report report);  // Bỏ qua báo cáo (Xóa báo cáo khỏi danh sách)
    }

    public ReportAdapter(Context context, List<Report> reportList, OnReportActionListener listener) {
        this.context = context;
        this.reportList = reportList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 🚀 Inflate layout item_report_admin.xml
        View view = LayoutInflater.from(context).inflate(R.layout.item_report_admin, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        final Report report = reportList.get(position);

        holder.tvReportId.setText("Báo cáo #" + report.getId());
        holder.tvReporterUser.setText("Người báo cáo: " + report.getReporterUsername());
        holder.tvReportReason.setText("Lý do: " + report.getReason());

        // Gán trực tiếp nội dung vào vùng xám
        holder.tvCommentContent.setText(report.getCommentContent());
        holder.tvReportDate.setText(report.getCreatedAt());

        holder.btnResolveReport.setOnClickListener(v -> {
            if (listener != null) listener.onResolveReport(report);
        });

        holder.btnIgnoreReport.setOnClickListener(v -> {
            if (listener != null) listener.onIgnoreReport(report);
        });
    }

    @Override
    public int getItemCount() {
        return reportList.size();
    }

    /**
     * Lớp ViewHolder để chứa các thành phần UI
     */
    public static class ReportViewHolder extends RecyclerView.ViewHolder {
        // Khai báo TextViews và Buttons
        TextView tvReportId;
        TextView tvReporterUser;
        TextView tvReportReason;
        TextView tvCommentContent;
        TextView tvReportDate;
        Button btnResolveReport;
        Button btnIgnoreReport;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);

            // 🚀 Ánh xạ Views
            tvReportId = itemView.findViewById(R.id.tv_report_id);
            tvReporterUser = itemView.findViewById(R.id.tv_reporter_user);
            tvReportReason = itemView.findViewById(R.id.tv_report_reason);
            tvCommentContent = itemView.findViewById(R.id.tv_comment_content);
            tvReportDate = itemView.findViewById(R.id.tv_report_date);

            btnResolveReport = itemView.findViewById(R.id.btn_resolve_report);
            btnIgnoreReport = itemView.findViewById(R.id.btn_ignore_report);
        }
    }
}