package com.example.doctruyenver2app.View;

import android.view.View;
import android.view.ViewGroup;
import androidx.viewpager2.widget.ViewPager2;
public class ViewPagerHeightWrapper {

    public static void setupViewPagerHeight(ViewPager2 viewPager) {
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                adjustViewPagerHeight(viewPager, position);
            }

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                adjustViewPagerHeight(viewPager, position);
            }
        });
    }

    /**
     * Điều chỉnh chiều cao của ViewPager2 dựa trên fragment hiện tại
     * @param viewPager ViewPager2
     * @param position Vị trí tab hiện tại
     */
    private static void adjustViewPagerHeight(ViewPager2 viewPager, int position) {
        viewPager.post(() -> {
            try {
                // Lấy child view tại vị trí hiện tại (RecyclerView)
                ViewGroup pagerContainer = (ViewGroup) viewPager.getChildAt(0);

                if (pagerContainer != null && pagerContainer.getChildCount() > position) {
                    View child = pagerContainer.getChildAt(position);

                    if (child != null) {
                        // Measure child để lấy chiều cao thực tế
                        child.measure(
                                View.MeasureSpec.makeMeasureSpec(viewPager.getWidth(), View.MeasureSpec.EXACTLY),
                                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                        );

                        int height = child.getMeasuredHeight();

                        // Cập nhật LayoutParams của ViewPager
                        ViewGroup.LayoutParams params = viewPager.getLayoutParams();
                        if (params != null) {
                            params.height = height;
                            viewPager.setLayoutParams(params);
                            viewPager.requestLayout();
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    public static void configureRecyclerViewForViewPager(androidx.recyclerview.widget.RecyclerView recyclerView) {
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(false);
    }
}