package com.example.doctruyenver2app.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import com.example.doctruyenver2app.Adapter.User.StoryDetailPagerAdapter;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

public class StoryDetailActivity extends AppCompatActivity {

    private static final String TAG = "StoryDetailActivity";

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;

    private ImageView imgStoryPoster;
    private TextView tvStoryTitle, tvAuthor, tvRating, tvViewCount;
    private Button btnReadStory;

    private int storyId = -1;
    private String storyTitle = "Chi Tiết Truyện";
    private Story story;

    private int currentUserId = -1;
    private String currentUserName = "";

    private StoryController storyController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_detail);

        storyController = new StoryController(this);
        getUserInfo();

        if (getIntent().getExtras() != null) {
            storyId = getIntent().getIntExtra("STORY_ID", -1);
        }

        if (storyId == -1) {
            Toast.makeText(this, "Lỗi: Không tìm thấy ID truyện.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        initializeViews();
        setupToolbar();
        loadStoryDetails();
        setupViewPager();

        if (btnReadStory != null) {
            btnReadStory.setOnClickListener(v -> startReading());
        }
    }

    private void getUserInfo() {
        currentUserId = 1;
        currentUserName = "Người dùng";
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar_detail);
        tabLayout = findViewById(R.id.tab_layout_detail);
        viewPager = findViewById(R.id.view_pager_detail);
        imgStoryPoster = findViewById(R.id.img_story_poster);
        tvStoryTitle = findViewById(R.id.tv_story_title);
        tvAuthor = findViewById(R.id.tv_author);
        tvRating = findViewById(R.id.tv_rating);
        tvViewCount = findViewById(R.id.tv_view_count);
        btnReadStory = findViewById(R.id.btn_read_story);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void loadStoryDetails() {
        story = storyController.getStoryById(storyId);
        if (story != null) {
            if (story.getCoverUrl() != null && !story.getCoverUrl().isEmpty()) {
                Glide.with(this)
                        .load(story.getCoverUrl())
                        .placeholder(R.drawable.ic_placeholder)
                        .centerCrop()
                        .into(imgStoryPoster);
            }
            tvStoryTitle.setText(story.getTitle());
            tvAuthor.setText("Tác giả: " + story.getAuthor());
            tvRating.setText("⭐ 4.8/5.0");
            tvViewCount.setText("📖 " + story.getChapterCount() + " chương");
            storyTitle = story.getTitle();
            toolbar.setTitle(storyTitle);
        }
    }

    private void setupViewPager() {
        StoryDetailPagerAdapter pagerAdapter = new StoryDetailPagerAdapter(
                this, storyId, currentUserId, currentUserName
        );
        viewPager.setAdapter(pagerAdapter);

        // TỐI ƯU: Sử dụng ViewPagerHeightWrapper để tự động điều chỉnh chiều cao
        ViewPagerHeightWrapper.setupViewPagerHeight(viewPager);

        String[] tabTitles = new String[]{"THÔNG TIN", "CHƯƠNG", "BÌNH LUẬN"};
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(tabTitles[position])
        ).attach();
    }

    private void startReading() {
        Intent intent = new Intent(this, ReadChapterActivity.class);
        intent.putExtra("STORY_ID", storyId);
        intent.putExtra("CHAPTER_ORDER", 1);
        intent.putExtra("USER_ID", currentUserId);
        intent.putExtra("USER_NAME", currentUserName);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}