package com.example.doctruyenver2app.View.Admin;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.doctruyenver2app.Controller.AdminController;
import com.example.doctruyenver2app.Model.Admin;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.Util.PasswordHashUtil; // <-- ĐÃ THÊM IMPORT


public class AddEditAdminActivity extends AppCompatActivity {

    private static final String TAG = "AddEditAdminActivity";

    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private TextView tvPasswordLabel;
    private TextView tvConfirmPasswordLabel;
    private CheckBox cbChangePassword;
    private Button btnSaveAdmin;
    private Button btnCancel;
    private Toolbar toolbar;

    private AdminController adminController;
    private int adminId = -1; // -1 nếu thêm mới, > 0 nếu sửa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_admin);

        adminController = new AdminController(this);

        // 1. Ánh xạ Views
        toolbar = findViewById(R.id.toolbar_add_edit_admin);
        etUsername = findViewById(R.id.et_admin_username);
        etEmail = findViewById(R.id.et_admin_email);
        etPassword = findViewById(R.id.et_admin_password);
        etConfirmPassword = findViewById(R.id.et_admin_confirm_password);
        tvPasswordLabel = findViewById(R.id.tv_admin_password_label);
        tvConfirmPasswordLabel = findViewById(R.id.tv_admin_confirm_password_label);
        cbChangePassword = findViewById(R.id.cb_admin_change_password);
        btnSaveAdmin = findViewById(R.id.btn_save_admin);
        btnCancel = findViewById(R.id.btn_cancel_admin);

        // Setup Toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // BẮT SỰ KIỆN NÚT QUAY LẠI TRÊN TOOLBAR (ĐÃ CÓ TRONG CODE CỦA BẠN)
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        // 2. Kiểm tra nếu là chế độ Sửa (Edit Mode)
        if (getIntent().hasExtra("ADMIN_ID")) {
            adminId = getIntent().getIntExtra("ADMIN_ID", -1);
            loadAdminData(adminId);
            toolbar.setTitle("Sửa Admin");

            // Ẩn password field nhưng hiện checkbox để sửa mật khẩu
            tvPasswordLabel.setVisibility(android.view.View.GONE);
            etPassword.setVisibility(android.view.View.GONE);
            tvConfirmPasswordLabel.setVisibility(android.view.View.GONE);
            etConfirmPassword.setVisibility(android.view.View.GONE);
            cbChangePassword.setVisibility(android.view.View.VISIBLE);

            // Khi checkbox được chọn, hiển thị password fields
            cbChangePassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    tvPasswordLabel.setVisibility(android.view.View.VISIBLE);
                    etPassword.setVisibility(android.view.View.VISIBLE);
                    tvConfirmPasswordLabel.setVisibility(android.view.View.VISIBLE);
                    etConfirmPassword.setVisibility(android.view.View.VISIBLE);
                } else {
                    tvPasswordLabel.setVisibility(android.view.View.GONE);
                    etPassword.setVisibility(android.view.View.GONE);
                    tvConfirmPasswordLabel.setVisibility(android.view.View.GONE);
                    etConfirmPassword.setVisibility(android.view.View.GONE);
                    etPassword.setText("");
                    etConfirmPassword.setText("");
                }
            });
        } else {
            toolbar.setTitle("Thêm Admin Mới");

            // Hiện password fields khi thêm mới
            tvPasswordLabel.setVisibility(android.view.View.VISIBLE);
            etPassword.setVisibility(android.view.View.VISIBLE);
            tvConfirmPasswordLabel.setVisibility(android.view.View.VISIBLE);
            etConfirmPassword.setVisibility(android.view.View.VISIBLE);
            cbChangePassword.setVisibility(android.view.View.GONE);
        }

        // 3. Thiết lập Listener
        btnSaveAdmin.setOnClickListener(v -> saveAdmin());
        btnCancel.setOnClickListener(v -> onBackPressed());
    }

    /**
     * Tải dữ liệu Admin nếu đang ở chế độ sửa.
     */
    private void loadAdminData(int id) {
        Admin admin = adminController.getAdminById(id);
        if (admin != null) {
            etUsername.setText(admin.getUsername());
            etEmail.setText(admin.getEmail());
        } else {
            Toast.makeText(this, "Không tìm thấy admin để sửa.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Xử lý lưu (Thêm mới hoặc Cập nhật) Admin.
     */
    private void saveAdmin() {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        // Kiểm tra validation cơ bản
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(this, "Vui lòng nhập tên đăng nhập.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Vui lòng nhập email.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Kiểm tra định dạng email
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Email không hợp lệ.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (adminId == -1) {
            // ========== CHẾ độ THÊM MỚI - Cần password ==========
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();

            if (TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Vui lòng nhập mật khẩu.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6) {
                Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Mật khẩu xác nhận không khớp.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Hash mật khẩu - SỬ DỤNG HÀM CHUNG
            String passwordHash = PasswordHashUtil.hashPassword(password); // <-- ĐÃ SỬA

            // Thêm mới Admin
            Admin newAdmin = new Admin(username, email);
            AdminController.AdminAddResult result = adminController.addAdmin(newAdmin, passwordHash);

            switch (result) {
                case SUCCESS:
                    Toast.makeText(this, "Thêm admin thành công!", Toast.LENGTH_SHORT).show();
                    finish();
                    break;
                case USERNAME_ALREADY_EXISTS:
                    Toast.makeText(this, "Tên đăng nhập đã tồn tại.", Toast.LENGTH_SHORT).show();
                    break;
                case EMAIL_ALREADY_EXISTS:
                    Toast.makeText(this, "Email đã tồn tại.", Toast.LENGTH_SHORT).show();
                    break;
                case ERROR:
                    Toast.makeText(this, "Lỗi khi thêm admin.", Toast.LENGTH_SHORT).show();
                    break;
            }
        } else {
            // ========== CHẾ độ CẬP NHẬT (Sửa) ==========
            boolean success = adminController.updateAdminInfo(adminId, username, email);

            if (!success) {
                Toast.makeText(this, "Lỗi khi cập nhật thông tin.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Nếu người dùng chọn sửa mật khẩu
            if (cbChangePassword.isChecked()) {
                String password = etPassword.getText().toString().trim();
                String confirmPassword = etConfirmPassword.getText().toString().trim();

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "Vui lòng nhập mật khẩu mới.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(this, "Mật khẩu xác nhận không khớp.", Toast.LENGTH_SHORT).show();
                    return;
                }

                String passwordHash = PasswordHashUtil.hashPassword(password); // <-- ĐÃ SỬA
                success = adminController.updateAdminPassword(adminId, passwordHash);

                if (!success) {
                    Toast.makeText(this, "Lỗi khi cập nhật mật khẩu.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            Toast.makeText(this, "Cập nhật admin thành công!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }


}