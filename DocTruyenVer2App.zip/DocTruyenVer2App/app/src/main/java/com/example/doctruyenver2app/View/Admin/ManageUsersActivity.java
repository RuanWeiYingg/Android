package com.example.doctruyenver2app.View.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar; // ⭐ Import cần thiết
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Adapter.Admin.ManagedAccountAdapter;
import com.example.doctruyenver2app.Controller.AccountManagerController;
import com.example.doctruyenver2app.Model.ManagedAccount;
import com.example.doctruyenver2app.Model.ManagedAccount.RoleType;
import com.example.doctruyenver2app.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity quản lý danh sách tài khoản (Admin & User) dành cho Admin.
 * Hiển thị danh sách, tìm kiếm, sửa, xóa tài khoản.
 * Triển khai ManagedAccountAdapter.OnAccountActionListener để xử lý sự kiện click trên từng item.
 */
public class ManageUsersActivity extends AppCompatActivity
        implements ManagedAccountAdapter.OnAccountActionListener {

    private static final String TAG = "ManageUsersActivity";

    private RecyclerView rvUsersList;
    private SearchView svUserSearch;
    private FloatingActionButton fabAddUser;
    private FloatingActionButton fabAddAdmin;

    private ManagedAccountAdapter adapter;
    private List<ManagedAccount> accountList;
    private AccountManagerController accountController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_users);

        // 1. Khởi tạo Controller và Data
        accountController = new AccountManagerController(this);
        accountList = new ArrayList<>();

        // 2. Ánh xạ các thành phần UI
        rvUsersList = findViewById(R.id.rv_users_list);
        svUserSearch = findViewById(R.id.sv_user_search);
        fabAddUser = findViewById(R.id.fab_add_user);
        fabAddAdmin = findViewById(R.id.fab_add_admin);

        // ⭐ BƯỚC THÊM MỚI: Cấu hình Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar_users);
        setSupportActionBar(toolbar);

        // 3. Cấu hình RecyclerView
        adapter = new ManagedAccountAdapter(this, accountList, this);
        rvUsersList.setLayoutManager(new LinearLayoutManager(this));
        rvUsersList.setAdapter(adapter);

        // 4a. Hiển thị nút back trong ActionBar (Giờ đã hoạt động vì setSupportActionBar đã được gọi)
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 4b. Thiết lập OnBackPressedDispatcher (thay thế onBackPressed)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToAdminDashboard();
            }
        });

        // 5. Tải dữ liệu ban đầu
        loadAccounts(null);

        // 6. Thiết lập Listener cho nút Thêm User
        fabAddUser.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUsersActivity.this, AddEditUserActivity.class);
            intent.putExtra("ACCOUNT_TYPE", "USER");
            startActivity(intent);
        });

        // 6b. Thiết lập Listener cho nút Thêm Admin
        fabAddAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUsersActivity.this, AddEditAdminActivity.class);
            startActivity(intent);
        });

        // 7. Thiết lập Listener cho ô Tìm kiếm
        setupSearchView();
    }

    /**
     * Tải danh sách tài khoản (có thể kèm theo từ khóa tìm kiếm)
     */
    private void loadAccounts(String searchQuery) {
        List<ManagedAccount> allAccounts;
        if (searchQuery == null || searchQuery.isEmpty()) {
            allAccounts = accountController.getAllAccounts("");
            Log.d(TAG, "Loaded all accounts. Count: " + allAccounts.size());
        } else {
            allAccounts = accountController.getAllAccounts(searchQuery);
            Log.d(TAG, "Search accounts by: " + searchQuery + ". Count: " + allAccounts.size());
        }

        // ⭐ QUAN TRỌNG: Sử dụng updateAccountList() để cập nhật UI
        adapter.updateAccountList(allAccounts);
    }

    /**
     * Cấu hình chức năng Tìm kiếm (SearchView)
     */
    private void setupSearchView() {
        svUserSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Xử lý khi nhấn nút tìm kiếm
                loadAccounts(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Tải lại danh sách khi văn bản thay đổi (tìm kiếm trực tiếp)
                loadAccounts(newText);
                return false;
            }
        });

        // Xử lý khi đóng SearchView (quay lại hiển thị tất cả)
        svUserSearch.setOnCloseListener(() -> {
            loadAccounts(null);
            return false;
        });
    }

    // =========================================================
    // =============== Xử lý sự kiện nút Back ==================
    // =========================================================

    /**
     * Xử lý sự kiện nút Back trong ActionBar
     */
    @Override
    public boolean onSupportNavigateUp() {
        navigateToAdminDashboard();
        return true;
    }

    /**
     * Hàm riêng để navigate quay lại AdminDashboardActivity
     */
    private void navigateToAdminDashboard() {
        Intent intent = new Intent(this, AdminDashboardActivity.class);
        startActivity(intent);
        finish();
    }

    // =========================================================
    // =============== Xử lý sự kiện từ ManagedAccountAdapter ===
    // =========================================================

    /**
     * PHƯƠNG THỨC: Xử lý sự kiện khi Admin nhấn nút Sửa
     */
    @Override
    public void onEdit(ManagedAccount account) {
        // Chuyển sang Activity Sửa tài khoản dựa trên role
        if (account.getRole() == RoleType.ADMIN) {
            // Sửa Admin
            Intent intent = new Intent(ManageUsersActivity.this, AddEditAdminActivity.class);
            intent.putExtra("ADMIN_ID", account.getId());
            startActivity(intent);
        } else {
            // Sửa User
            Intent intent = new Intent(ManageUsersActivity.this, AddEditUserActivity.class);
            intent.putExtra("ACCOUNT_ID", account.getId());
            intent.putExtra("ACCOUNT_TYPE", "USER");
            startActivity(intent);
        }
    }

    /**
     * PHƯƠNG THỨC: Xử lý sự kiện khi Admin nhấn nút Xóa
     */
    @Override
    public void onDelete(ManagedAccount account) {
        // Hiển thị hộp thoại xác nhận xóa
        String accountType = account.getRole() == RoleType.ADMIN ? "Admin" : "Người dùng";

        new AlertDialog.Builder(this)
                .setTitle("Xác nhận Xóa " + accountType)
                .setMessage("Bạn có chắc chắn muốn xóa " + accountType + " \"" + account.getUsername() + "\"? " +
                        "Thao tác này sẽ xóa TẤT CẢ dữ liệu liên quan.")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    performDeleteAccount(account);
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    /**
     * Thực hiện thao tác xóa tài khoản thông qua Controller và cập nhật UI.
     */
    private void performDeleteAccount(ManagedAccount account) {
        boolean isDeleted = accountController.deleteAccount(account.getId(), account.getRole());
        if (isDeleted) {
            // Xóa thành công, cập nhật giao diện
            adapter.removeAccount(account);
            Toast.makeText(this, "Đã xóa tài khoản: " + account.getUsername(), Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Account deleted: " + account.getUsername());
        } else {
            Toast.makeText(this, "Lỗi: Không thể xóa tài khoản " + account.getUsername(), Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to delete account: " + account.getUsername());
        }
    }

    /**
     * Đảm bảo dữ liệu được cập nhật nếu có thao tác Thêm/Sửa/Xóa từ màn hình khác
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called");
        // Tải lại danh sách tài khoản (giữ nguyên kết quả tìm kiếm nếu đang có)
        String searchQuery = svUserSearch.getQuery() != null ?
                svUserSearch.getQuery().toString() : "";
        loadAccounts(searchQuery);
    }
}