package com.example.doctruyenver2app.View.Admin;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View; // Import cần thiết cho View.GONE/VISIBLE và setOnClickListener
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.doctruyenver2app.Controller.AdminController;
import com.example.doctruyenver2app.Controller.UserController;
import com.example.doctruyenver2app.Model.Admin;
import com.example.doctruyenver2app.Model.User;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.Util.PasswordHashUtil; // <-- ĐÃ SỬ DỤNG IMPORT NÀY

public class AddEditUserActivity extends AppCompatActivity {

    private static final String TAG = "AddEditUserActivity";

    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private TextView tvPasswordLabel;
    private TextView tvConfirmPasswordLabel;
    private CheckBox cbChangePassword;
    private Button btnSaveUser;
    private Button btnCancel;
    private Toolbar toolbar;

    private UserController userController;
    private AdminController adminController;
    private int userId = -1; // -1 nếu thêm mới, > 0 nếu sửa
    private String accountType = "USER"; // USER hoặc ADMIN

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_user);

        userController = new UserController(this);
        adminController = new AdminController(this);

        // 1. Ánh xạ Views
        toolbar = findViewById(R.id.toolbar_add_edit_user);
        etUsername = findViewById(R.id.et_username);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        tvPasswordLabel = findViewById(R.id.tv_password_label);
        tvConfirmPasswordLabel = findViewById(R.id.tv_confirm_password_label);
        cbChangePassword = findViewById(R.id.cb_change_password);
        btnSaveUser = findViewById(R.id.btn_save_user);
        btnCancel = findViewById(R.id.btn_cancel);

        // =========================================================================
        //                 PHẦN THIẾT LẬP NÚT BACK (QUAY LẠI)
        // =========================================================================
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Sử dụng setNavigationOnClickListener để xử lý sự kiện nút back trên Toolbar
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        // =========================================================================

        // 2. Lấy thông tin từ Intent
        accountType = getIntent().getStringExtra("ACCOUNT_TYPE");
        if (accountType == null) {
            accountType = "USER"; // Mặc định là USER
        }

        // 3. Kiểm tra nếu là chế độ Sửa (Edit Mode)
        if (getIntent().hasExtra("ACCOUNT_ID")) {
            userId = getIntent().getIntExtra("ACCOUNT_ID", -1);
            loadAccountData(userId);
            toolbar.setTitle("Sửa " + ("ADMIN".equals(accountType) ? "Admin" : "Người Dùng"));

            // Ẩn password field nhưng hiện checkbox để sửa mật khẩu
            tvPasswordLabel.setVisibility(View.GONE);
            etPassword.setVisibility(View.GONE);
            tvConfirmPasswordLabel.setVisibility(View.GONE);
            etConfirmPassword.setVisibility(View.GONE);
            cbChangePassword.setVisibility(View.VISIBLE);

            // Khi checkbox được chọn, hiển thị password fields
            cbChangePassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    tvPasswordLabel.setVisibility(View.VISIBLE);
                    etPassword.setVisibility(View.VISIBLE);
                    tvConfirmPasswordLabel.setVisibility(View.VISIBLE);
                    etConfirmPassword.setVisibility(View.VISIBLE);
                } else {
                    tvPasswordLabel.setVisibility(View.GONE);
                    etPassword.setVisibility(View.GONE);
                    tvConfirmPasswordLabel.setVisibility(View.GONE);
                    etConfirmPassword.setVisibility(View.GONE);
                    etPassword.setText("");
                    etConfirmPassword.setText("");
                }
            });
        } else {
            toolbar.setTitle("Thêm " + ("ADMIN".equals(accountType) ? "Admin" : "Người Dùng") + " Mới");

            // Hiện password fields khi thêm mới
            tvPasswordLabel.setVisibility(View.VISIBLE);
            etPassword.setVisibility(View.VISIBLE);
            tvConfirmPasswordLabel.setVisibility(View.VISIBLE);
            etConfirmPassword.setVisibility(View.VISIBLE);
            cbChangePassword.setVisibility(View.GONE);
        }

        // 4. Thiết lập Listener
        btnSaveUser.setOnClickListener(v -> saveAccount());
        btnCancel.setOnClickListener(v -> onBackPressed());
    }

    /**
     * Tải dữ liệu tài khoản nếu đang ở chế độ sửa.
     */
    private void loadAccountData(int id) {
        if ("ADMIN".equals(accountType)) {
            Admin admin = adminController.getAdminById(id);
            if (admin != null) {
                etUsername.setText(admin.getUsername());
                etEmail.setText(admin.getEmail());
            } else {
                Toast.makeText(this, "Không tìm thấy admin để sửa.", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            User user = userController.getUserById(id);
            if (user != null) {
                etUsername.setText(user.getUsername());
                etEmail.setText(user.getEmail());
            } else {
                Toast.makeText(this, "Không tìm thấy người dùng để sửa.", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    /**
     * Xử lý lưu (Thêm mới hoặc Cập nhật) tài khoản.
     */
    private void saveAccount() {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        // Kiểm tra validation cơ bản
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(this, "Vui lòng nhập tên đăng nhập.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Vui lòng nhập email.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Kiểm tra định dạng email
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Email không hợp lệ.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (userId == -1) {
            // ========== CHẾ độ THÊM MỚI - Cần password ==========
            String password = etPassword.getText().toString().trim();
            String confirmPassword = etConfirmPassword.getText().toString().trim();

            if (TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Vui lòng nhập mật khẩu.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6) {
                Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Mật khẩu xác nhận không khớp.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Hash mật khẩu - SỬ DỤNG PasswordHashUtil
            String passwordHash = PasswordHashUtil.hashPassword(password);

            if ("ADMIN".equals(accountType)) {
                // Thêm mới Admin
                Admin newAdmin = new Admin(username, email);
                AdminController.AdminAddResult result = adminController.addAdmin(newAdmin, passwordHash);

                switch (result) {
                    case SUCCESS:
                        Toast.makeText(this, "Thêm admin thành công!", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case USERNAME_ALREADY_EXISTS:
                        Toast.makeText(this, "Tên đăng nhập đã tồn tại.", Toast.LENGTH_SHORT).show();
                        break;
                    case EMAIL_ALREADY_EXISTS:
                        Toast.makeText(this, "Email đã tồn tại.", Toast.LENGTH_SHORT).show();
                        break;
                    case ERROR:
                        Toast.makeText(this, "Lỗi khi thêm admin.", Toast.LENGTH_SHORT).show();
                        break;
                }
            } else {
                // Thêm mới User
                UserController.RegisterResult result = userController.register(username, email, passwordHash);

                switch (result) {
                    case SUCCESS:
                        Toast.makeText(this, "Thêm người dùng thành công!", Toast.LENGTH_SHORT).show();
                        finish();
                        break;
                    case USERNAME_ALREADY_EXISTS:
                        Toast.makeText(this, "Tên đăng nhập đã tồn tại.", Toast.LENGTH_SHORT).show();
                        break;
                    case EMAIL_ALREADY_EXISTS:
                        Toast.makeText(this, "Email đã tồn tại.", Toast.LENGTH_SHORT).show();
                        break;
                    case ERROR:
                        Toast.makeText(this, "Lỗi khi thêm người dùng.", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        } else {
            // ========== CHẾ độ CẬP NHẬT (Sửa) ==========
            boolean success = false;

            // Cập nhật username và email
            if ("ADMIN".equals(accountType)) {
                success = adminController.updateAdminInfo(userId, username, email);
            } else {
                success = userController.updateUserInfo(userId, username, email);
            }

            if (!success) {
                Toast.makeText(this, "Lỗi khi cập nhật thông tin (Tên đăng nhập/Email có thể đã tồn tại).", Toast.LENGTH_SHORT).show();
                return;
            }

            // Nếu người dùng chọn sửa mật khẩu
            if (cbChangePassword.isChecked()) {
                String password = etPassword.getText().toString().trim();
                String confirmPassword = etConfirmPassword.getText().toString().trim();

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "Vui lòng nhập mật khẩu mới.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    Toast.makeText(this, "Mật khẩu xác nhận không khớp.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Hash mật khẩu - SỬ DỤNG PasswordHashUtil
                String passwordHash = PasswordHashUtil.hashPassword(password);

                if ("ADMIN".equals(accountType)) {
                    success = adminController.updateAdminPassword(userId, passwordHash);
                } else {
                    success = userController.updatePassword(userId, passwordHash);
                }

                if (!success) {
                    Toast.makeText(this, "Lỗi khi cập nhật mật khẩu.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            Toast.makeText(this, "Cập nhật thành công!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}