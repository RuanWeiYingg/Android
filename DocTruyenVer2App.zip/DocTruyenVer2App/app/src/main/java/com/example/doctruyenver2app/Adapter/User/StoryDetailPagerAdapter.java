package com.example.doctruyenver2app.Adapter.User;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.doctruyenver2app.View.Fragment.ChapterListFragment;
import com.example.doctruyenver2app.View.Fragment.CommentFragment;
import com.example.doctruyenver2app.View.Fragment.StoryInfoFragment;

public class StoryDetailPagerAdapter extends FragmentStateAdapter {

    private static final int NUM_TABS = 3;
    private final int storyId;
    private final int userId;
    private final String userName;

    /**
     * Constructor với các tham số cần thiết
     */
    public StoryDetailPagerAdapter(@NonNull FragmentActivity fragmentActivity,
                                   int storyId,
                                   int userId,
                                   String userName) {
        super(fragmentActivity);
        this.storyId = storyId;
        this.userId = userId;
        this.userName = userName;
    }

    /**
     * Tạo Fragment tương ứng với vị trí tab
     */
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        Bundle bundle = new Bundle();
        bundle.putInt("STORY_ID", storyId);
        bundle.putInt("USER_ID", userId);
        bundle.putString("USER_NAME", userName);

        switch (position) {
            case 0:
                // Tab THÔNG TIN
                StoryInfoFragment infoFragment = new StoryInfoFragment();
                infoFragment.setArguments(bundle);
                return infoFragment;

            case 1:
                // Tab CHƯƠNG TRUYỆN
                ChapterListFragment chapterFragment = new ChapterListFragment();
                chapterFragment.setArguments(bundle);
                return chapterFragment;

            case 2:
                // Tab BÌNH LUẬN
                CommentFragment commentFragment = CommentFragment.newInstance(storyId, userId, userName);
                return commentFragment;

            default:
                StoryInfoFragment defaultFragment = new StoryInfoFragment();
                defaultFragment.setArguments(bundle);
                return defaultFragment;
        }
    }

    /**
     * Trả về số lượng tab
     */
    @Override
    public int getItemCount() {
        return NUM_TABS;
    }
}