package com.example.doctruyenver2app.Model;

// Lớp Model đại diện cho một Danh mục (Thể loại) trong cơ sở dữ liệu
public class Category {
    private int id;
    private String name;

    // Constructor mặc định (cần thiết cho một số thư viện hoặc khởi tạo nhanh)
    public Category() {
    }

    // Constructor khi đã có ID (đọc từ database)
    public Category(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Constructor khi tạo đối tượng mới (chưa có ID, ID sẽ được database tự động tạo)
    public Category(String name) {
        this.name = name;
    }

    // --- Getters ---
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    // --- Setters ---
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
