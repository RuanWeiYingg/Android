package com.example.doctruyenver2app.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.doctruyenver2app.Util.PasswordHashUtil;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "DocTruyen.db";
    private static final int DATABASE_VERSION = 13;

    // ======== TÊN CÁC BẢNG ========
    public static final String TABLE_USERS = "users";
    public static final String TABLE_ADMINS = "admins";
    public static final String TABLE_PASSWORDS = "passwords";
    public static final String TABLE_STORIES = "stories";
    public static final String TABLE_CHAPTERS = "chapters";
    public static final String TABLE_CATEGORIES = "categories";
    public static final String TABLE_STORY_CATEGORY = "story_category";
    public static final String TABLE_FAVORITES = "favorites";
    public static final String TABLE_COMMENTS = "comments";
    public static final String TABLE_REPORTS = "reports";

    // ======== TÊN CÁC CỘT ========
    public static final String COLUMN_PASS_ID = "id";
    public static final String COLUMN_HASH = "hash";
    public static final String COLUMN_CREATED_AT = "created_at";

    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_AVATAR = "avatar_path";
    public static final String COLUMN_PASSWORD_ID = "password_id";

    public static final String COLUMN_ADMIN_ID = "id";
    public static final String COLUMN_ADMIN_USERNAME = "username";
    public static final String COLUMN_ADMIN_EMAIL = "email";
    public static final String COLUMN_ADMIN_PASSWORD_ID = "password_id";

    public static final String COLUMN_STORY_ID = "id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_AUTHOR = "author";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_COVER_URL = "cover_url";
    public static final String COLUMN_CREATED_BY = "created_by";

    public static final String COLUMN_CHAPTER_ID = "id";
    public static final String COLUMN_STORY_ID_FK = "story_id";
    public static final String COLUMN_CHAPTER_TITLE = "title";
    public static final String COLUMN_CONTENT = "content";
    public static final String COLUMN_ORDER_INDEX = "order_index";

    public static final String COLUMN_CATEGORY_ID = "id";
    public static final String COLUMN_CATEGORY_NAME = "name";

    public static final String COLUMN_SC_ID = "id";
    public static final String COLUMN_SC_STORY_ID = "story_id";
    public static final String COLUMN_SC_CATEGORY_ID = "category_id";

    public static final String COLUMN_FAV_ID = "id";
    public static final String COLUMN_FAV_USER_ID = "user_id";
    public static final String COLUMN_FAV_STORY_ID = "story_id";
    public static final String COLUMN_ADDED_DATE = "added_date";

    public static final String COLUMN_COMMENT_ID = "id";
    public static final String COLUMN_COMMENT_USER_ID = "user_id";
    public static final String COLUMN_COMMENT_STORY_ID = "story_id";
    public static final String COLUMN_COMMENT_CHAPTER_ID = "chapter_id";
    public static final String COLUMN_COMMENT_CONTENT = "content";
    public static final String COLUMN_COMMENT_CREATED_AT = "created_at";

    public static final String COLUMN_REPORT_ID = "id";
    public static final String COLUMN_REPORT_REPORTER_USER_ID = "reporter_user_id";
    public static final String COLUMN_REPORT_REPORTED_COMMENT_ID = "reported_comment_id";
    public static final String COLUMN_REPORT_REASON = "reason";
    public static final String COLUMN_REPORT_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return dateFormat.format(new Date());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "Creating database tables...");
        db.execSQL("PRAGMA encoding = 'UTF-8'");

        db.execSQL("CREATE TABLE " + TABLE_PASSWORDS + " (" +
                COLUMN_PASS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_HASH + " TEXT NOT NULL, " +
                COLUMN_CREATED_AT + " TEXT DEFAULT CURRENT_TIMESTAMP);");

        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COLUMN_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COLUMN_AVATAR + " TEXT, " +
                COLUMN_PASSWORD_ID + " INTEGER NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_PASSWORD_ID + ") REFERENCES " + TABLE_PASSWORDS + "(" + COLUMN_PASS_ID + "));");

        db.execSQL("CREATE TABLE " + TABLE_ADMINS + " (" +
                COLUMN_ADMIN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ADMIN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COLUMN_ADMIN_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COLUMN_ADMIN_PASSWORD_ID + " INTEGER NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_ADMIN_PASSWORD_ID + ") REFERENCES " + TABLE_PASSWORDS + "(" + COLUMN_PASS_ID + "));");

        db.execSQL("CREATE TABLE " + TABLE_CATEGORIES + " (" +
                COLUMN_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CATEGORY_NAME + " TEXT UNIQUE NOT NULL);");

        db.execSQL("CREATE TABLE " + TABLE_STORIES + " (" +
                COLUMN_STORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT NOT NULL, " +
                COLUMN_AUTHOR + " TEXT, " +
                COLUMN_DESCRIPTION + " TEXT, " +
                COLUMN_COVER_URL + " TEXT, " +
                COLUMN_CREATED_BY + " INTEGER NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_CREATED_BY + ") REFERENCES " + TABLE_ADMINS + "(" + COLUMN_ADMIN_ID + ") ON DELETE CASCADE);");

        db.execSQL("CREATE TABLE " + TABLE_CHAPTERS + " (" +
                COLUMN_CHAPTER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_STORY_ID_FK + " INTEGER NOT NULL, " +
                COLUMN_CHAPTER_TITLE + " TEXT NOT NULL, " +
                COLUMN_CONTENT + " TEXT, " +
                COLUMN_ORDER_INDEX + " INTEGER NOT NULL, " +
                "UNIQUE(" + COLUMN_STORY_ID_FK + ", " + COLUMN_ORDER_INDEX + "), " +
                "FOREIGN KEY(" + COLUMN_STORY_ID_FK + ") REFERENCES " + TABLE_STORIES + "(" + COLUMN_STORY_ID + ") ON DELETE CASCADE);");

        db.execSQL("CREATE TABLE " + TABLE_STORY_CATEGORY + " (" +
                COLUMN_SC_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_SC_STORY_ID + " INTEGER NOT NULL, " +
                COLUMN_SC_CATEGORY_ID + " INTEGER NOT NULL, " +
                "UNIQUE(" + COLUMN_SC_STORY_ID + ", " + COLUMN_SC_CATEGORY_ID + "), " +
                "FOREIGN KEY(" + COLUMN_SC_STORY_ID + ") REFERENCES " + TABLE_STORIES + "(" + COLUMN_STORY_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + COLUMN_SC_CATEGORY_ID + ") REFERENCES " + TABLE_CATEGORIES + "(" + COLUMN_CATEGORY_ID + ") ON DELETE CASCADE);");

        db.execSQL("CREATE TABLE " + TABLE_FAVORITES + " (" +
                COLUMN_FAV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_FAV_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_FAV_STORY_ID + " INTEGER NOT NULL, " +
                COLUMN_ADDED_DATE + " TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "UNIQUE(" + COLUMN_FAV_USER_ID + ", " + COLUMN_FAV_STORY_ID + "), " +
                "FOREIGN KEY(" + COLUMN_FAV_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + COLUMN_FAV_STORY_ID + ") REFERENCES " + TABLE_STORIES + "(" + COLUMN_STORY_ID + ") ON DELETE CASCADE);");

        db.execSQL("CREATE TABLE " + TABLE_COMMENTS + " (" +
                COLUMN_COMMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_COMMENT_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_COMMENT_STORY_ID + " INTEGER NOT NULL, " +
                COLUMN_COMMENT_CHAPTER_ID + " INTEGER, " +
                COLUMN_COMMENT_CONTENT + " TEXT NOT NULL, " +
                COLUMN_COMMENT_CREATED_AT + " TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(" + COLUMN_COMMENT_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + COLUMN_COMMENT_STORY_ID + ") REFERENCES " + TABLE_STORIES + "(" + COLUMN_STORY_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + COLUMN_COMMENT_CHAPTER_ID + ") REFERENCES " + TABLE_CHAPTERS + "(" + COLUMN_CHAPTER_ID + ") ON DELETE CASCADE);");

        db.execSQL("CREATE TABLE " + TABLE_REPORTS + " (" +
                COLUMN_REPORT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_REPORT_REPORTER_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_REPORT_REPORTED_COMMENT_ID + " INTEGER NOT NULL, " +
                COLUMN_REPORT_REASON + " TEXT NOT NULL, " +
                COLUMN_REPORT_CREATED_AT + " TEXT DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(" + COLUMN_REPORT_REPORTER_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE, " +
                "FOREIGN KEY(" + COLUMN_REPORT_REPORTED_COMMENT_ID + ") REFERENCES " + TABLE_COMMENTS + "(" + COLUMN_COMMENT_ID + ") ON DELETE CASCADE);");

        insertInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPORTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVORITES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STORY_CATEGORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHAPTERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STORIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADMINS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PASSWORDS);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }
// Check
    private void insertInitialData(SQLiteDatabase db) {
        try {
            String hashedPass = PasswordHashUtil.hashPassword("user123");

            ContentValues p1 = new ContentValues();
            p1.put(COLUMN_HASH, hashedPass);
            long adminPassId = db.insert(TABLE_PASSWORDS, null, p1);

            ContentValues p2 = new ContentValues();
            p2.put(COLUMN_HASH, hashedPass);
            long userPassId = db.insert(TABLE_PASSWORDS, null, p2);

            ContentValues a = new ContentValues();
            a.put(COLUMN_ADMIN_USERNAME, "admin_user");
            a.put(COLUMN_ADMIN_EMAIL, "admin@app.com");
            a.put(COLUMN_ADMIN_PASSWORD_ID, adminPassId);
            long adminId = db.insert(TABLE_ADMINS, null, a);


            ContentValues cvSampleUser = new ContentValues();
            cvSampleUser.put(COLUMN_USERNAME, "Nguyễn Duy Anh");
            cvSampleUser.put(COLUMN_EMAIL, "duyanh@gmail.com");
            cvSampleUser.put(COLUMN_AVATAR, "");
            cvSampleUser.put(COLUMN_PASSWORD_ID, userPassId);
            db.insert(TABLE_USERS, null, cvSampleUser);


            String[][] storyData = {
                    {"Tiên Nghịch", "Nhĩ Căn", "Tiên Hiệp", "Hành trình tu tiên đầy gian khổ của Vương Lâm.", "anh_nen_tien_nghich.jpg"},
                    {"Đấu Phá Thương Khung", "Thiên Tằm Thổ Đậu", "Kiếm Hiệp", "Tiêu Viêm từ một thiên tài bị mất linh lực đến đỉnh cao.", "anh_nen_dau_pha_thuong_khung.jpg"},
                    {"Thần Điêu Đại Hiệp", "Kim Dung", "Võ Hiệp", "Chuyện tình đầy trắc trở giữa Dương Quá và Tiểu Long Nữ.", "anh_nen_than_dieu_dai_hiep.jpg"},
                    {"Đấu La Đại Lục", "Đường Gia Tam Thiếu", "Huyền Huyễn", "Đường Tam và hành trình thức tỉnh Võ Hồn tại thế giới mới.", "anh_nen_dau_la_dai_luc.jpg"},
                    {"Mắt Biếc", "Nguyễn Nhật Ánh", "Ngôn Tình", "Tình yêu đơn phương da diệt của Ngạn dành cho Hà Lan.", "anh_nen_mat_biec.jpg"},
                    {"Sherlock Holmes", "Arthur Conan Doyle", "Trinh Thám", "Những vụ án ly kỳ của vị thám tử tài ba nhất mọi thời đại.", "anh_nen_sherlock_holmes.jpg"},
                    {"Dế Mèn Phiêu Lưu Ký", "Tô Hoài", "Thiếu Nhi", "Những cuộc phiêu lưu đầy bài học của chú Dế Mèn.", "anh_nen_de_men_phieu_luu_ky.jpg"},
                    {"Tam Quốc Diễn Nghĩa", "La Quán Trung", "Lịch Sử", "Cuộc tranh hùng của ba nước Ngụy, Thục, Ngô.", "anh_nen_tam_quoc_dien_nghia.jpg"},
                    {"Hãy Nhắm Mắt Khi Anh Đến", "Đinh Mặc", "Trinh Thám/Ngôn Tình", "Sự kết hợp giữa phân tích tâm lý tội phạm và tình yêu.", "anh_nen_hay_nham_mat_khi_anh_den.jpg"},
                    {"Đất Rừng Phương Nam", "Đoàn Giỏi", "Văn Học", "Cuộc sống và con người vùng đất Nam Bộ kháng chiến.", "anh_nen_dat_rung_phuong_nam.jpg"}
            };

            Map<String, Long> catMap = new HashMap<>();
            for (String[] data : storyData) {
                String title = data[0], author = data[1], catName = data[2], desc = data[3], imageName = data[4];

                if (!catMap.containsKey(catName)) {
                    ContentValues cvCat = new ContentValues();
                    cvCat.put(COLUMN_CATEGORY_NAME, catName);
                    catMap.put(catName, db.insert(TABLE_CATEGORIES, null, cvCat));
                }

                ContentValues cvS = new ContentValues();
                cvS.put(COLUMN_TITLE, title);
                cvS.put(COLUMN_AUTHOR, author);
                cvS.put(COLUMN_DESCRIPTION, desc);
                cvS.put(COLUMN_COVER_URL, imageName);
                cvS.put(COLUMN_CREATED_BY, adminId);
                long sId = db.insert(TABLE_STORIES, null, cvS);

                ContentValues cvSC = new ContentValues();
                cvSC.put(COLUMN_SC_STORY_ID, sId);
                cvSC.put(COLUMN_SC_CATEGORY_ID, catMap.get(catName));
                db.insert(TABLE_STORY_CATEGORY, null, cvSC);

                for (int i = 1; i <= 5; i++) {
                    ContentValues cvChapter = new ContentValues();
                    cvChapter.put(COLUMN_STORY_ID_FK, sId);
                    cvChapter.put(COLUMN_CHAPTER_TITLE, "Chương " + i + ": Khởi đầu mới");
                    cvChapter.put(COLUMN_CONTENT, "Đây là nội dung chương " + i + " của bộ truyện " + title + ". \nNội dung đang được cập nhật...");
                    cvChapter.put(COLUMN_ORDER_INDEX, i);
                    db.insert(TABLE_CHAPTERS, null, cvChapter);
                }
            }
            Log.d(TAG, "✅ Seeded 10 stories with 5 chapters each successfully.");
        } catch (Exception e) {
            Log.e(TAG, "Seed data error: " + e.getMessage());
        }
    }
}