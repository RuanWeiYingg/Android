package com.example.doctruyenver2app.Model;

public class Story {
    private int id;
    private String title;
    private String author;
    private String description;
    private String coverUrl;
    private int createdBy; // admin_id

    // =========================================================
    // <<< TRƯỜNG BỔ SUNG CHO MÀN HÌNH DANH SÁCH/ADAPTER >>>
    private String categoryName;
    private int chapterCount;
    // =========================================================

    public Story() {}

    // Constructor 1: Dùng khi ĐỌC dữ liệu cơ bản từ DB (Có đầy đủ ID)
    public Story(int id, String title, String author, String description, String coverUrl, int createdBy) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.coverUrl = coverUrl;
        this.createdBy = createdBy;
    }

    // Constructor 2: Dùng khi THÊM MỚI dữ liệu vào DB (Không có ID)
    public Story(String title, String author, String description, String coverUrl, int createdBy) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.coverUrl = coverUrl;
        this.createdBy = createdBy;
    }

    // <<< Constructor 3: Dùng khi lấy đầy đủ thông tin cho Adapter >>>
    // Yêu cầu StoryController phải thực hiện JOIN và COUNT
    public Story(int id, String title, String author, String description, String coverUrl, int createdBy, String categoryName, int chapterCount) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.coverUrl = coverUrl;
        this.createdBy = createdBy;
        this.categoryName = categoryName;
        this.chapterCount = chapterCount;
    }

    // Getter & Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCoverUrl() { return coverUrl; }
    public void setCoverUrl(String coverUrl) { this.coverUrl = coverUrl; }

    public int getCreatedBy() { return createdBy; }
    public void setCreatedBy(int createdBy) { this.createdBy = createdBy; }

    // <<< Getter & Setter cho các trường bổ sung >>>
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public int getChapterCount() { return chapterCount; }
    public void setChapterCount(int chapterCount) { this.chapterCount = chapterCount; }
}