package com.example.doctruyenver2app.Adapter.User;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Controller.ReportController;
import com.example.doctruyenver2app.Controller.UserController;
import com.example.doctruyenver2app.Model.Comment;
import com.example.doctruyenver2app.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {

    private Context context;
    private List<Comment> comments = new ArrayList<>();
    private UserController userController;
    private ReportController reportController;
    private int currentUserId; // ID người dùng hiện tại để báo cáo

    // Constructor nhận 2 tham số để fix lỗi "Expected 2 arguments"
    public CommentAdapter(Context context, int currentUserId) {
        this.context = context;
        this.currentUserId = currentUserId;
        this.userController = new UserController(context);
        this.reportController = new ReportController(context);
    }

    // Method setComments để fix lỗi "Cannot resolve method"
    public void setComments(List<Comment> commentList) {
        this.comments = commentList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_comment, parent, false);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
        Comment comment = comments.get(position);
        holder.bind(comment);
    }

    @Override
    public int getItemCount() {
        return comments.size();
    }

    public class CommentViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivUserAvatar;
        private TextView tvUserName, tvCommentContent, tvCommentTime;
        private TextView tvReply, tvLikeCount, tvDislikeCount;
        private LinearLayout layoutLike, layoutDislike;
        private ImageButton btnMore;

        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            ivUserAvatar = itemView.findViewById(R.id.iv_user_avatar);
            tvUserName = itemView.findViewById(R.id.tv_user_name);
            tvCommentContent = itemView.findViewById(R.id.tv_comment_content);
            tvCommentTime = itemView.findViewById(R.id.tv_comment_time);
            tvReply = itemView.findViewById(R.id.tv_comment_actions);
            tvLikeCount = itemView.findViewById(R.id.tv_like_count);
            tvDislikeCount = itemView.findViewById(R.id.tv_dislike_count);
            layoutLike = itemView.findViewById(R.id.layout_like);
            layoutDislike = itemView.findViewById(R.id.layout_dislike);
            btnMore = itemView.findViewById(R.id.btn_comment_more);
        }

        public void bind(Comment comment) {
            tvUserName.setText("User " + comment.getUserId());
            tvCommentContent.setText(comment.getContent());
            tvCommentTime.setText(formatTime(comment.getCreatedAt()));
            ivUserAvatar.setImageResource(R.drawable.ic_avatar_placeholder);

            // Báo cáo vi phạm
            btnMore.setOnClickListener(v -> {
                PopupMenu popup = new PopupMenu(context, btnMore);
                popup.getMenu().add("Báo cáo vi phạm");
                popup.setOnMenuItemClickListener(item -> {
                    // Gọi sang ReportController
                    boolean success = reportController.createReport(currentUserId, comment.getId(), "Nội dung vi phạm");
                    if (success) Toast.makeText(context, "Đã gửi báo cáo!", Toast.LENGTH_SHORT).show();
                    return true;
                });
                popup.show();
            });
        }

        private String formatTime(String createdAt) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                Date date = sdf.parse(createdAt);
                long diff = System.currentTimeMillis() - date.getTime();
                long minutes = diff / 60000;
                if (minutes < 60) return minutes + " phút trước";
                return (minutes / 60) + " giờ trước";
            } catch (Exception e) { return createdAt; }
        }
    }
}