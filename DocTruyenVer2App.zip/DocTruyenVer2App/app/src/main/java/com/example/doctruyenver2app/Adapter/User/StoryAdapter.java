package com.example.doctruyenver2app.Adapter.User;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.View.StoryDetailActivity;

import java.util.List;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {

    private static final String TAG = "StoryAdapter_User";
    private List<Story> storyList;
    private Context context;

    public StoryAdapter(List<Story> storyList, Context context) {
        this.storyList = storyList;
        this.context = context;
    }

    @NonNull
    @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Liên kết với layout item_story
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_story, parent, false);
        return new StoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder holder, int position) {
        Story story = storyList.get(position);

        // 1. Đổ dữ liệu văn bản (Thêm icon emoji để tăng tính thẩm mỹ và tương phản)
        holder.tvTitle.setText(story.getTitle());
        holder.tvAuthor.setText("✍️ Tác giả: " + story.getAuthor());

        // Hiển thị Thể loại (Lấy từ Model Story)
        if (story.getCategoryName() != null) {
            holder.tvCategory.setText("🏷️ Thể loại: " + story.getCategoryName());
        }

        // Hiển thị Mô tả ngắn (Giới hạn khoảng 80 ký tự để không làm vỡ giao diện)
        if (story.getDescription() != null) {
            String desc = story.getDescription();
            if (desc.length() > 85) {
                desc = desc.substring(0, 82) + "...";
            }
            holder.tvDescription.setText(desc);
        }

        // 2. Xử lý tải ảnh bìa (Giữ nguyên logic xử lý tên Resource của bạn)
        String coverUrl = story.getCoverUrl();
        if (coverUrl != null && !coverUrl.isEmpty()) {
            String imageName = coverUrl;
            int lastDotIndex = coverUrl.lastIndexOf('.');
            if (lastDotIndex > 0) {
                imageName = coverUrl.substring(0, lastDotIndex);
            }

            imageName = imageName.toLowerCase().replaceAll("[^a-z0-9_]", "_");

            int resourceId = context.getResources().getIdentifier(
                    imageName, "drawable", context.getPackageName()
            );

            if (resourceId != 0) {
                Glide.with(context)
                        .load(resourceId)
                        .placeholder(R.drawable.ic_placeholder_cover)
                        .error(R.drawable.ic_placeholder_cover)
                        .into(holder.imgCover);
            } else {
                holder.imgCover.setImageResource(R.drawable.ic_placeholder_cover);
            }
        } else {
            holder.imgCover.setImageResource(R.drawable.ic_placeholder_cover);
        }

        // 3. Sự kiện Click chuyển màn hình
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, StoryDetailActivity.class);
            intent.putExtra("STORY_ID", story.getId());
            intent.putExtra("STORY_TITLE", story.getTitle());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return (storyList != null) ? storyList.size() : 0;
    }

    /**
     * ViewHolder: Đã sửa lỗi cú pháp và khai báo thêm View
     */
    public static class StoryViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        TextView tvTitle, tvAuthor, tvCategory, tvDescription;

        public StoryViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.img_story_cover);
            tvTitle = itemView.findViewById(R.id.tv_story_title);
            tvAuthor = itemView.findViewById(R.id.tv_story_author);

            // Khai báo thêm các View mới để hiển thị đầy đủ thông tin
            tvCategory = itemView.findViewById(R.id.tv_story_category);
            tvDescription = itemView.findViewById(R.id.tv_story_description);
        }
    }
}