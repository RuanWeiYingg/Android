package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Category;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller quản lý các thao tác với bảng Danh mục (categories)
 * Đã tối ưu hóa cho Tiếng Việt Unicode.
 */
public class CategoryController {

    private static final String TAG = "CategoryController";
    private DatabaseHelper dbHelper;

    public CategoryController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // =========================================================================
    //                            QUẢN LÝ DANH MỤC (CATEGORIES)
    // =========================================================================

    /**
     * Thêm danh mục mới với cơ chế chống trùng lặp Unicode
     */
    public long addCategory(Category category) {
        if (category.getName() == null || category.getName().trim().isEmpty()) return -1;

        // Kiểm tra tồn tại (không phân biệt hoa thường/dấu cách thừa)
        if (isCategoryNameExists(category.getName())) {
            Log.w(TAG, "Category already exists: " + category.getName());
            return -1;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_CATEGORY_NAME, category.getName().trim());

        long id = -1;
        try {
            id = db.insert(DatabaseHelper.TABLE_CATEGORIES, null, values);
        } catch (Exception e) {
            Log.e(TAG, "Error inserting category: " + e.getMessage());
        } finally {
            db.close();
        }
        return id;
    }

    public Category getCategoryById(int categoryId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Category category = null;
        Cursor cursor = null;

        try {
            cursor = db.query(
                    DatabaseHelper.TABLE_CATEGORIES,
                    new String[]{DatabaseHelper.COLUMN_CATEGORY_ID, DatabaseHelper.COLUMN_CATEGORY_NAME},
                    DatabaseHelper.COLUMN_CATEGORY_ID + " = ?",
                    new String[]{String.valueOf(categoryId)},
                    null, null, null
            );

            if (cursor != null && cursor.moveToFirst()) {
                category = new Category(cursor.getInt(0), cursor.getString(1));
            }
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return category;
    }

    public List<Category> getAllCategories() {
        List<Category> categoryList = new ArrayList<>();
        // Sắp xếp Alphabet để dễ tìm kiếm trên giao diện
        String selectQuery = "SELECT * FROM " + DatabaseHelper.TABLE_CATEGORIES +
                " ORDER BY " + DatabaseHelper.COLUMN_CATEGORY_NAME + " ASC";

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        try (Cursor cursor = db.rawQuery(selectQuery, null)) {
            if (cursor.moveToFirst()) {
                do {
                    categoryList.add(new Category(cursor.getInt(0), cursor.getString(1)));
                } while (cursor.moveToNext());
            }
        } finally {
            db.close();
        }
        return categoryList;
    }

    public boolean updateCategory(Category category) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_CATEGORY_NAME, category.getName().trim());

        int rowsAffected = 0;
        try {
            rowsAffected = db.update(
                    DatabaseHelper.TABLE_CATEGORIES,
                    values,
                    DatabaseHelper.COLUMN_CATEGORY_ID + " = ?",
                    new String[]{String.valueOf(category.getId())}
            );
        } finally {
            db.close();
        }
        return rowsAffected > 0;
    }

    public boolean deleteCategory(int categoryId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        int rowsAffected = 0;
        try {
            // 1. Xóa các liên kết trước để tránh lỗi ràng buộc Foreign Key
            db.delete(DatabaseHelper.TABLE_STORY_CATEGORY,
                    DatabaseHelper.COLUMN_SC_CATEGORY_ID + " = ?",
                    new String[]{String.valueOf(categoryId)});

            // 2. Xóa danh mục chính
            rowsAffected = db.delete(DatabaseHelper.TABLE_CATEGORIES,
                    DatabaseHelper.COLUMN_CATEGORY_ID + " = ?",
                    new String[]{String.valueOf(categoryId)});

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            db.close();
        }
        return rowsAffected > 0;
    }

    // =========================================================================
    //                     PHƯƠNG THỨC KIỂM TRA & TÌM KIẾM (TIẾNG VIỆT)
    // =========================================================================

    public boolean isCategoryNameExists(String categoryName) {
        if (categoryName == null) return false;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        boolean exists = false;

        String selectQuery = "SELECT 1 FROM " + DatabaseHelper.TABLE_CATEGORIES +
                " WHERE " + DatabaseHelper.COLUMN_CATEGORY_NAME + " = ? COLLATE NOCASE";

        try (Cursor cursor = db.rawQuery(selectQuery, new String[]{categoryName.trim()})) {
            exists = (cursor != null && cursor.getCount() > 0);
        } finally {
            db.close();
        }
        return exists;
    }

    public List<Category> searchCategoriesByName(String query) {
        List<Category> categoryList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Sử dụng LOWER để tìm kiếm không phân biệt hoa thường với Unicode
        String selectQuery = "SELECT * FROM " + DatabaseHelper.TABLE_CATEGORIES +
                " WHERE LOWER(" + DatabaseHelper.COLUMN_CATEGORY_NAME + ") LIKE LOWER(?)";

        try (Cursor cursor = db.rawQuery(selectQuery, new String[]{"%" + query.trim() + "%"})) {
            if (cursor.moveToFirst()) {
                do {
                    categoryList.add(new Category(cursor.getInt(0), cursor.getString(1)));
                } while (cursor.moveToNext());
            }
        } finally {
            db.close();
        }
        return categoryList;
    }

    // =========================================================================
    //                       PHƯƠNG THỨC LIÊN KẾT TRUYỆN (STORY_CATEGORY)
    // =========================================================================

    public long linkStoryToCategory(int storyId, int categoryId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_SC_STORY_ID, storyId);
        values.put(DatabaseHelper.COLUMN_SC_CATEGORY_ID, categoryId);

        try {
            // Dùng insertOrThrow để báo lỗi nếu bị trùng liên kết (Unique constraint)
            return db.insertOrThrow(DatabaseHelper.TABLE_STORY_CATEGORY, null, values);
        } catch (Exception e) {
            return -1;
        } finally {
            db.close();
        }
    }

    /**
     * ✅ ĐÃ THÊM LẠI: Phương thức hủy liên kết
     */
    public boolean unlinkStoryFromCategory(int storyId, int categoryId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsAffected = 0;
        try {
            rowsAffected = db.delete(
                    DatabaseHelper.TABLE_STORY_CATEGORY,
                    DatabaseHelper.COLUMN_SC_STORY_ID + " = ? AND " + DatabaseHelper.COLUMN_SC_CATEGORY_ID + " = ?",
                    new String[]{String.valueOf(storyId), String.valueOf(categoryId)}
            );
        } finally {
            db.close();
        }
        return rowsAffected > 0;
    }

    public List<Category> getCategoriesForStory(int storyId) {
        List<Category> categoryList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selectQuery = "SELECT T1." + DatabaseHelper.COLUMN_CATEGORY_ID + ", T1." + DatabaseHelper.COLUMN_CATEGORY_NAME +
                " FROM " + DatabaseHelper.TABLE_CATEGORIES + " T1" +
                " INNER JOIN " + DatabaseHelper.TABLE_STORY_CATEGORY + " T2" +
                " ON T1." + DatabaseHelper.COLUMN_CATEGORY_ID + " = T2." + DatabaseHelper.COLUMN_SC_CATEGORY_ID +
                " WHERE T2." + DatabaseHelper.COLUMN_SC_STORY_ID + " = ?";

        try (Cursor cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(storyId)})) {
            if (cursor.moveToFirst()) {
                do {
                    categoryList.add(new Category(cursor.getInt(0), cursor.getString(1)));
                } while (cursor.moveToNext());
            }
        } finally {
            db.close();
        }
        return categoryList;
    }
}