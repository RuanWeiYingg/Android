package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.User;

import java.util.ArrayList;
import java.util.List;

import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class UserController {
    private static final String TAG = "UserController";
    private DatabaseHelper dbHelper;

    public enum LoginResult { SUCCESS, INVALID_CREDENTIALS, USER_NOT_FOUND, ERROR }
    public enum RegisterResult { SUCCESS, USERNAME_ALREADY_EXISTS, EMAIL_ALREADY_EXISTS, ERROR }

    public UserController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // =========================================================
    // =============== CHỨC NĂNG ĐĂNG KÝ (CREATE) ===============
    // =========================================================

    public RegisterResult register(String username, String email, String passwordHash) {
        if (isUsernameExists(username)) return RegisterResult.USERNAME_ALREADY_EXISTS;
        if (isEmailExists(email)) return RegisterResult.EMAIL_ALREADY_EXISTS;

        User newUser = new User(username, email);
        newUser.setAvatarPath("");

        long result = addUser(newUser, passwordHash);
        return (result > 0) ? RegisterResult.SUCCESS : RegisterResult.ERROR;
    }

    private long addUser(User user, String passwordHash) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long passId = -1, userId = -1;
        db.beginTransaction();
        try {
            ContentValues passValues = new ContentValues();
            passValues.put(COLUMN_HASH, passwordHash);
            passId = db.insert(TABLE_PASSWORDS, null, passValues);

            if (passId != -1) {
                ContentValues userValues = new ContentValues();
                userValues.put(COLUMN_USERNAME, user.getUsername());
                userValues.put(COLUMN_EMAIL, user.getEmail());
                userValues.put(COLUMN_AVATAR, user.getAvatarPath());
                userValues.put(COLUMN_PASSWORD_ID, passId);
                userId = db.insert(TABLE_USERS, null, userValues);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error adding user: " + e.getMessage());
        } finally {
            db.endTransaction();
            db.close();
        }
        return userId;
    }

    // =========================================================
    // =============== CHỨC NĂNG ĐĂNG NHẬP & READ ===============
    // =========================================================

    public LoginResult login(String usernameOrEmail, String passwordHash) {
        User user = getUserByUsernameOrEmail(usernameOrEmail);
        if (user == null) return LoginResult.USER_NOT_FOUND;

        String storedHash = getPasswordHash(user.getId());
        if (storedHash != null && storedHash.equals(passwordHash)) {
            return LoginResult.SUCCESS;
        } else {
            return LoginResult.INVALID_CREDENTIALS;
        }
    }

    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT " + COLUMN_USER_ID + ", " + COLUMN_USERNAME + ", " + COLUMN_EMAIL + ", " + COLUMN_AVATAR + " FROM " + TABLE_USERS, null);
            if (cursor.moveToFirst()) {
                do {
                    list.add(new User(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting all users: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return list;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        User user = null;
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID, COLUMN_USERNAME, COLUMN_EMAIL, COLUMN_AVATAR},
                    COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null);
            if (cursor.moveToFirst()) {
                user = new User(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting user by ID: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return user;
    }

    public User getUserByUsernameOrEmail(String identifier) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        User user = null;
        Cursor cursor = null;
        String selection = COLUMN_USERNAME + " = ? COLLATE NOCASE OR " + COLUMN_EMAIL + " = ? COLLATE NOCASE";
        try {
            cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_ID, COLUMN_USERNAME, COLUMN_EMAIL, COLUMN_AVATAR}, selection, new String[]{identifier, identifier}, null, null, null);
            if (cursor.moveToFirst()) {
                user = new User(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching user: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return user;
    }

    // =========================================================
    // =============== CHỨC NĂNG CẬP NHẬT (UPDATE) ==============
    // =========================================================

    // Hàm này dùng để fix lỗi "cannot find symbol: method updateUserInfo"
    public boolean updateUserInfo(int userId, String newUsername, String newEmail) {
        User currentUser = getUserById(userId);
        String currentAvatar = (currentUser != null) ? currentUser.getAvatarPath() : "";
        // Gọi hàm 5 tham số với mật khẩu rỗng
        return updateUserProfile(userId, newUsername, newEmail, currentAvatar, "");
    }

    // CẬP NHẬT: Thêm tham số newPassword để khớp với Activity
    public boolean updateUserProfile(int userId, String newUsername, String newEmail, String avatarPath, String newPassword) {
        if (isUsernameExistsExcludingUser(newUsername, userId)) return false;
        if (isEmailExistsExcludingUser(newEmail, userId)) return false;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        boolean success = false;
        db.beginTransaction();
        try {
            // 1. Cập nhật thông tin cơ bản trong bảng Users
            ContentValues userValues = new ContentValues();
            userValues.put(COLUMN_USERNAME, newUsername);
            userValues.put(COLUMN_EMAIL, newEmail);
            userValues.put(COLUMN_AVATAR, avatarPath);
            db.update(TABLE_USERS, userValues, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});

            // 2. Nếu có mật khẩu mới, cập nhật bảng Passwords
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                // Tìm password_id của user này
                Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_PASSWORD_ID},
                        COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null);

                if (cursor.moveToFirst()) {
                    int passId = cursor.getInt(0);
                    ContentValues passValues = new ContentValues();
                    passValues.put(COLUMN_HASH, newPassword); // Lưu ý: thực tế nên hash mật khẩu
                    db.update(TABLE_PASSWORDS, passValues, COLUMN_PASS_ID + " = ?", new String[]{String.valueOf(passId)});
                }
                cursor.close();
            }

            db.setTransactionSuccessful();
            success = true;
        } catch (Exception e) {
            Log.e(TAG, "Error updating profile: " + e.getMessage());
        } finally {
            db.endTransaction();
            db.close();
        }
        return success;
    }

    public boolean updateUserProfile(int userId, String newUsername, String newEmail, String avatarPath) {
        if (isUsernameExistsExcludingUser(newUsername, userId)) return false;
        if (isEmailExistsExcludingUser(newEmail, userId)) return false;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, newUsername);
        values.put(COLUMN_EMAIL, newEmail);
        values.put(COLUMN_AVATAR, avatarPath);

        int rowsAffected = db.update(TABLE_USERS, values, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        db.close();
        return rowsAffected > 0;
    }

    public boolean updatePassword(int userId, String newPasswordHash) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_PASSWORD_ID}, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null);
        int passId = -1;
        if (cursor.moveToFirst()) passId = cursor.getInt(0);
        cursor.close();

        if (passId != -1) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_HASH, newPasswordHash);
            int rows = db.update(TABLE_PASSWORDS, values, COLUMN_PASS_ID + " = ?", new String[]{String.valueOf(passId)});
            db.close();
            return rows > 0;
        }
        db.close();
        return false;
    }

    // =========================================================
    // =============== CHỨC NĂNG XÓA & KIỂM TRA =================
    // =========================================================

    public boolean deleteUser(int userId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE_FAVORITES, COLUMN_FAV_USER_ID + " = ?", new String[]{String.valueOf(userId)});
            db.delete(TABLE_COMMENTS, COLUMN_COMMENT_USER_ID + " = ?", new String[]{String.valueOf(userId)});
            int deleted = db.delete(TABLE_USERS, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
            db.setTransactionSuccessful();
            return deleted > 0;
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    private boolean isUsernameExists(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COLUMN_USERNAME + "=? COLLATE NOCASE", new String[]{username}, null, null, null);
        boolean exists = c.getCount() > 0;
        c.close(); return exists;
    }

    private boolean isEmailExists(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COLUMN_EMAIL + "=? COLLATE NOCASE", new String[]{email}, null, null, null);
        boolean exists = c.getCount() > 0;
        c.close(); return exists;
    }

    private boolean isUsernameExistsExcludingUser(String username, int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COLUMN_USERNAME + "=? COLLATE NOCASE AND " + COLUMN_USER_ID + "!=?", new String[]{username, String.valueOf(userId)}, null, null, null);
        boolean exists = c.getCount() > 0;
        c.close(); return exists;
    }

    private boolean isEmailExistsExcludingUser(String email, int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null, COLUMN_EMAIL + "=? COLLATE NOCASE AND " + COLUMN_USER_ID + "!=?", new String[]{email, String.valueOf(userId)}, null, null, null);
        boolean exists = c.getCount() > 0;
        c.close(); return exists;
    }

    private String getPasswordHash(int userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT p." + COLUMN_HASH + " FROM " + TABLE_PASSWORDS + " p JOIN " + TABLE_USERS + " u ON p." + COLUMN_PASS_ID + " = u." + COLUMN_PASSWORD_ID + " WHERE u." + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        String hash = null;
        if (c.moveToFirst()) hash = c.getString(0);
        c.close(); return hash;
    }
}