package com.example.doctruyenver2app.Adapter.Admin;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

import java.util.List;

/**
 * Adapter cho RecyclerView hiển thị danh sách truyện trong màn hình Admin.
 * Sử dụng layout item_story_admin.xml
 */
public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {

    private static final String TAG = "StoryAdapter";
    private List<Story> storyList;
    private OnItemActionListener listener;
    private Context context;

    // Interface để xử lý các hành động Sửa/Xóa/Quản lý Chương
    public interface OnItemActionListener {
        void onEditClick(Story story);
        void onDeleteClick(Story story);
        void onManageChaptersClick(Story story);
    }

    public StoryAdapter(Context context, List<Story> storyList, OnItemActionListener listener) {
        this.context = context;
        this.storyList = storyList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_story_admin, parent, false);
        return new StoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder holder, int position) {
        Story story = storyList.get(position);

        // 1. Gán dữ liệu cơ bản
        holder.tvTitle.setText(story.getTitle());
        holder.tvAuthor.setText("Tác giả: " + story.getAuthor());

        // 2. Gán thông tin Thể loại và Số chương
        holder.tvCategory.setText("Thể loại: " + (story.getCategoryName() != null ? story.getCategoryName() : "[Chưa gán]"));
        holder.tvChapterCount.setText("Chương: " + story.getChapterCount());

        // 3. Tải ảnh bìa từ thư mục res/drawable
        String coverUrl = story.getCoverUrl();
        ImageView imgCover = holder.imgCover;
        Context ctx = holder.itemView.getContext();

        if (coverUrl != null && !coverUrl.isEmpty()) {
            // Loại bỏ phần mở rộng (.jpg, .png, v.v.)
            String imageName;
            int lastDotIndex = coverUrl.lastIndexOf('.');

            if (lastDotIndex > 0) {
                // Nếu có đuôi file, lấy phần trước dấu chấm
                imageName = coverUrl.substring(0, lastDotIndex);
            } else {
                // Nếu không có đuôi file, dùng toàn bộ tên
                imageName = coverUrl;
            }

            // Chuyển thành chữ thường
            imageName = imageName.toLowerCase();
            // Thay thế các ký tự không hợp lệ bằng dấu gạch dưới
            imageName = imageName.replaceAll("[^a-z0-9_]", "_");

            Log.d(TAG, "Original coverUrl: " + coverUrl + " -> resourceName: " + imageName);

            // Lấy ID của drawable resource
            int resourceId = ctx.getResources().getIdentifier(
                    imageName,
                    "drawable",
                    ctx.getPackageName()
            );

            if (resourceId != 0) {
                // Nếu tìm thấy resource
                Log.d(TAG, "Found resource: " + imageName);
                Glide.with(ctx)
                        .load(resourceId)
                        .placeholder(R.drawable.placeholder_cover)
                        .error(R.drawable.placeholder_cover)
                        .into(imgCover);
            } else {
                // Nếu không tìm thấy resource, hiển thị ảnh mặc định
                Log.d(TAG, "Resource not found: " + imageName);
                imgCover.setImageResource(R.drawable.placeholder_cover);
            }
        } else {
            // Hiển thị ảnh mặc định nếu không có URL
            imgCover.setImageResource(R.drawable.placeholder_cover);
        }

        // 4. Thiết lập sự kiện click cho các nút
        holder.btnEdit.setOnClickListener(v -> {
            if (listener != null) {
                listener.onEditClick(story);
            }
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(story);
            }
        });

        holder.btnManageChapters.setOnClickListener(v -> {
            if (listener != null) {
                listener.onManageChaptersClick(story);
            }
        });
    }

    @Override
    public int getItemCount() {
        return storyList.size();
    }

    // Phương thức cập nhật danh sách
    public void updateStoryList(List<Story> newStoryList) {
        this.storyList = newStoryList;
        notifyDataSetChanged();
    }

    public static class StoryViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCover;
        TextView tvTitle;
        TextView tvAuthor;
        TextView tvCategory;
        TextView tvChapterCount;
        ImageButton btnEdit;
        ImageButton btnDelete;
        Button btnManageChapters;

        public StoryViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCover = itemView.findViewById(R.id.img_story_cover);
            tvTitle = itemView.findViewById(R.id.tv_story_title);
            tvAuthor = itemView.findViewById(R.id.tv_story_author);
            tvCategory = itemView.findViewById(R.id.tv_category);
            tvChapterCount = itemView.findViewById(R.id.tv_chapter_count);
            btnEdit = itemView.findViewById(R.id.btn_edit_story);
            btnDelete = itemView.findViewById(R.id.btn_delete_story);
            btnManageChapters = itemView.findViewById(R.id.btn_manage_chapters);
        }
    }
}