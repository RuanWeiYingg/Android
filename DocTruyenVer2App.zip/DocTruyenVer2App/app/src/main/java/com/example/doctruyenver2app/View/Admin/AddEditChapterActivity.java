package com.example.doctruyenver2app.View.Admin;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.doctruyenver2app.Controller.ChapterController;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

public class AddEditChapterActivity extends AppCompatActivity {

    private EditText etChapterTitle, etChapterContent, etChapterOrder;
    private Button btnSaveChapter, btnCancelChapter, btnBackChapter;
    private TextView tvStoryTitle, tvChapterMode, tvContentInfo;

    private ChapterController chapterController;
    private StoryController storyController;
    private int storyId = -1; // ID truyện mà chương này thuộc về
    private int chapterId = -1; // -1 nếu thêm mới, > 0 nếu sửa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_chapter);

        chapterController = new ChapterController(this);
        storyController = new StoryController(this);

        // 1. Ánh xạ Views
        etChapterTitle = findViewById(R.id.et_chapter_title);
        etChapterContent = findViewById(R.id.et_chapter_content);
        etChapterOrder = findViewById(R.id.et_chapter_order);
        btnSaveChapter = findViewById(R.id.btn_save_chapter);
        btnCancelChapter = findViewById(R.id.btn_cancel_chapter);
        btnBackChapter = findViewById(R.id.btn_back_chapter);
        tvStoryTitle = findViewById(R.id.tv_story_title);
        tvChapterMode = findViewById(R.id.tv_chapter_mode);
        tvContentInfo = findViewById(R.id.tv_content_info);

        // 2. Lấy Story ID và Chapter ID từ Intent
        storyId = getIntent().getIntExtra("STORY_ID", -1);
        chapterId = getIntent().getIntExtra("CHAPTER_ID", -1);

        if (storyId == -1) {
            Toast.makeText(this, "Lỗi: Không xác định được truyện.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 3. Hiển thị nút back trong ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 4. Tải thông tin truyện
        loadStoryInfo(storyId);

        // 5. Kiểm tra chế độ: Sửa hay Thêm
        if (chapterId != -1) {
            loadChapterData(chapterId);
            tvChapterMode.setText("Sửa Chương");
            setTitle("Sửa Chương");
        } else {
            tvChapterMode.setText("Thêm Chương Mới");
            setTitle("Thêm Chương Mới");
        }

        // 6. Thiết lập Listener cho thay đổi nội dung
        setupContentWatcher();

        // 7. Thiết lập Listener cho nút
        btnSaveChapter.setOnClickListener(v -> saveChapter());
        btnCancelChapter.setOnClickListener(v -> onCancelClick());
        btnBackChapter.setOnClickListener(v -> onCancelClick());

        // 8. Thiết lập OnBackPressedDispatcher
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onCancelClick();
            }
        });
    }

    /**
     * Tải thông tin truyện để hiển thị tiêu đề
     */
    private void loadStoryInfo(int id) {
        Story story = storyController.getStoryById(id);
        if (story != null) {
            tvStoryTitle.setText("Truyện: " + story.getTitle());
        } else {
            tvStoryTitle.setText("Không tìm thấy thông tin truyện");
        }
    }

    /**
     * Tải dữ liệu chương nếu đang ở chế độ sửa.
     */
    private void loadChapterData(int id) {
        Chapter chapter = chapterController.getChapterById(id);
        if (chapter != null) {
            etChapterTitle.setText(chapter.getTitle());
            etChapterContent.setText(chapter.getContent());
            etChapterOrder.setText(String.valueOf(chapter.getOrderIndex()));
            updateContentInfo();
        } else {
            Toast.makeText(this, "Không tìm thấy chương để sửa.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Thiết lập TextWatcher để theo dõi thay đổi nội dung
     */
    private void setupContentWatcher() {
        etChapterContent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateContentInfo();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    /**
     * Cập nhật thông tin về số lượng ký tự
     */
    private void updateContentInfo() {
        int currentLength = etChapterContent.getText().toString().length();
        int maxLength = 50000;
        tvContentInfo.setText(currentLength + " ký tự / " + maxLength + " ký tự");
    }
    private void saveChapter() {
        String title = etChapterTitle.getText().toString().trim();
        String content = etChapterContent.getText().toString().trim();
        String orderText = etChapterOrder.getText().toString().trim();

        // Kiểm tra validation cơ bản
        if (TextUtils.isEmpty(title)) {
            etChapterTitle.setError("Vui lòng nhập tiêu đề chương");
            return;
        }

        if (TextUtils.isEmpty(content)) {
            etChapterContent.setError("Vui lòng nhập nội dung chương");
            return;
        }

        if (TextUtils.isEmpty(orderText)) {
            etChapterOrder.setError("Vui lòng nhập số thứ tự chương");
            return;
        }

        int orderIndex;
        try {
            orderIndex = Integer.parseInt(orderText);
            if (orderIndex <= 0) {
                etChapterOrder.setError("Số thứ tự phải lớn hơn 0");
                return;
            }
        } catch (NumberFormatException e) {
            etChapterOrder.setError("Số thứ tự không hợp lệ");
            return;
        }

        if (content.length() < 10) {
            etChapterContent.setError("Nội dung chương phải có ít nhất 10 ký tự");
            return;
        }

        // Lưu dữ liệu
        if (chapterId == -1) {
            // Chế độ THÊM MỚI
            Chapter newChapter = new Chapter(storyId, title, content, orderIndex);
            long id = chapterController.addChapter(newChapter);
            if (id > 0) {
                Toast.makeText(this, "Thêm chương mới thành công!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Lỗi: Có thể số thứ tự chương bị trùng hoặc lỗi cơ sở dữ liệu.", Toast.LENGTH_LONG).show();
            }
        } else {
            // Chế độ CẬP NHẬT (Sửa)
            Chapter updatedChapter = new Chapter(chapterId, storyId, title, content, orderIndex);
            boolean success = chapterController.updateChapter(updatedChapter);
            if (success) {
                Toast.makeText(this, "Cập nhật chương thành công!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Lỗi khi cập nhật chương.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void onCancelClick() {
        // Kiểm tra xem có dữ liệu thay đổi không
        String title = etChapterTitle.getText().toString().trim();
        String content = etChapterContent.getText().toString().trim();
        String order = etChapterOrder.getText().toString().trim();

        // Nếu có dữ liệu, hỏi xác nhận trước khi quay lại
        if (!TextUtils.isEmpty(title) || !TextUtils.isEmpty(content) || !TextUtils.isEmpty(order)) {
            new AlertDialog.Builder(this)
                    .setTitle("Xác nhận Hủy")
                    .setMessage("Bạn có dữ liệu chưa lưu. Bạn có chắc chắn muốn thoát?")
                    .setPositiveButton("Thoát", (dialog, which) -> finish())
                    .setNegativeButton("Tiếp tục soạn", null)
                    .show();
        } else {
            finish();
        }
    }
    @Override
    public boolean onSupportNavigateUp() {
        onCancelClick();
        return true;
    }
}