package com.example.doctruyenver2app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;

import com.example.doctruyenver2app.View.Admin.AdminDashboardActivity;
import com.example.doctruyenver2app.View.User.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Chuyển sang LoginActivity thay vì setContentView
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);

        // Đóng MainActivity
        finish();
    }
}