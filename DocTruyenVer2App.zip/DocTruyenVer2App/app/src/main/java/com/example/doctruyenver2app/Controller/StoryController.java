package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Story;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

// Import các hằng số từ DatabaseHelper
import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class StoryController {
    private static final String TAG = "StoryController";
    private DatabaseHelper dbHelper;

    // =========================================================
    // =============== ENUM KẾT QUẢ THAO TÁC ===================
    // =========================================================

    public enum StoryAddResult {
        SUCCESS,
        TITLE_AUTHOR_ALREADY_EXISTS, // Đổi ý nghĩa thành "Tiêu đề đã tồn tại"
        ERROR
    }

    public enum StoryUpdateResult {
        SUCCESS,
        TITLE_AUTHOR_ALREADY_EXISTS, // Đổi ý nghĩa thành "Tiêu đề đã tồn tại"
        NOT_FOUND,
        ERROR
    }


    public StoryController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // =========================================================
    // =============== HÀM TIỆN ÍCH CHUẨN HÓA ==================
    // =========================================================

    /**
     * Loại bỏ dấu tiếng Việt (chuẩn hóa) và chuyển về chữ thường.
     * Dùng cho mục đích tìm kiếm linh hoạt (accent-insensitive).
     */
    private String removeVietnameseAccents(String s) {
        if (s == null) return null;
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(temp).replaceAll("").toLowerCase();
    }


    // =========================================================
    // =============== 1. CREATE (Thêm Truyện) - ĐÃ CẬP NHẬT ==================
    // =========================================================

    /**
     * Thêm một truyện mới. Kiểm tra trùng lặp Tiêu đề (bắt buộc duy nhất).
     */
    public StoryAddResult addStory(Story story) {
        // KIỂM TRA TRÙNG LẶP TIÊU ĐỀ TRƯỚC
        if (isStoryExists(story.getTitle())) { // <-- CHỈ TRUYỀN TITLE
            Log.w(TAG, "Add failed: Story title already exists.");
            return StoryAddResult.TITLE_AUTHOR_ALREADY_EXISTS; // Sử dụng lại Enum này
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, story.getTitle());
        values.put(COLUMN_AUTHOR, story.getAuthor());
        values.put(COLUMN_DESCRIPTION, story.getDescription());
        values.put(COLUMN_COVER_URL, story.getCoverUrl());
        values.put(COLUMN_CREATED_BY, story.getCreatedBy());

        long result = db.insert(TABLE_STORIES, null, values);
        db.close();

        if (result > 0) {
            return StoryAddResult.SUCCESS;
        } else {
            return StoryAddResult.ERROR;
        }
    }

    // =========================================================
    // ================== 2. READ (Đọc Truyện) ==================
    // =========================================================

    /**
     * Lấy danh sách tất cả truyện.
     */
    public List<Story> getAllStories() {
        return getStoriesByQuery(null, null);
    }

    /**
     * Lấy chi tiết một truyện theo ID (READ - Single)
     */
    public Story getStoryById(int storyId) {
        // Thay vì dùng db.query đơn giản, ta dùng hàm getStoriesByQuery
        // để lấy luôn ChapterCount và CategoryNames đã được tính toán
        String whereClause = "s." + COLUMN_STORY_ID + " = ?";
        String[] whereArgs = {String.valueOf(storyId)};

        List<Story> list = getStoriesByQuery(whereClause, whereArgs);

        if (list != null && !list.isEmpty()) {
            return list.get(0); // Trả về truyện đầu tiên tìm thấy
        }
        return null;
    }

    // =========================================================
    // ================ 3. UPDATE (Cập nhật Truyện) - ĐÃ CẬP NHẬT =============
    // =========================================================

    /**
     * Cập nhật thông tin truyện. Kiểm tra trùng lặp Tiêu đề (bắt buộc duy nhất), loại trừ ID hiện tại.
     */
    public StoryUpdateResult updateStory(Story story) {
        // KIỂM TRA TRÙNG LẶP TIÊU ĐỀ (Loại trừ ID của chính truyện đang sửa)
        if (isStoryExistsExcludingId(story.getTitle(), story.getId())) { // <-- CHỈ TRUYỀN TITLE VÀ ID
            Log.w(TAG, "Update failed: Story title already exist for another story.");
            return StoryUpdateResult.TITLE_AUTHOR_ALREADY_EXISTS; // Sử dụng lại Enum này
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_TITLE, story.getTitle());
        values.put(COLUMN_AUTHOR, story.getAuthor());
        values.put(COLUMN_DESCRIPTION, story.getDescription());
        values.put(COLUMN_COVER_URL, story.getCoverUrl());
        values.put(COLUMN_CREATED_BY, story.getCreatedBy());

        int rows = db.update(TABLE_STORIES,
                values,
                COLUMN_STORY_ID + " = ?",
                new String[]{String.valueOf(story.getId())});
        db.close();

        if (rows > 0) {
            return StoryUpdateResult.SUCCESS;
        } else if (rows == 0) {
            return StoryUpdateResult.NOT_FOUND;
        } else {
            return StoryUpdateResult.ERROR;
        }
    }

    // =========================================================
    // ================= 4. DELETE (Xóa Truyện) =================
    // =========================================================

    /**
     * Xóa một truyện và tất cả dữ liệu liên quan.
     */
    public boolean deleteStory(int storyId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsDeleted = 0;

        db.beginTransaction();
        try {
            // 1. Xóa các mục Yêu thích liên quan
            db.delete(TABLE_FAVORITES, COLUMN_FAV_STORY_ID + " = ?", new String[]{String.valueOf(storyId)});

            // 2. Xóa các Bình luận liên quan
            db.delete(TABLE_COMMENTS, COLUMN_COMMENT_STORY_ID + " = ?", new String[]{String.valueOf(storyId)});

            // 3. XÓA LIÊN KẾT THỂ LOẠI
            db.delete(TABLE_STORY_CATEGORY, COLUMN_SC_STORY_ID + " = ?", new String[]{String.valueOf(storyId)});

            // 4. Xóa các Chương liên quan
            db.delete(TABLE_CHAPTERS, COLUMN_STORY_ID_FK + " = ?", new String[]{String.valueOf(storyId)});

            // 5. Xóa chính truyện
            rowsDeleted = db.delete(TABLE_STORIES, COLUMN_STORY_ID + " = ?", new String[]{String.valueOf(storyId)});

            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error deleting story: " + e.getMessage());
        } finally {
            db.endTransaction();
            db.close();
        }
        return rowsDeleted > 0;
    }

    // =========================================================
    // =============== 5. KIỂM TRA TRÙNG LẶP - ĐÃ THAY ĐỔI LOGIC ===================
    // =========================================================

    /**
     * Kiểm tra xem đã tồn tại truyện có cùng Tiêu đề chưa (Không cần quan tâm Tác giả).
     * Dùng cho chức năng THÊM MỚI.
     */
    public boolean isStoryExists(String title) { // <-- CHỈ CẦN TITLE
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        // CHỈ KIỂM TRA TRÙNG LẶP TIÊU ĐỀ
        String selectQuery = "SELECT 1 FROM " + TABLE_STORIES +
                " WHERE " + COLUMN_TITLE + " = ? COLLATE NOCASE";

        try {
            cursor = db.rawQuery(selectQuery, new String[]{title});

            if (cursor != null && cursor.getCount() > 0) {
                exists = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking story existence by title: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return exists;
    }

    /**
     * Kiểm tra trùng lặp Tiêu đề, loại trừ ID của truyện đang được chỉnh sửa.
     * Dùng cho chức năng CẬP NHẬT.
     */
    public boolean isStoryExistsExcludingId(String title, int storyIdToExclude) { // <-- CHỈ CẦN TITLE VÀ ID
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        // CHỈ KIỂM TRA TRÙNG LẶP TIÊU ĐỀ, LOẠI TRỪ ID
        String selectQuery = "SELECT 1 FROM " + TABLE_STORIES +
                " WHERE " + COLUMN_TITLE + " = ? COLLATE NOCASE" +
                " AND " + COLUMN_STORY_ID + " != ?";

        try {
            cursor = db.rawQuery(selectQuery, new String[]{title, String.valueOf(storyIdToExclude)});

            if (cursor != null && cursor.getCount() > 0) {
                exists = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking story existence excluding ID by title: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return exists;
    }


    // =========================================================
    // ================== 6. SEARCH (Tìm kiếm) ==================
    // =========================================================

    /**
     * Tìm kiếm truyện theo Tiêu đề và Tác giả KHÔNG PHÂN BIỆT DẤU.
     * Sử dụng phương pháp lọc Java trên dữ liệu đã được lấy ra.
     * @param keyword Chuỗi tìm kiếm (có thể có dấu hoặc không dấu).
     * @return Danh sách Story khớp với truy vấn.
     */
    public List<Story> searchStories(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllStories();
        }

        // Lấy tất cả (vì SQLite không có hàm loại bỏ dấu tích hợp)
        List<Story> allStories = getStoriesByQuery(null, null);
        final String finalNormalizedQuery = removeVietnameseAccents(keyword.trim());

        // Lọc bằng Java
        List<Story> filteredList = new ArrayList<>();
        for (Story story : allStories) {
            String normalizedTitle = removeVietnameseAccents(story.getTitle());
            String normalizedAuthor = removeVietnameseAccents(story.getAuthor());

            // So sánh không dấu trên cả tiêu đề và tác giả
            if ((normalizedTitle != null && normalizedTitle.contains(finalNormalizedQuery)) ||
                    (normalizedAuthor != null && normalizedAuthor.contains(finalNormalizedQuery))) {
                filteredList.add(story);
            }
        }
        return filteredList;
    }

    // =========================================================
    // =============== HÀM CHUNG LẤY DANH SÁCH ==================
    // =========================================================

    /**
     * Hàm chung thực hiện truy vấn phức tạp để lấy thông tin đầy đủ cho Adapter.
     * Sử dụng ALIAS đơn giản cho GROUP_CONCAT và COUNT(*) để tránh lỗi truy xuất Cursor.
     * @param whereClause Điều kiện WHERE (hoặc null nếu muốn lấy tất cả).
     * @param whereArgs Các tham số cho điều kiện WHERE (nếu có).
     * @return Danh sách Story với CategoryName và ChapterCount.
     */
    private List<Story> getStoriesByQuery(String whereClause, String[] whereArgs) {
        List<Story> storyList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;

        // CÁC CỘT CẦN THIẾT TỪ BẢNG STORIES
        String storyColumns = "s." + COLUMN_STORY_ID + ", s." + COLUMN_TITLE + ", s." + COLUMN_AUTHOR + ", s." + COLUMN_DESCRIPTION + ", s." + COLUMN_COVER_URL + ", s." + COLUMN_CREATED_BY;

        // TRUY VẤN COUNT CHAPTERS (Dùng Subquery) -> Dùng ALIAS: ChapterCount
        String chapterCountQuery = "(SELECT COUNT(*) FROM " + TABLE_CHAPTERS + " WHERE " + COLUMN_STORY_ID_FK + " = s." + COLUMN_STORY_ID + ") AS ChapterCount";

        // TRUY VẤN CATEGORY (Dùng GROUP_CONCAT) -> Dùng ALIAS: CategoryNames
        String categoryNameQuery = "GROUP_CONCAT(c." + COLUMN_CATEGORY_NAME + ") AS CategoryNames";

        // Xây dựng câu truy vấn chính
        String query = "SELECT " + storyColumns + ", " + categoryNameQuery + ", " + chapterCountQuery + " " +
                "FROM " + TABLE_STORIES + " s " +
                // JOIN với bảng liên kết và bảng Category
                "LEFT JOIN " + TABLE_STORY_CATEGORY + " sc ON s." + COLUMN_STORY_ID + " = sc." + COLUMN_SC_STORY_ID + " " +
                "LEFT JOIN " + TABLE_CATEGORIES + " c ON sc." + COLUMN_SC_CATEGORY_ID + " = c." + COLUMN_CATEGORY_ID + " ";

        // Thêm điều kiện tìm kiếm nếu có
        if (whereClause != null && !whereClause.isEmpty()) {
            query += "WHERE " + whereClause + " ";
        }

        // Bắt buộc GROUP BY để GROUP_CONCAT hoạt động
        query += "GROUP BY s." + COLUMN_STORY_ID + " ORDER BY s." + COLUMN_STORY_ID + " DESC";

        try {
            cursor = db.rawQuery(query, whereArgs);

            if (cursor.moveToFirst()) {
                // Lấy index các cột TỪ TÊN ALIAS (an toàn hơn)
                int idIndex = cursor.getColumnIndexOrThrow(COLUMN_STORY_ID);
                int titleIndex = cursor.getColumnIndexOrThrow(COLUMN_TITLE);
                int authorIndex = cursor.getColumnIndexOrThrow(COLUMN_AUTHOR);
                int descIndex = cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION);
                int coverIndex = cursor.getColumnIndexOrThrow(COLUMN_COVER_URL);
                int createdByIndex = cursor.getColumnIndexOrThrow(COLUMN_CREATED_BY);
                int categoryIndex = cursor.getColumnIndexOrThrow("CategoryNames");
                int chapterCountIndex = cursor.getColumnIndexOrThrow("ChapterCount");

                do {
                    Story story = new Story(
                            cursor.getInt(idIndex),   // ID
                            cursor.getString(titleIndex), // TITLE
                            cursor.getString(authorIndex), // AUTHOR
                            cursor.getString(descIndex), // DESCRIPTION
                            cursor.getString(coverIndex), // COVER_URL
                            cursor.getInt(createdByIndex),    // CREATED_BY
                            cursor.getString(categoryIndex), // CATEGORY_NAME (GROUP_CONCAT)
                            cursor.getInt(chapterCountIndex)     // CHAPTER_COUNT
                    );
                    storyList.add(story);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error executing getStoriesByQuery: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return storyList;
    }

    // Thêm vào class StoryController

    /**
     * Lấy truyện theo Tiêu đề (dùng khi vừa thêm mới để lấy ID)
     */
    public Story getStoryByTitle(String title) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Story story = null;
        Cursor c = null;

        try {
            c = db.query(TABLE_STORIES,
                    null,
                    COLUMN_TITLE + " = ? COLLATE NOCASE",
                    new String[]{title},
                    null, null, null);

            if (c.moveToFirst()) {
                story = new Story(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_STORY_ID)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_TITLE)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_AUTHOR)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_DESCRIPTION)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_COVER_URL)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CREATED_BY))
                );
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting story by title: " + e.getMessage());
        } finally {
            if (c != null) c.close();
            db.close();
        }
        return story;
    }

    // Thêm method này vào class StoryController

    /**
     * Lấy tất cả truyện thuộc một danh mục cụ thể.
     * @param categoryId ID của danh mục
     * @return Danh sách Story thuộc danh mục đó
     */
    public List<Story> getStoriesByCategoryId(int categoryId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Story> storyList = new ArrayList<>();
        Cursor cursor = null;

        // SQL JOIN: Lấy truyện từ bảng STORY_CATEGORY
        String query = "SELECT DISTINCT s." + COLUMN_STORY_ID + ", s." + COLUMN_TITLE +
                ", s." + COLUMN_AUTHOR + ", s." + COLUMN_DESCRIPTION + ", s." + COLUMN_COVER_URL +
                ", s." + COLUMN_CREATED_BY + " " +
                "FROM " + TABLE_STORIES + " s " +
                "INNER JOIN " + TABLE_STORY_CATEGORY + " sc ON s." + COLUMN_STORY_ID +
                " = sc." + COLUMN_SC_STORY_ID + " " +
                "WHERE sc." + COLUMN_SC_CATEGORY_ID + " = ? " +
                "ORDER BY s." + COLUMN_STORY_ID + " DESC";

        try {
            cursor = db.rawQuery(query, new String[]{String.valueOf(categoryId)});

            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndexOrThrow(COLUMN_STORY_ID);
                int titleIndex = cursor.getColumnIndexOrThrow(COLUMN_TITLE);
                int authorIndex = cursor.getColumnIndexOrThrow(COLUMN_AUTHOR);
                int descIndex = cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION);
                int coverIndex = cursor.getColumnIndexOrThrow(COLUMN_COVER_URL);
                int createdByIndex = cursor.getColumnIndexOrThrow(COLUMN_CREATED_BY);

                do {
                    Story story = new Story(
                            cursor.getInt(idIndex),
                            cursor.getString(titleIndex),
                            cursor.getString(authorIndex),
                            cursor.getString(descIndex),
                            cursor.getString(coverIndex),
                            cursor.getInt(createdByIndex)
                    );
                    storyList.add(story);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting stories by category ID: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }

        return storyList;
    }
}