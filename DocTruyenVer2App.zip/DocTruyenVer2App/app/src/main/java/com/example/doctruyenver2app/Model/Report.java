package com.example.doctruyenver2app.Model;

public class Report {
    private int id;
    private int reporterId; // ID người báo cáo (User)
    private int reportedCommentId; // ID bình luận bị báo cáo
    private String reason; // Lý do báo cáo
    private String createdAt;

    // Thuộc tính hỗ trợ hiển thị (Không nằm trong bảng Report, dùng JOIN/View)
    private String reporterUsername;
    private String commentContent;

    public Report() {}

    // Constructor đầy đủ (Lấy từ DB, có thông tin JOIN)
    public Report(int id, int reporterId, int reportedCommentId, String reason, String createdAt, String reporterUsername, String commentContent) {
        this.id = id;
        this.reporterId = reporterId;
        this.reportedCommentId = reportedCommentId;
        this.reason = reason;
        this.createdAt = createdAt;
        this.reporterUsername = reporterUsername;
        this.commentContent = commentContent;
    }

    // Constructor thêm mới (chỉ cần ID liên quan và lý do)
    public Report(int reporterId, int reportedCommentId, String reason) {
        this.reporterId = reporterId;
        this.reportedCommentId = reportedCommentId;
        this.reason = reason;
    }

    // =========================================================
    //                            Getter & Setter
    // =========================================================

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getReporterId() { return reporterId; }
    public void setReporterId(int reporterId) { this.reporterId = reporterId; }

    public int getReportedCommentId() { return reportedCommentId; }
    public void setReportedCommentId(int reportedCommentId) { this.reportedCommentId = reportedCommentId; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    // Getters/Setters cho thuộc tính hỗ trợ hiển thị (dùng trong ReportAdapter)
    public String getReporterUsername() { return reporterUsername; }
    public void setReporterUsername(String reporterUsername) { this.reporterUsername = reporterUsername; }

    public String getCommentContent() { return commentContent; }
    public void setCommentContent(String commentContent) { this.commentContent = commentContent; }
}