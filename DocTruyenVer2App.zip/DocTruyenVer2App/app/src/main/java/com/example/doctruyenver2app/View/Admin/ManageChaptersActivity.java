package com.example.doctruyenver2app.View.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View; // Import cần thiết cho View.OnClickListener
import android.widget.ImageButton; // Import cần thiết cho ImageButton
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.example.doctruyenver2app.Adapter.Admin.ChapterAdapter;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Controller.ChapterController;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.R;

import java.util.ArrayList;
import java.util.List;

public class ManageChaptersActivity extends AppCompatActivity
        implements ChapterAdapter.OnChapterActionListener {

    private static final String TAG = "ManageChaptersActivity";

    private int storyId = -1;
    private Story story; // Dùng để hiển thị tên truyện

    private TextView tvStoryTitle;
    private RecyclerView rvChapters;
    private FloatingActionButton fabAddChapter;
    private ImageButton btnBack; // ⭐ THÀNH PHẦN MỚI: Nút Back tùy chỉnh

    private ChapterController chapterController;
    private StoryController storyController;
    private ChapterAdapter chapterAdapter;
    private List<Chapter> chapterList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_chapters);

        chapterController = new ChapterController(this);
        storyController = new StoryController(this);
        chapterList = new ArrayList<>();

        // 1. Lấy Story ID từ Intent
        storyId = getIntent().getIntExtra("STORY_ID", -1);

        // 2. Ánh xạ Views
        tvStoryTitle = findViewById(R.id.tv_story_title_chapters);
        rvChapters = findViewById(R.id.rv_chapters_list);
        fabAddChapter = findViewById(R.id.fab_add_chapter);
        btnBack = findViewById(R.id.btn_back_chapters); // ⭐ Ánh xạ ImageButton

        if (storyId != -1) {
            loadStoryInfo(storyId);
        } else {
            Toast.makeText(this, "Lỗi: Không tìm thấy ID truyện.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // 3. Cấu hình hành vi Back (KHÔNG DÙNG getSupportActionBar)

        // 3a. Thiết lập OnClickListener cho ImageButton Back
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToManageStories();
            }
        });

        // 3b. Thiết lập OnBackPressedDispatcher (thay thế onBackPressed)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                navigateToManageStories();
            }
        });

        // 4. Cấu hình RecyclerView
        chapterAdapter = new ChapterAdapter(this, chapterList, this);
        rvChapters.setLayoutManager(new LinearLayoutManager(this));
        rvChapters.setAdapter(chapterAdapter);

        // 5. Thiết lập Listener cho FAB
        fabAddChapter.setOnClickListener(v -> {
            // Chuyển đến Activity Thêm/Sửa Chương
            Intent intent = new Intent(this, AddEditChapterActivity.class);
            intent.putExtra("STORY_ID", storyId); // Truyền Story ID để biết chương thuộc truyện nào
            startActivity(intent);
        });

        // 6. Tải dữ liệu
        loadChapters();
    }

    private void loadStoryInfo(int id) {
        story = storyController.getStoryById(id);
        if (story != null) {
            // ⭐ Dùng TextView để hiển thị tiêu đề, không dùng setTitle() của ActionBar
            tvStoryTitle.setText("Quản lý Chương: " + story.getTitle());
        } else {
            Toast.makeText(this, "Không tìm thấy thông tin truyện.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private void loadChapters() {
        if (storyId != -1) {
            List<Chapter> chapters = chapterController.getChaptersByStory(storyId);
            chapterAdapter.updateList(chapters);
            Log.d(TAG, "Loaded " + chapters.size() + " chapters for Story ID: " + storyId);
        }
    }

    // =========================================================
    // =============== Xử lý sự kiện nút Back ==================
    // =========================================================

    /**
     * Xử lý sự kiện nút Back trong ActionBar (ĐÃ BỊ LOẠI BỎ DO KHÔNG DÙNG TOOLBAR)
     * Thay thế bằng btnBack.setOnClickListener()
     */
    // @Override
    // public boolean onSupportNavigateUp() {
    //     navigateToManageStories();
    //     return true;
    // }

    /**
     * Hàm riêng để navigate quay lại ManageStoriesActivity
     */
    private void navigateToManageStories() {
        Intent intent = new Intent(this, ManageStoriesActivity.class);
        startActivity(intent);
        finish();
    }

    // =========================================================
    // =============== TRIỂN KHAI LISTENER CỦA ADAPTER ============
    // =========================================================

    @Override
    public void onEditClick(Chapter chapter) {
        // Chuyển đến Activity Thêm/Sửa Chương để sửa
        Intent intent = new Intent(this, AddEditChapterActivity.class);
        intent.putExtra("STORY_ID", storyId);
        intent.putExtra("CHAPTER_ID", chapter.getId()); // Truyền ID Chương để biết là chế độ Sửa
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(Chapter chapter) {
        new AlertDialog.Builder(this)
                .setTitle("Xác nhận Xóa Chương")
                .setMessage("Bạn có chắc chắn muốn xóa '" + chapter.getTitle() + "' không?")
                .setPositiveButton("Xóa", (dialog, which) -> {
                    performDeleteChapter(chapter);
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void performDeleteChapter(Chapter chapter) {
        boolean isDeleted = chapterController.deleteChapter(chapter.getId());
        if (isDeleted) {
            Toast.makeText(this, "Đã xóa chương: " + chapter.getTitle(), Toast.LENGTH_SHORT).show();
            loadChapters(); // Tải lại danh sách sau khi xóa
        } else {
            Toast.makeText(this, "Lỗi: Không thể xóa chương.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Tải lại danh sách khi quay lại từ màn hình Thêm/Sửa chương
        loadChapters();
    }
}