package com.example.doctruyenver2app.View.Admin;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import com.example.doctruyenver2app.Adapter.Admin.CategorySelectAdapter;
import com.example.doctruyenver2app.Controller.CategoryController;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Category;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.doctruyenver2app.Controller.StoryController.StoryAddResult;
import com.example.doctruyenver2app.Controller.StoryController.StoryUpdateResult;

public class AddEditStoryActivity extends AppCompatActivity {

    private static final String TAG = "AddEditStoryActivity";

    private EditText etTitle, etAuthor, etDescription, etCoverUrl;
    private Button btnSave, btnBack;
    private TextView tvStoryMode, tvCategoryEmpty;
    private RecyclerView recyclerCategories;

    private StoryController storyController;
    private CategoryController categoryController;
    private CategorySelectAdapter categoryAdapter;

    private int storyId = -1;
    private Set<Integer> selectedCategoryIds = new HashSet<>();

    private static final int CURRENT_ADMIN_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_story);

        storyController = new StoryController(this);
        categoryController = new CategoryController(this);

        // 1. Ánh xạ Views
        initializeViews();

        // 2. Thiết lập RecyclerView cho Category
        setupCategoryRecyclerView();

        // 3. Kiểm tra chế độ Edit hay Add
        if (getIntent().hasExtra("STORY_ID")) {
            storyId = getIntent().getIntExtra("STORY_ID", -1);
            loadStoryData(storyId);
            tvStoryMode.setText("Sửa Truyện");
        } else {
            tvStoryMode.setText("Thêm Truyện Mới");
        }

        // 4. Thiết lập Listeners
        setupListeners();
    }

    /**
     * Ánh xạ tất cả Views
     */
    private void initializeViews() {
        etTitle = findViewById(R.id.et_story_title);
        etAuthor = findViewById(R.id.et_story_author);
        etDescription = findViewById(R.id.et_story_description);
        etCoverUrl = findViewById(R.id.et_story_cover_url);
        btnSave = findViewById(R.id.btn_save_story);
        btnBack = findViewById(R.id.btn_back_story);
        tvStoryMode = findViewById(R.id.tv_story_mode);
        recyclerCategories = findViewById(R.id.recycler_categories_select);
        tvCategoryEmpty = findViewById(R.id.tv_category_empty);
    }

    /**
     * ✅ FIX: Dùng GridLayoutManager 2 cột + measure height tính toán 3 hàng
     * Điều chỉnh RecyclerView height để vừa 3 hàng (6 items = 11 chia 2 cột)
     */
    private void setupCategoryRecyclerView() {
        List<Category> categories = categoryController.getAllCategories();

        if (categories == null || categories.isEmpty()) {
            recyclerCategories.setVisibility(View.GONE);
            tvCategoryEmpty.setVisibility(View.VISIBLE);
            return;
        }

        recyclerCategories.setVisibility(View.VISIBLE);
        tvCategoryEmpty.setVisibility(View.GONE);

        // ✅ GridLayoutManager 2 cột
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2);
        recyclerCategories.setLayoutManager(gridLayoutManager);

        // ✅ Set nested scrolling false
        recyclerCategories.setNestedScrollingEnabled(false);
        recyclerCategories.setHasFixedSize(false);

        // Tạo adapter
        categoryAdapter = new CategorySelectAdapter(categories, selectedCategoryIds);
        recyclerCategories.setAdapter(categoryAdapter);

        // ✅ QUAN TRỌNG: Set fixed height cho RecyclerView
        // Tính toán: 11 items / 2 cột = 6 hàng (làm tròn)
        // Mỗi item ~56dp (48dp + padding), 6 hàng = 336dp + padding
        ViewGroup.LayoutParams params = recyclerCategories.getLayoutParams();
        params.height = 400; // ✅ 400dp để vừa đúng 3 hàng đầu tiên + phần lớn hàng 4
        recyclerCategories.setLayoutParams(params);

        categoryAdapter.notifyDataSetChanged();
    }

    /**
     * Thiết lập các event listeners
     */
    private void setupListeners() {
        btnSave.setOnClickListener(v -> saveStory());
        btnBack.setOnClickListener(v -> finish());
    }

    /**
     * Tải dữ liệu truyện khi ở chế độ Edit
     */
    private void loadStoryData(int id) {
        Story story = storyController.getStoryById(id);
        if (story != null) {
            etTitle.setText(story.getTitle());
            etAuthor.setText(story.getAuthor());
            etDescription.setText(story.getDescription());
            etCoverUrl.setText(story.getCoverUrl());

            // ✅ Tải danh mục của truyện
            List<Category> storyCategories = categoryController.getCategoriesForStory(id);
            if (storyCategories != null && !storyCategories.isEmpty()) {
                selectedCategoryIds.clear();
                for (Category cat : storyCategories) {
                    selectedCategoryIds.add(cat.getId());
                }
            }

            // ✅ Cập nhật adapter NGAY SAU KHI load dữ liệu
            if (categoryAdapter != null) {
                categoryAdapter.updateSelectedCategories(selectedCategoryIds);
            }
        } else {
            Toast.makeText(this, "Không tìm thấy truyện.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Lưu truyện mới hoặc cập nhật truyện cũ
     */
    private void saveStory() {
        String title = etTitle.getText().toString().trim();
        String author = etAuthor.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String coverUrl = etCoverUrl.getText().toString().trim();

        // ✅ Validation
        if (TextUtils.isEmpty(title)) {
            etTitle.setError("Vui lòng nhập tiêu đề");
            return;
        }

        if (TextUtils.isEmpty(author)) {
            etAuthor.setError("Vui lòng nhập tác giả");
            return;
        }

        if (TextUtils.isEmpty(description)) {
            etDescription.setError("Vui lòng nhập mô tả");
            return;
        }

        if (selectedCategoryIds.isEmpty()) {
            Toast.makeText(this, "Vui lòng chọn ít nhất một danh mục.", Toast.LENGTH_SHORT).show();
            return;
        }

        // ✅ Thêm truyện mới
        if (storyId == -1) {
            Story newStory = new Story(title, author, description, coverUrl, CURRENT_ADMIN_ID);
            StoryAddResult result = storyController.addStory(newStory);

            if (result == StoryAddResult.SUCCESS) {
                Story addedStory = storyController.getStoryByTitle(title);
                if (addedStory != null) {
                    saveCategoryLinks(addedStory.getId());
                    Toast.makeText(this, "✅ Thêm truyện thành công!", Toast.LENGTH_SHORT).show();
                    finish();
                }
            } else if (result == StoryAddResult.TITLE_AUTHOR_ALREADY_EXISTS) {
                Toast.makeText(this, "❌ Tiêu đề và tác giả này đã tồn tại.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "❌ Lỗi thêm truyện.", Toast.LENGTH_SHORT).show();
            }
        }
        // ✅ Cập nhật truyện cũ
        else {
            Story updatedStory = new Story(storyId, title, author, description, coverUrl, CURRENT_ADMIN_ID);
            StoryUpdateResult result = storyController.updateStory(updatedStory);

            if (result == StoryUpdateResult.SUCCESS) {
                clearCategoryLinks(storyId);
                saveCategoryLinks(storyId);
                Toast.makeText(this, "✅ Cập nhật truyện thành công!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "❌ Lỗi cập nhật truyện.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Lưu các liên kết giữa Truyện và Danh Mục
     */
    private void saveCategoryLinks(int storyId) {
        for (int categoryId : selectedCategoryIds) {
            categoryController.linkStoryToCategory(storyId, categoryId);
        }
    }

    /**
     * Xóa các liên kết cũ giữa Truyện và Danh Mục
     */
    private void clearCategoryLinks(int storyId) {
        List<Category> oldCategories = categoryController.getCategoriesForStory(storyId);
        if (oldCategories != null && !oldCategories.isEmpty()) {
            for (Category cat : oldCategories) {
                categoryController.unlinkStoryFromCategory(storyId, cat.getId());
            }
        }
    }
}