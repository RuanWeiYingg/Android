package com.example.doctruyenver2app.Adapter.User;

import android.graphics.Color; // Dòng này cực kỳ quan trọng để sửa lỗi "Color"
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.Category;
import com.example.doctruyenver2app.R;

import java.util.List;

/**
 * Adapter hiển thị danh mục thể loại.
 * Sử dụng layout item_category_chip.xml (CardView + TextView).
 */
public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    private List<Category> categoryList;
    private OnCategoryClickListener listener;
    private int selectedCategoryId = -1; // Lưu trữ ID đang được chọn

    public interface OnCategoryClickListener {
        void onCategoryClick(Category category);
        void onClearFilter();
    }

    public CategoryAdapter(List<Category> categoryList, OnCategoryClickListener listener) {
        this.categoryList = categoryList;
        this.listener = listener;
    }

    /**
     * Cập nhật trạng thái chọn từ bên ngoài (ví dụ khi reset filter)
     */
    public void setSelectedCategory(int categoryId) {
        this.selectedCategoryId = categoryId;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Đảm bảo tên file layout là item_category_chip.xml
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_chip, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category category = categoryList.get(position);

        holder.textCategoryName.setText(category.getName());

        // LOGIC HIGHLIGHT: Thay đổi màu sắc dựa trên trạng thái được chọn
        if (selectedCategoryId == category.getId()) {
            // Khi được chọn: Nền Tím, Chữ Trắng
            holder.textCategoryName.setBackgroundColor(Color.parseColor("#6C5CE7"));
            holder.textCategoryName.setTextColor(Color.WHITE);
        } else {
            // Khi bình thường: Nền Xám nhạt, Chữ Đen/Xám đậm
            holder.textCategoryName.setBackgroundColor(Color.parseColor("#F0F2F5"));
            holder.textCategoryName.setTextColor(Color.parseColor("#2D3436"));
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                // Nếu click vào cái đang chọn thì có thể coi là hủy chọn (Optional)
                if (selectedCategoryId == category.getId()) {
                    selectedCategoryId = -1;
                    listener.onClearFilter();
                } else {
                    selectedCategoryId = category.getId();
                    listener.onCategoryClick(category);
                }
                notifyDataSetChanged(); // Vẽ lại danh sách để cập nhật màu sắc
            }
        });
    }

    @Override
    public int getItemCount() {
        return (categoryList != null) ? categoryList.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textCategoryName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ánh xạ ID text_category_name từ file item_category_chip.xml
            textCategoryName = itemView.findViewById(R.id.text_category_name);
        }
    }
}