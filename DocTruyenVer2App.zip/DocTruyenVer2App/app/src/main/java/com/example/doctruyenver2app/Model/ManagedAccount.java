package com.example.doctruyenver2app.Model;

public class ManagedAccount {

    public enum RoleType {
        ADMIN,
        USER
    }

    private int id;
    private String username;
    private String email;
    private RoleType role;

    public ManagedAccount(int id, String username, String email, RoleType role) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.role = role;
    }

    // Getter & Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public RoleType getRole() { return role; }
    public void setRole(RoleType role) { this.role = role; }
}