package com.example.doctruyenver2app.View.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

public class StoryInfoFragment extends Fragment {

    private int storyId = -1;
    private TextView tvDescription;
    private StoryController storyController;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            storyId = getArguments().getInt("STORY_ID", -1);
        }
        // Khởi tạo Controller để truy vấn database
        storyController = new StoryController(getContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_story_info, container, false);

        tvDescription = view.findViewById(R.id.tv_info_description);

        loadStoryInfo();

        return view;
    }

    private void loadStoryInfo() {
        if (storyId != -1) {
            Story story = storyController.getStoryById(storyId);

            if (story != null) {
                String content = story.getDescription();

                if (content != null && !content.isEmpty()) {
                    tvDescription.setText(content);
                } else {
                    tvDescription.setText("Nội dung tóm tắt đang được cập nhật...");
                }
            }
        } else {
            tvDescription.setText("Lỗi: Không tìm thấy ID truyện.");
        }
    }
    }
