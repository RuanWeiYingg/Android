package com.example.doctruyenver2app.Adapter.Admin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.Category;
import com.example.doctruyenver2app.R;

import java.util.List;
import java.util.Set;

public class CategorySelectAdapter extends RecyclerView.Adapter<CategorySelectAdapter.ViewHolder> {

    private List<Category> categoryList;
    private Set<Integer> selectedCategoryIds;

    public CategorySelectAdapter(List<Category> categoryList, Set<Integer> selectedCategoryIds) {
        this.categoryList = categoryList;
        this.selectedCategoryIds = selectedCategoryIds;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category_select, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category category = categoryList.get(position);


        holder.checkbox.setOnCheckedChangeListener(null);
        holder.tvCategoryName.setText(category.getName());
        boolean isSelected = selectedCategoryIds.contains(category.getId());
        holder.checkbox.setChecked(isSelected);
        holder.checkbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                selectedCategoryIds.add(category.getId());
            } else {
                selectedCategoryIds.remove(category.getId());
            }
        });
        holder.itemView.setOnClickListener(v -> {
            holder.checkbox.toggle();
        });
    }

    @Override
    public int getItemCount() {
        return categoryList != null ? categoryList.size() : 0;
    }

    public void updateSelectedCategories(Set<Integer> newSelectedIds) {
        this.selectedCategoryIds = newSelectedIds;
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedCategoryIds.clear();
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkbox;
        TextView tvCategoryName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            checkbox = itemView.findViewById(R.id.checkbox_category);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
        }
    }
}