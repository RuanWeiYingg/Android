package com.example.doctruyenver2app.View.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.SearchView; // Import cần thiết cho SearchView
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Controller.CategoryController;
import com.example.doctruyenver2app.Adapter.Admin.CategoryAdapter;
import com.example.doctruyenver2app.Model.Category;
import com.example.doctruyenver2app.R;
import java.util.ArrayList;
import java.util.List;

public class ManageCategoriesActivity extends AppCompatActivity
        implements CategoryAdapter.OnItemActionListener, SearchView.OnQueryTextListener { // <<< BỔ SUNG OnQueryTextListener

    private RecyclerView rvCategoriesList;
    private EditText etNewCategoryName;
    private SearchView svCategorySearch; // <<< THAY ĐỔI: Sử dụng SearchView
    private Button btnAddCategory;
    private Toolbar toolbar;

    private CategoryController categoryController;
    private CategoryAdapter categoryAdapter;
    private List<Category> categoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_categories);

        categoryController = new CategoryController(this);
        categoryList = new ArrayList<>();

        // 1. Ánh xạ các thành phần UI
        toolbar = findViewById(R.id.toolbar_categories);
        rvCategoriesList = findViewById(R.id.rv_categories_list);
        etNewCategoryName = findViewById(R.id.et_new_category_name);
        btnAddCategory = findViewById(R.id.btn_add_category);

        // <<< THAY ĐỔI: Ánh xạ SearchView theo ID mới >>>
        svCategorySearch = findViewById(R.id.sv_category_search);

        // =========================================================================
        //                 THIẾT LẬP NÚT BACK
        // =========================================================================

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // =========================================================================

        // 2. Cấu hình RecyclerView
        categoryAdapter = new CategoryAdapter(categoryList, this);
        rvCategoriesList.setLayoutManager(new LinearLayoutManager(this));
        rvCategoriesList.setAdapter(categoryAdapter);

        // 3. Tải dữ liệu ban đầu
        loadCategories();

        // 4. Thiết lập Listener cho nút Thêm mới
        btnAddCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewCategory();
            }
        });

        // =========================================================================
        //                 BỔ SUNG: THIẾT LẬP LISTENER CHO SEARCHVIEW
        // =========================================================================
        svCategorySearch.setOnQueryTextListener(this);
        // =========================================================================
    }

    // =========================================================================
    //                       TRIỂN KHAI PHƯƠNG THỨC SEARCHVIEW
    // =========================================================================

    @Override
    public boolean onQueryTextSubmit(String query) {
        // Có thể gọi filterCategories(query) ở đây nếu bạn chỉ muốn tìm kiếm khi nhấn Enter
        // Trong trường hợp này, ta sử dụng onQueryTextChange để tìm kiếm tức thời
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        // Kích hoạt tìm kiếm mỗi khi văn bản thay đổi
        filterCategories(newText);
        return false;
    }

    // =========================================================================
    //                 PHƯƠNG THỨC LỌC/TÌM KIẾM
    // =========================================================================

    /**
     * Thực hiện tìm kiếm danh mục và cập nhật RecyclerView.
     * Nếu chuỗi tìm kiếm rỗng, hiển thị toàn bộ danh sách.
     */
    private void filterCategories(String query) {
        List<Category> filteredList;

        if (TextUtils.isEmpty(query)) {
            // Nếu query rỗng, tải lại toàn bộ danh sách
            filteredList = categoryController.getAllCategories();
        } else {
            // Ngược lại, gọi phương thức searchCategoriesByName đã có trong Controller
            filteredList = categoryController.searchCategoriesByName(query);
        }

        // Cập nhật Adapter với danh sách lọc được
        categoryList.clear();
        categoryList.addAll(filteredList);
        // Giả định adapter có hàm updateCategoryList
        categoryAdapter.updateCategoryList(categoryList);
    }


    private void loadCategories() {
        // Tải tất cả danh mục từ Controller và cập nhật Adapter
        List<Category> allCategories = categoryController.getAllCategories();
        categoryList.clear();
        categoryList.addAll(allCategories);
        categoryAdapter.updateCategoryList(categoryList);
    }

    private void addNewCategory() {
        String categoryName = etNewCategoryName.getText().toString().trim();

        if (TextUtils.isEmpty(categoryName)) {
            Toast.makeText(this, "Tên thể loại không được để trống.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Kiểm tra trùng lặp
        if (categoryController.isCategoryNameExists(categoryName)) {
            Toast.makeText(this, "Thêm thất bại: Tên thể loại '" + categoryName + "' đã tồn tại.", Toast.LENGTH_LONG).show();
            return;
        }

        Category newCategory = new Category(categoryName);
        long newId = categoryController.addCategory(newCategory);

        if (newId != -1) {
            Toast.makeText(this, "Thêm thành công!", Toast.LENGTH_SHORT).show();
            etNewCategoryName.setText(""); // Xóa EditText

            // Sau khi thêm, tải lại danh sách
            loadCategories();
        } else {
            Toast.makeText(this, "Thêm thất bại. Vui lòng thử lại.", Toast.LENGTH_SHORT).show();
        }
    }

    // =========================================================================
    //                            TRIỂN KHAI LISTENER CỦA ADAPTER
    // =========================================================================

    @Override
    public void onEditClick(Category category) {
        showEditDialog(category);
    }

    @Override
    public void onDeleteClick(Category category) {
        showDeleteConfirmationDialog(category);
    }

    private void showEditDialog(Category category) {
        final EditText input = new EditText(this);
        input.setText(category.getName());

        new AlertDialog.Builder(this)
                .setTitle("Sửa Thể loại")
                .setView(input)
                .setPositiveButton("Lưu", (dialog, which) -> {
                    String newName = input.getText().toString().trim();

                    if (TextUtils.isEmpty(newName)) {
                        Toast.makeText(this, "Tên không được để trống!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Kích hoạt hàm SỬA trong Controller
                    Category updatedCategory = new Category(category.getId(), newName);
                    boolean success = categoryController.updateCategory(updatedCategory);

                    if (success) {
                        Toast.makeText(this, "Sửa thành công!", Toast.LENGTH_SHORT).show();
                        loadCategories(); // Tải lại danh sách
                    } else {
                        Toast.makeText(this, "Sửa thất bại (có thể tên trùng hoặc lỗi DB).", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showDeleteConfirmationDialog(Category category) {
        new AlertDialog.Builder(this)
                .setTitle("Xác nhận Xóa")
                .setMessage("Bạn có chắc chắn muốn xóa thể loại '" + category.getName() + "' không? (Lưu ý: Thao tác này sẽ xóa CẢ các liên kết đến truyện!)")
                .setPositiveButton("Xóa", (dialog, which) -> {

                    // Kích hoạt hàm XÓA trong Controller
                    boolean success = categoryController.deleteCategory(category.getId());

                    if (success) {
                        Toast.makeText(this, "Đã xóa thành công!", Toast.LENGTH_SHORT).show();
                        loadCategories(); // Tải lại danh sách
                    } else {
                        Toast.makeText(this, "Xóa thất bại (Kiểm tra Logcat).", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}