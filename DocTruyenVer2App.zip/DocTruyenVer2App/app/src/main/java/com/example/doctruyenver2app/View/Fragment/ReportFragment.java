package com.example.doctruyenver2app.View.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Adapter.Admin.ReportAdapter;
import com.example.doctruyenver2app.Controller.CommentController;
import com.example.doctruyenver2app.Controller.ReportController;
import com.example.doctruyenver2app.Model.Report;
import com.example.doctruyenver2app.R;

import java.util.List;

public class ReportFragment extends Fragment implements ReportAdapter.OnReportActionListener {

    private RecyclerView recyclerView;
    private TextView tvNoReports;
    private ReportAdapter adapter;
    private List<Report> reportList;
    private ReportController reportController;
    private CommentController commentController;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_report_list, container, false);

        recyclerView = view.findViewById(R.id.rv_report_list);
        tvNoReports = view.findViewById(R.id.tv_no_reports);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        reportController = new ReportController(getContext());
        commentController = new CommentController(getContext());

        loadReportData();

        return view;
    }

    private void loadReportData() {
        reportList = reportController.getAllReports();
        Log.d("ReportFragment", "Reports count: " + (reportList == null ? "null" : reportList.size()));

        if (reportList == null || reportList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            tvNoReports.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            tvNoReports.setVisibility(View.GONE);
            adapter = new ReportAdapter(getContext(), reportList, this);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public void onResolveReport(Report report) {
        boolean success = commentController.deleteComment(report.getReportedCommentId());
        if (success) {
            Toast.makeText(getContext(), "Da xoa binh luan vi pham!", Toast.LENGTH_SHORT).show();
            onIgnoreReport(report);
        }
    }

    @Override
    public void onIgnoreReport(Report report) {
        boolean success = reportController.deleteReport(report.getId());
        if (success) {
            int position = reportList.indexOf(report);
            if (position != -1) {
                reportList.remove(position);
                adapter.notifyItemRemoved(position);
                if (reportList.isEmpty()) {
                    recyclerView.setVisibility(View.GONE);
                    tvNoReports.setVisibility(View.VISIBLE);
                }
            }
        }
    }
}