package com.example.doctruyenver2app.View.Admin;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.View.Fragment.ReportFragment;

public class ManageReportsActivity extends AppCompatActivity {

    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_reports);

        btnBack = findViewById(R.id.btn_back_reports);
        btnBack.setOnClickListener(v -> finish());

        // Hiển thị ReportFragment trực tiếp
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new ReportFragment())
                    .commit();
        }
    }
}