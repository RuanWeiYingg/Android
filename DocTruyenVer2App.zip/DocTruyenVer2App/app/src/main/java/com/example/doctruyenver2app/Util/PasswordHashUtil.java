package com.example.doctruyenver2app.Util;

import android.util.Log;

public class PasswordHashUtil {
    private static final String TAG = "PasswordHashUtil";

    public static String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] messageDigest = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b));
            }
            String hash = sb.toString();
            Log.d(TAG, "Hashed password for: " + password.substring(0, Math.min(3, password.length())) + "***");
            return hash;
        } catch (Exception e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
            return password; // Fallback - không nên xảy ra
        }
    }

    /**
     * Xác minh mật khẩu gốc có khớp với hash không
     * @param rawPassword Mật khẩu gốc nhập vào
     * @param storedHash Hash đã lưu trong database
     * @return true nếu khớp, false nếu không
     */
    public static boolean verifyPassword(String rawPassword, String storedHash) {
        String computedHash = hashPassword(rawPassword);
        boolean matches = computedHash.equals(storedHash);
        Log.d(TAG, "Password verification result: " + (matches ? "MATCH" : "MISMATCH"));
        return matches;
    }
}