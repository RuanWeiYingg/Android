    package com.example.doctruyenver2app.View.Fragment;

    import android.os.Bundle;
    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.ProgressBar;
    import android.widget.TextView;
    import android.widget.Toast;

    import androidx.annotation.NonNull;
    import androidx.annotation.Nullable;
    import androidx.fragment.app.Fragment;
    import androidx.recyclerview.widget.LinearLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;

    import com.example.doctruyenver2app.Adapter.User.CommentAdapter;
    import com.example.doctruyenver2app.Controller.CommentController;
    import com.example.doctruyenver2app.Model.Comment;
    import com.example.doctruyenver2app.R;

    import java.text.SimpleDateFormat;
    import java.util.Date;
    import java.util.List;
    import java.util.Locale;

    public class CommentFragment extends Fragment {

        private static final String TAG = "CommentFragment";

        // Data
        private int storyId = -1;
        private int userId = -1;
        private String userName = "";

        // UI Components
        private EditText etCommentContent;
        private Button btnSubmitComment;
        private RecyclerView rvComments;
        private ProgressBar progressBar;
        private TextView tvNoComments;

        // Controller & Adapter
        private CommentController commentController;
        private CommentAdapter commentAdapter;

        /**
         * Factory method để tạo Fragment với các tham số
         */
        public static CommentFragment newInstance(int storyId, int userId, String userName) {
            CommentFragment fragment = new CommentFragment();
            Bundle args = new Bundle();
            args.putInt("STORY_ID", storyId);
            args.putInt("USER_ID", userId);
            args.putString("USER_NAME", userName);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            if (getArguments() != null) {
                storyId = getArguments().getInt("STORY_ID", -1);
                userId = getArguments().getInt("USER_ID", -1);
                userName = getArguments().getString("USER_NAME", "Anonymous");
            }

            // Khởi tạo Controller
            commentController = new CommentController(requireContext());
        }

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                                 @Nullable Bundle savedInstanceState) {
            return inflater.inflate(R.layout.fragment_comment, container, false);
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            initializeViews(view);
            setupRecyclerView();
            loadComments();

            btnSubmitComment.setOnClickListener(v -> submitComment());
        }

        private void initializeViews(View view) {
            etCommentContent = view.findViewById(R.id.et_comment_content);
            btnSubmitComment = view.findViewById(R.id.btn_submit_comment);
            rvComments = view.findViewById(R.id.rv_comments);
            progressBar = view.findViewById(R.id.progress_bar_comments);
            tvNoComments = view.findViewById(R.id.tv_no_comments);
        }

        private void setupRecyclerView() {
            rvComments.setLayoutManager(new LinearLayoutManager(requireContext()));

            // TRUYỀN 2 THAM SỐ: Context và userId của người đang đăng nhập
            commentAdapter = new CommentAdapter(requireContext(), userId);

            rvComments.setAdapter(commentAdapter);
        }

        private void loadComments() {
            if (storyId == -1) {
                tvNoComments.setText("Lỗi: Không tìm thấy ID truyện");
                return;
            }

            progressBar.setVisibility(View.VISIBLE);

            new Thread(() -> {
                try {
                    List<Comment> comments = commentController.getCommentsByStory(storyId);

                    if (getActivity() == null) return;

                    getActivity().runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);

                        if (comments != null && !comments.isEmpty()) {
                            tvNoComments.setVisibility(View.GONE);
                            rvComments.setVisibility(View.VISIBLE);

                            // Gọi hàm setComments từ Adapter mới cập nhật
                            commentAdapter.setComments(comments);
                        } else {
                            rvComments.setVisibility(View.GONE);
                            tvNoComments.setVisibility(View.VISIBLE);
                            tvNoComments.setText("Chưa có bình luận nào. Hãy là người đầu tiên!");
                        }
                    });
                } catch (Exception e) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            Toast.makeText(requireContext(), "Lỗi khi tải bình luận", Toast.LENGTH_SHORT).show();
                        });
                    }
                }
            }).start();
        }

        /**
         * Xử lý gửi bình luận mới
         */
        private void submitComment() {
            String content = etCommentContent.getText().toString().trim();

            if (content.isEmpty()) {
                Toast.makeText(requireContext(), "Vui lòng nhập nội dung bình luận", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userId == -1) {
                Toast.makeText(requireContext(), "Vui lòng đăng nhập để bình luận", Toast.LENGTH_SHORT).show();
                return;
            }

            // Tạo đối tượng Comment mới (storyId, userId, chapterId, content, time)
            Comment newComment = new Comment(
                    storyId,
                    userId,
                    0, // chapterId mặc định là 0
                    content,
                    getCurrentTimestamp()
            );

            new Thread(() -> {
                try {
                    long result = commentController.addComment(newComment);

                    if (getActivity() == null) return;

                    getActivity().runOnUiThread(() -> {
                        if (result > 0) {
                            Toast.makeText(requireContext(), "Bình luận đã được gửi", Toast.LENGTH_SHORT).show();
                            etCommentContent.setText("");
                            loadComments(); // Tải lại danh sách
                        } else {
                            Toast.makeText(requireContext(), "Không thể gửi bình luận", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    if (getActivity() != null) {
                        getActivity().runOnUiThread(() -> {
                            Toast.makeText(requireContext(), "Lỗi: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                    }
                }
            }).start();
        }

        private String getCurrentTimestamp() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            return sdf.format(new Date());
        }
    }