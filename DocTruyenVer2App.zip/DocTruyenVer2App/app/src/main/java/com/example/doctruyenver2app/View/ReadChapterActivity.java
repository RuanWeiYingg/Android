package com.example.doctruyenver2app.View;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.Controller.ChapterController;
import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.View.User.CommentBottomSheetDialog;

public class ReadChapterActivity extends AppCompatActivity {

    private static final String TAG = "ReadChapterActivity";

    private Toolbar toolbar;
    private TextView tvChapterTitle;
    private TextView tvChapterContent;
    private BottomNavigationView bottomNavigation;

    private int storyId = -1;
    private int chapterOrder = -1;
    private int currentUserId = -1;
    private String currentUserName = "";

    private ChapterController chapterController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_chapter);

        // Set background trắng để tránh transparent
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));

        // 1. Nhận dữ liệu từ Intent
        if (getIntent().getExtras() != null) {
            storyId = getIntent().getIntExtra("STORY_ID", -1);
            chapterOrder = getIntent().getIntExtra("CHAPTER_ORDER", 1);
            currentUserId = getIntent().getIntExtra("USER_ID", -1);
            currentUserName = getIntent().getStringExtra("USER_NAME");
        }

        if (storyId == -1 || chapterOrder == -1) {
            Toast.makeText(this, "Lỗi: Không tìm thấy ID truyện hoặc số chương.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Kiểm tra user info
        if (currentUserId == -1 || currentUserName == null) {
            currentUserId = 1;
            currentUserName = "Người dùng";
        }

        chapterController = new ChapterController(this);

        // 2. Ánh xạ Views
        toolbar = findViewById(R.id.toolbar_read);
        tvChapterTitle = findViewById(R.id.tv_chapter_title);
        tvChapterContent = findViewById(R.id.tv_chapter_content);
        bottomNavigation = findViewById(R.id.bottom_navigation_read);

        // 3. Thiết lập Toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // 4. Tải nội dung chương
        loadChapterContent(storyId, chapterOrder);

        // 5. Thiết lập Bottom Navigation
        setupBottomNavigation();
    }

    /**
     * Tải nội dung chương dựa trên Story ID và số thứ tự chương
     */
    private void loadChapterContent(int storyId, int order) {
        Chapter chapter = chapterController.getChapterByOrder(storyId, order);
        if (chapter != null) {
            String fullTitle = "Chương " + chapter.getOrderIndex() + ": " + chapter.getTitle();
            Log.d(TAG, "Loading: " + fullTitle);
            Log.d(TAG, "Content length: " + chapter.getContent().length());

            tvChapterTitle.setText(fullTitle);
            tvChapterContent.setText(chapter.getContent());
        } else {
            tvChapterTitle.setText("Chương không tồn tại");
            tvChapterContent.setText("Xin lỗi, nội dung chương này hiện chưa có hoặc đã bị xóa.");
            Toast.makeText(this, "Không tìm thấy Chương " + order, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Xử lý các nút điều hướng (Chương trước, Chương sau, Bình luận, Cài đặt)
     */
    private void setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.action_prev_chapter) {
                navigateChapter(chapterOrder - 1);
                return true;
            } else if (itemId == R.id.action_next_chapter) {
                navigateChapter(chapterOrder + 1);
                return true;
            } else if (itemId == R.id.action_comment) {
                openCommentDialog();
                return true;
            } else if (itemId == R.id.action_settings) {
                openSettingsDialog();
                return true;
            }
            return false;
        });
    }

    /**
     * Xử lý chuyển chương
     */
    private void navigateChapter(int targetOrder) {
        if (targetOrder >= 1) {
            chapterOrder = targetOrder;
            loadChapterContent(storyId, chapterOrder);
        } else {
            Toast.makeText(this, "Đây là chương đầu tiên!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Mở BottomSheetDialog bình luận
     */
    private void openCommentDialog() {
        CommentBottomSheetDialog dialog = CommentBottomSheetDialog.newInstance(
                storyId,
                currentUserId,
                currentUserName
        );
        dialog.show(getSupportFragmentManager(), "CommentBottomSheet");
    }

    /**
     * Mở dialog cài đặt
     */
    private void openSettingsDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Cài đặt đọc truyện")
                .setMessage("Các tùy chọn cài đặt sẽ được thêm vào trong phiên bản tiếp theo")
                .setIcon(R.drawable.ic_settings_24)
                .setPositiveButton("OK", null)
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}