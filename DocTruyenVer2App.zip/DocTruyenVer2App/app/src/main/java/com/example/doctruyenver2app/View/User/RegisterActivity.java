package com.example.doctruyenver2app.View.User;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.doctruyenver2app.Controller.UserController;
import com.example.doctruyenver2app.Model.User;
import com.example.doctruyenver2app.R;
import com.example.doctruyenver2app.Util.PasswordHashUtil;

public class    RegisterActivity extends AppCompatActivity {

    private static final String TAG = "RegisterActivity";
    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private Button btnRegister;
    private TextView tvLoginLink;

    private UserController userController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userController = new UserController(this);

        etUsername = findViewById(R.id.et_register_username);
        etEmail = findViewById(R.id.et_register_email);
        etPassword = findViewById(R.id.et_register_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        tvLoginLink = findViewById(R.id.tv_login_link);

        btnRegister.setOnClickListener(v -> {
            handleRegistration();
        });

        tvLoginLink.setOnClickListener(v -> {
            Log.d(TAG, "Navigating to LoginActivity.");
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Xử lý logic đăng ký người dùng.
     */
    private void handleRegistration() {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // 1. Kiểm tra rỗng
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin.", Toast.LENGTH_LONG).show();
            return;
        }

        // 2. Kiểm tra khớp mật khẩu
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Mật khẩu xác nhận không khớp.", Toast.LENGTH_LONG).show();
            return;
        }

        // 3. Kiểm tra độ dài mật khẩu
        if (password.length() < 6) {
            Toast.makeText(this, "Mật khẩu phải có ít nhất 6 ký tự.", Toast.LENGTH_LONG).show();
            return;
        }

        // 4. ✅ Hash mật khẩu sử dụng PasswordHashUtil (NHẤT QUÁN VỚI TẤT CẢ ACTIVITY)
        String passwordHash = PasswordHashUtil.hashPassword(password);

        Log.d(TAG, "Registration Attempt - Username: " + username + ", Email: " + email);
        Log.d(TAG, "Password Hash: " + passwordHash);

        // 5. Gọi Controller để đăng ký
        UserController.RegisterResult result = userController.register(username, email, passwordHash);

        switch (result) {
            case SUCCESS:
                Toast.makeText(this, "Đăng ký thành công! Vui lòng đăng nhập.", Toast.LENGTH_LONG).show();
                Log.d(TAG, "Registration successful for: " + username);

                // Chuyển về màn hình đăng nhập sau khi đăng ký thành công
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;

            case USERNAME_ALREADY_EXISTS:
                Toast.makeText(this, "Tên đăng nhập đã tồn tại.", Toast.LENGTH_LONG).show();
                Log.w(TAG, "Username already exists: " + username);
                break;

            case EMAIL_ALREADY_EXISTS:
                Toast.makeText(this, "Email đã được sử dụng cho một tài khoản khác.", Toast.LENGTH_LONG).show();
                Log.w(TAG, "Email already exists: " + email);
                break;

            case ERROR:
                Toast.makeText(this, "Đăng ký thất bại do lỗi hệ thống. Kiểm tra Logcat.", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Registration failed due to system error");
                break;
        }
    }

    }