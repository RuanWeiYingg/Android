package com.example.doctruyenver2app.Model;

public class Chapter {
    private int id;
    private int storyId;
    private String title;
    private String content;
    private int orderIndex;

    public Chapter() {}

    // Constructor 1: Dùng khi ĐỌC dữ liệu từ DB hoặc Cập nhật (Có đầy đủ ID)
    public Chapter(int id, int storyId, String title, String content, int orderIndex) {
        this.id = id;
        this.storyId = storyId;
        this.title = title;
        this.content = content;
        this.orderIndex = orderIndex;
    }

    // Constructor 2: Dùng khi THÊM MỚI dữ liệu vào DB (Không có ID)
    public Chapter(int storyId, String title, String content, int orderIndex) {
        this.storyId = storyId;
        this.title = title;
        this.content = content;
        this.orderIndex = orderIndex;
    }

    // Getter & Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getStoryId() { return storyId; }
    public void setStoryId(int storyId) { this.storyId = storyId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public int getOrderIndex() { return orderIndex; }
    public void setOrderIndex(int orderIndex) { this.orderIndex = orderIndex; }
}