package com.example.doctruyenver2app.Model;

public class User {
    private int id;
    private String username;
    private String email;
    private String avatarPath;

    // TRƯỜNG NÀY LÀ KHÓA NGOẠI (FOREIGN KEY)
    // DÙNG ĐỂ LIÊN KẾT ĐẾN BẢNG PASSWORDS.
    private int passwordId;

    public User() {}

    // 1. Dùng khi Đăng ký mới (Chưa có ID, chưa có ảnh)
    public User(String username, String email) {
        this.username = username;
        this.email = email;
        this.id = -1;
        this.passwordId = -1;
        this.avatarPath = ""; // Mặc định là chuỗi rỗng
    }

    // 2. Dùng khi lấy thông tin cơ bản từ DB (ID, Username, Email)
    public User(int id, String username, String email) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.passwordId = -1;
    }

    // 3. Dùng khi lấy đầy đủ thông tin (Bao gồm cả Ảnh đại diện)
    public User(int id, String username, String email, String avatarPath) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.avatarPath = avatarPath;
        this.passwordId = -1;
    }

    // 4. Dùng khi cần lấy cả thông tin PassId (Full DB Map)
    public User(int id, String username, String email, String avatarPath, int passwordId) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.avatarPath = avatarPath;
        this.passwordId = passwordId;
    }

    // Getter & Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAvatarPath() { return avatarPath; }
    public void setAvatarPath(String avatarPath) { this.avatarPath = avatarPath; }

    public int getPasswordId() { return passwordId; }
    public void setPasswordId(int passwordId) { this.passwordId = passwordId; }
}