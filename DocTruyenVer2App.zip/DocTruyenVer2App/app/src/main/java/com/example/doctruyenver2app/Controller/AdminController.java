package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Admin;

import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class AdminController {
    private static final String TAG = "AdminController";
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;

    public enum AdminLoginResult {
        SUCCESS,
        INVALID_CREDENTIALS,
        ADMIN_NOT_FOUND,
        ERROR
    }

    public enum AdminAddResult {
        SUCCESS,
        USERNAME_ALREADY_EXISTS,
        EMAIL_ALREADY_EXISTS,
        ERROR
    }

    public AdminController(Context context) {
        dbHelper = new DatabaseHelper(context);
        sessionManager = new SessionManager(context);
    }

    // =========================================================
    // =============== CHỨC NĂNG THÊM ADMIN (CREATE) ================
    // =========================================================

    public AdminAddResult addAdmin(Admin admin, String passwordHash) {
        if (isAdminUsernameExists(admin.getUsername())) {
            return AdminAddResult.USERNAME_ALREADY_EXISTS;
        }
        if (isAdminEmailExists(admin.getEmail())) {
            return AdminAddResult.EMAIL_ALREADY_EXISTS;
        }

        long result = insertAdmin(admin, passwordHash);

        if (result > 0) {
            return AdminAddResult.SUCCESS;
        } else {
            return AdminAddResult.ERROR;
        }
    }

    private long insertAdmin(Admin admin, String passwordHash) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long passId = -1;
        long adminId = -1;

        db.beginTransaction();
        try {
            ContentValues passValues = new ContentValues();
            passValues.put(COLUMN_HASH, passwordHash);
            passId = db.insert(TABLE_PASSWORDS, null, passValues);

            if (passId != -1) {
                ContentValues adminValues = new ContentValues();
                adminValues.put(COLUMN_ADMIN_USERNAME, admin.getUsername());
                adminValues.put(COLUMN_ADMIN_EMAIL, admin.getEmail());
                adminValues.put(COLUMN_ADMIN_PASSWORD_ID, (int) passId);
                adminId = db.insert(TABLE_ADMINS, null, adminValues);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error adding admin: " + e.getMessage());
        } finally {
            db.endTransaction();
            db.close();
        }
        return adminId;
    }

    // =========================================================
    // ================ CHỨC NĂNG ĐĂNG NHẬP & READ =================
    // =========================================================

    /**
     * ✅ UPDATED: Login với debug log chi tiết
     */
    public AdminLoginResult login(String usernameOrEmail, String passwordHash) {
        Log.d(TAG, "========== ADMIN LOGIN DEBUG ==========");
        Log.d(TAG, "Input username/email: " + usernameOrEmail);
        Log.d(TAG, "Input password hash: " + passwordHash);

        // Bước 1: Tìm admin theo username hoặc email
        Admin admin = getAdminByUsernameOrEmail(usernameOrEmail);

        if (admin == null) {
            Log.d(TAG, "❌ ADMIN NOT FOUND in database");
            Log.d(TAG, "========== END LOGIN DEBUG ==========");
            return AdminLoginResult.ADMIN_NOT_FOUND;
        }

        Log.d(TAG, "✅ Admin found:");
        Log.d(TAG, "   ID: " + admin.getId());
        Log.d(TAG, "   Username: " + admin.getUsername());
        Log.d(TAG, "   Email: " + admin.getEmail());
        Log.d(TAG, "   Password ID: " + admin.getPasswordId());

        // Bước 2: Lấy hash từ database
        String storedHash = getPasswordHashForAdmin(admin.getPasswordId());
        Log.d(TAG, "Stored hash from DB: " + storedHash);

        // Bước 3: So sánh
        Log.d(TAG, "Comparing hashes:");
        Log.d(TAG, "  Input hash  : " + passwordHash);
        Log.d(TAG, "  Stored hash : " + storedHash);

        if (storedHash == null) {
            Log.d(TAG, "❌ STORED HASH IS NULL");
            Log.d(TAG, "========== END LOGIN DEBUG ==========");
            return AdminLoginResult.INVALID_CREDENTIALS;
        }

        boolean hashMatch = storedHash.equals(passwordHash);
        Log.d(TAG, "Hash match: " + hashMatch);
        Log.d(TAG, "Input hash length: " + passwordHash.length());
        Log.d(TAG, "Stored hash length: " + storedHash.length());

        if (hashMatch) {
            Log.d(TAG, "✅ LOGIN SUCCESS");
            // Lưu phiên đăng nhập
            sessionManager.createLoginSession(admin.getId(), SessionManager.TYPE_ADMIN);
            Log.d(TAG, "========== END LOGIN DEBUG ==========");
            return AdminLoginResult.SUCCESS;
        } else {
            Log.d(TAG, "❌ PASSWORD MISMATCH");
            Log.d(TAG, "========== END LOGIN DEBUG ==========");
            return AdminLoginResult.INVALID_CREDENTIALS;
        }
    }

    /**
     * Lấy Admin bằng ID
     */
    public Admin getAdminById(int adminId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Admin admin = null;
        Cursor cursor = null;

        try {
            cursor = db.query(
                    TABLE_ADMINS,
                    new String[]{COLUMN_ADMIN_ID, COLUMN_ADMIN_USERNAME, COLUMN_ADMIN_EMAIL, COLUMN_ADMIN_PASSWORD_ID},
                    COLUMN_ADMIN_ID + " = ?",
                    new String[]{String.valueOf(adminId)},
                    null, null, null
            );

            if (cursor.moveToFirst()) {
                admin = new Admin(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getInt(3)
                );
            }
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return admin;
    }

    /**
     * Lấy Admin bằng Username hoặc Email (COLLATE NOCASE)
     */
    public Admin getAdminByUsernameOrEmail(String identifier) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Admin admin = null;
        Cursor cursor = null;

        String selection = COLUMN_ADMIN_USERNAME + " = ? COLLATE NOCASE OR " +
                COLUMN_ADMIN_EMAIL + " = ? COLLATE NOCASE";
        String[] selectionArgs = new String[]{identifier, identifier};

        try {
            cursor = db.query(
                    TABLE_ADMINS,
                    new String[]{COLUMN_ADMIN_ID, COLUMN_ADMIN_USERNAME, COLUMN_ADMIN_EMAIL, COLUMN_ADMIN_PASSWORD_ID},
                    selection, selectionArgs, null, null, null
            );

            if (cursor.moveToFirst()) {
                admin = new Admin(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getInt(3)
                );
                Log.d(TAG, "Found admin with identifier: " + identifier);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching admin by identifier: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return admin;
    }

    /**
     * Lấy Hash Mật khẩu từ Password ID
     */
    private String getPasswordHashForAdmin(int passwordId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String hash = null;
        Cursor passCursor = null;

        try {
            passCursor = db.query(
                    TABLE_PASSWORDS,
                    new String[]{COLUMN_HASH},
                    COLUMN_PASS_ID + " = ?",
                    new String[]{String.valueOf(passwordId)},
                    null, null, null
            );

            if (passCursor.moveToFirst()) {
                hash = passCursor.getString(0);
                Log.d(TAG, "Retrieved password hash for ID " + passwordId);
            } else {
                Log.d(TAG, "No password found for ID: " + passwordId);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching password hash: " + e.getMessage());
        } finally {
            if (passCursor != null) passCursor.close();
            db.close();
        }
        return hash;
    }

    /**
     * Kiểm tra Username tồn tại (COLLATE NOCASE)
     */
    private boolean isAdminUsernameExists(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        String selection = COLUMN_ADMIN_USERNAME + " = ? COLLATE NOCASE";

        try {
            cursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_ID}, selection,
                    new String[]{username}, null, null, null);
            exists = (cursor.getCount() > 0);
        } catch (Exception e) {
            Log.e(TAG, "Error checking username existence: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return exists;
    }

    /**
     * Kiểm tra Email tồn tại (COLLATE NOCASE)
     */
    private boolean isAdminEmailExists(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        String selection = COLUMN_ADMIN_EMAIL + " = ? COLLATE NOCASE";

        try {
            cursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_ID}, selection,
                    new String[]{email}, null, null, null);
            exists = (cursor.getCount() > 0);
        } catch (Exception e) {
            Log.e(TAG, "Error checking email existence: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return exists;
    }

    // =========================================================
    // ================ CHỨC NĂNG CẬP NHẬT (UPDATE) =================
    // =========================================================

    /**
     * Cập nhật Username và Email của Admin
     */
    public boolean updateAdminInfo(int adminId, String newUsername, String newEmail) {
        if (isAdminUsernameExistsExcludingAdmin(newUsername, adminId)) {
            Log.w(TAG, "Update failed: Username already exists.");
            return false;
        }

        if (isAdminEmailExistsExcludingAdmin(newEmail, adminId)) {
            Log.w(TAG, "Update failed: Email already exists.");
            return false;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ADMIN_USERNAME, newUsername);
        values.put(COLUMN_ADMIN_EMAIL, newEmail);

        int rowsAffected = 0;
        try {
            rowsAffected = db.update(TABLE_ADMINS, values, COLUMN_ADMIN_ID + " = ?",
                    new String[]{String.valueOf(adminId)});
        } finally {
            db.close();
        }
        return rowsAffected > 0;
    }

    /**
     * Kiểm tra Username tồn tại (loại trừ Admin cụ thể)
     */
    private boolean isAdminUsernameExistsExcludingAdmin(String username, int adminIdToExclude) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        String selection = COLUMN_ADMIN_USERNAME + " = ? COLLATE NOCASE AND " +
                COLUMN_ADMIN_ID + " != ?";
        String[] selectionArgs = new String[]{username, String.valueOf(adminIdToExclude)};

        try {
            cursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_ID}, selection,
                    selectionArgs, null, null, null);
            exists = (cursor.getCount() > 0);
        } catch (Exception e) {
            Log.e(TAG, "Error checking username existence for update: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return exists;
    }

    /**
     * Kiểm tra Email tồn tại (loại trừ Admin cụ thể)
     */
    private boolean isAdminEmailExistsExcludingAdmin(String email, int adminIdToExclude) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        String selection = COLUMN_ADMIN_EMAIL + " = ? COLLATE NOCASE AND " +
                COLUMN_ADMIN_ID + " != ?";
        String[] selectionArgs = new String[]{email, String.valueOf(adminIdToExclude)};

        try {
            cursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_ID}, selection,
                    selectionArgs, null, null, null);
            exists = (cursor.getCount() > 0);
        } catch (Exception e) {
            Log.e(TAG, "Error checking email existence for update: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return exists;
    }

    /**
     * Cập nhật mật khẩu Admin
     */
    public boolean updateAdminPassword(int adminId, String newPasswordHash) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        boolean success = false;

        try {
            // Lấy password_id
            Cursor adminCursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_PASSWORD_ID},
                    COLUMN_ADMIN_ID + " = ?", new String[]{String.valueOf(adminId)},
                    null, null, null);
            int passId = -1;
            if (adminCursor.moveToFirst()) {
                passId = adminCursor.getInt(0);
            }
            adminCursor.close();

            if (passId != -1) {
                ContentValues values = new ContentValues();
                values.put(COLUMN_HASH, newPasswordHash);
                int rowsAffected = db.update(TABLE_PASSWORDS, values, COLUMN_PASS_ID + " = ?",
                        new String[]{String.valueOf(passId)});
                success = rowsAffected > 0;
            }
        } finally {
            db.close();
        }
        return success;
    }

    // =========================================================
    // ================= CHỨC NĂNG XÓA (DELETE) ==================
    // =========================================================

    /**
     * Xóa Admin và Password liên quan
     */
    public boolean deleteAdmin(int adminId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        boolean success = false;

        db.beginTransaction();
        try {
            // Lấy password_id
            Cursor adminCursor = db.query(TABLE_ADMINS, new String[]{COLUMN_ADMIN_PASSWORD_ID},
                    COLUMN_ADMIN_ID + " = ?", new String[]{String.valueOf(adminId)},
                    null, null, null);
            int passId = -1;
            if (adminCursor.moveToFirst()) {
                passId = adminCursor.getInt(0);
            }
            adminCursor.close();

            // Xóa admin
            int adminDeleted = db.delete(TABLE_ADMINS, COLUMN_ADMIN_ID + " = ?",
                    new String[]{String.valueOf(adminId)});

            // Xóa password nếu admin được xóa
            if (adminDeleted > 0 && passId != -1) {
                db.delete(TABLE_PASSWORDS, COLUMN_PASS_ID + " = ?",
                        new String[]{String.valueOf(passId)});
                success = true;
            }

            db.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e(TAG, "Error deleting admin: " + e.getMessage());
        } finally {
            db.endTransaction();
            db.close();
        }
        return success;
    }
}