package com.example.doctruyenver2app.View;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.doctruyenver2app.Adapter.User.CategoryAdapter;
import com.example.doctruyenver2app.Adapter.User.StoryAdapter;
import com.example.doctruyenver2app.Controller.CategoryController;
import com.example.doctruyenver2app.Controller.StoryController;
import com.example.doctruyenver2app.Model.Category;
import com.example.doctruyenver2app.Model.Story;
import com.example.doctruyenver2app.R;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = "HomeActivity";

    private Toolbar toolbar;
    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerStories, recyclerCategories;
    private View btnProfileLogin, overlayBackground;
    private LinearLayout categoryHeaderLayout;
    private ImageView iconCategoryExpand;
    private SearchView searchView;

    private StoryAdapter storyAdapter;
    private CategoryAdapter categoryAdapter;
    private List<Story> storyList;
    private List<Category> categoryList;
    private StoryController storyController;
    private CategoryController categoryController;

    private boolean isCategoryExpanded = false;
    private int currentUserId = -1;  // ✅ Lưu USER_ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // ✅ NHẬN USER_ID TỪ LoginActivity
        currentUserId = getIntent().getIntExtra("USER_ID", -1);
        Log.d(TAG, "Received USER_ID from LoginActivity: " + currentUserId);

        if (currentUserId == -1) {
            Log.e(TAG, "Invalid USER_ID");
            Toast.makeText(this, "Lỗi: Không tìm thấy ID người dùng", Toast.LENGTH_SHORT).show();
            // Có thể xử lý: quay lại LoginActivity hoặc set default
        }

        initViews();
        setupToolbar();
        setupData();
        setupEventListeners();
        loadInitialData();
    }

    private void initViews() {
        toolbar = findViewById(R.id.toolbar_home);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        recyclerStories = findViewById(R.id.recycler_stories);
        recyclerCategories = findViewById(R.id.recycler_categories);
        btnProfileLogin = findViewById(R.id.btn_profile_login);
        overlayBackground = findViewById(R.id.overlay_background);
        categoryHeaderLayout = findViewById(R.id.category_header_layout);
        iconCategoryExpand = findViewById(R.id.icon_category_expand);
        searchView = findViewById(R.id.search_view_stories);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> resetToHome());
    }

    private void setupData() {
        storyList = new ArrayList<>();
        categoryList = new ArrayList<>();
        storyController = new StoryController(this);
        categoryController = new CategoryController(this);

        recyclerStories.setLayoutManager(new LinearLayoutManager(this));
        storyAdapter = new StoryAdapter(storyList, this);
        recyclerStories.setAdapter(storyAdapter);

        recyclerCategories.setLayoutManager(new GridLayoutManager(this, 3));
        categoryAdapter = new CategoryAdapter(categoryList, new CategoryAdapter.OnCategoryClickListener() {
            @Override
            public void onCategoryClick(Category category) {
                loadStoriesByCategory(category.getId());
                toggleCategorySection();
                Toast.makeText(HomeActivity.this, "Thể loại: " + category.getName(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onClearFilter() {
                loadStories();
                toggleCategorySection();
            }
        });
        recyclerCategories.setAdapter(categoryAdapter);
    }

    private void setupEventListeners() {
        // ✅ GỬI USER_ID ĐÚNG sang UserProfileActivity
        btnProfileLogin.setOnClickListener(v -> {
            Log.d(TAG, "Opening UserProfileActivity with USER_ID: " + currentUserId);
            Intent intent = new Intent(HomeActivity.this, com.example.doctruyenver2app.View.User.UserProfileActivity.class);
            intent.putExtra("USER_ID", currentUserId);  // ✅ GỬI USER_ID NHẬN ĐƯỢC
            startActivity(intent);
        });

        categoryHeaderLayout.setOnClickListener(v -> toggleCategorySection());
        overlayBackground.setOnClickListener(v -> toggleCategorySection());

        swipeRefreshLayout.setOnRefreshListener(this::loadStories);

        setupSearchView();
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                searchView.clearFocus();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    loadStories();
                } else {
                    performSearch(newText);
                }
                return true;
            }
        });
    }

    private void performSearch(String query) {
        List<Story> filteredList = storyController.searchStories(query);
        storyList.clear();
        if (filteredList != null) {
            storyList.addAll(filteredList);
        }
        storyAdapter.notifyDataSetChanged();
    }

    private void toggleCategorySection() {
        if (isCategoryExpanded) {
            recyclerCategories.setVisibility(View.GONE);
            overlayBackground.setVisibility(View.GONE);
            iconCategoryExpand.animate().rotation(0).setDuration(300).start();
        } else {
            recyclerCategories.setVisibility(View.VISIBLE);
            overlayBackground.setVisibility(View.VISIBLE);
            iconCategoryExpand.animate().rotation(180).setDuration(300).start();
        }
        isCategoryExpanded = !isCategoryExpanded;
    }

    private void resetToHome() {
        searchView.setQuery("", false);
        searchView.clearFocus();
        loadStories();
        if (isCategoryExpanded) toggleCategorySection();
        Toast.makeText(this, "Đã quay về trang chủ", Toast.LENGTH_SHORT).show();
    }

    private void loadInitialData() {
        loadCategories();
        loadStories();
    }

    private void loadCategories() {
        categoryList.clear();
        categoryList.addAll(categoryController.getAllCategories());
        categoryAdapter.notifyDataSetChanged();
    }

    private void loadStories() {
        swipeRefreshLayout.setRefreshing(true);
        List<Story> allStories = storyController.getAllStories();
        storyList.clear();
        if (allStories != null) storyList.addAll(allStories);
        storyAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }

    private void loadStoriesByCategory(int id) {
        swipeRefreshLayout.setRefreshing(true);
        List<Story> catStories = storyController.getStoriesByCategoryId(id);
        storyList.clear();
        if (catStories != null) storyList.addAll(catStories);
        storyAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }
}