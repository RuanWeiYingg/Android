package com.example.doctruyenver2app.Model;

public class Admin {
    private int id;
    private String username;
    private String email;
    private int passwordId;

    // Constructor 1: Rỗng
    public Admin() {}

    // Constructor 2: Chỉ username và email (DÙNG KHI THÊM MỚI)
    public Admin(String username, String email) {
        this.username = username;  // ✅ THÊM DÒNG NÀY
        this.email = email;        // ✅ THÊM DÒNG NÀY
        this.id = -1;              // Chưa có ID từ database
        this.passwordId = -1;      // Chưa có password ID
    }

    // Constructor 3: ID + Username + Email + PasswordId (DÙNG KHI LẤY TỪ DATABASE)
    public Admin(int id, String username, String email, int passwordId) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.passwordId = passwordId;
    }

    // ============= GETTERS & SETTERS =============
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPasswordId() {
        return passwordId;
    }

    public void setPasswordId(int passwordId) {
        this.passwordId = passwordId;
    }

    @Override
    public String toString() {
        return "Admin{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", passwordId=" + passwordId +
                '}';
    }
}