package com.example.doctruyenver2app.Controller;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Quản lý phiên đăng nhập bằng cách sử dụng SharedPreferences.
 * Lưu trữ ID người dùng/Admin và loại tài khoản sau khi đăng nhập thành công.
 */
public class SessionManager {

    // Tên file SharedPreferences
    private static final String PREF_NAME = "DocTruyenVer2AppPrefs";

    // Các Khóa (Keys)
    private static final String IS_LOGGED_IN = "IsLoggedIn";
    private static final String KEY_USER_ID = "UserId";
    private static final String KEY_ACCOUNT_TYPE = "AccountType";

    // Hằng số cho loại tài khoản
    public static final String TYPE_USER = "USER";
    public static final String TYPE_ADMIN = "ADMIN";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context _context;

    // Constructor
    public SessionManager(Context context) {
        this._context = context;
        // Mở SharedPreferences với chế độ PRIVATE
        pref = _context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    // ---------------------------------------------------------
    // 1. CREATE: Tạo và lưu Phiên Đăng nhập
    // ---------------------------------------------------------

    /**
     * Tạo và lưu phiên đăng nhập.
     * @param id ID của người dùng hoặc admin
     * @param accountType Loại tài khoản ("USER" hoặc "ADMIN")
     */
    public void createLoginSession(int id, String accountType) {
        editor.putBoolean(IS_LOGGED_IN, true);
        editor.putInt(KEY_USER_ID, id);
        editor.putString(KEY_ACCOUNT_TYPE, accountType);
        editor.apply(); // apply() lưu bất đồng bộ, commit() lưu đồng bộ
    }

    // ---------------------------------------------------------
    // 2. READ: Lấy thông tin Phiên
    // ---------------------------------------------------------

    /**
     * Kiểm tra trạng thái đăng nhập.
     * @return true nếu đã đăng nhập, false nếu chưa.
     */
    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGGED_IN, false);
    }

    /**
     * Lấy ID của người dùng/admin đang đăng nhập.
     * @return ID hoặc -1 nếu chưa đăng nhập.
     */
    public int getLoggedInUserId() {
        return pref.getInt(KEY_USER_ID, -1);
    }

    /**
     * Lấy loại tài khoản đang đăng nhập.
     * @return "USER", "ADMIN", hoặc null nếu chưa đăng nhập.
     */
    public String getAccountType() {
        return pref.getString(KEY_ACCOUNT_TYPE, null);
    }

    /**
     * Kiểm tra xem tài khoản đang đăng nhập có phải là Admin không.
     */
    public boolean isAdmin() {
        // Chỉ cần kiểm tra KEY_ACCOUNT_TYPE có phải là TYPE_ADMIN không
        return TYPE_ADMIN.equals(getAccountType());
    }

    // ---------------------------------------------------------
    // 3. DELETE: Đăng xuất (Xóa Phiên)
    // ---------------------------------------------------------

    /**
     * Xóa tất cả dữ liệu phiên (Đăng xuất).
     * Cần gọi hàm này trong logout button hoặc khi Token hết hạn.
     */
    public void logoutUser() {
        // Xóa tất cả dữ liệu trong SharedPreferences
        editor.clear();
        editor.apply();

        // *TÙY CHỌN: Ở lớp Activity, bạn sẽ cần thêm logic để chuyển hướng người dùng
        // về màn hình đăng nhập (LoginActivity) sau khi gọi hàm này.
    }
}