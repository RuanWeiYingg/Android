package com.example.doctruyenver2app.View.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button; // Cần import Button
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.doctruyenver2app.View.User.LoginActivity ;
import com.example.doctruyenver2app.R;

public class AdminDashboardActivity extends AppCompatActivity {

    // Thay thế CardView bằng Button
    private Button btnManageStories;
    private Button btnManageUsers;
    private Button btnManageCategories;
    private Button btnManageReports;
    private Button btnAdminLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_admin_dashboard);

        btnManageStories = findViewById(R.id.btn_manage_stories);
        btnManageUsers = findViewById(R.id.btn_manage_users);
        btnManageCategories = findViewById(R.id.btn_manage_categories);
        btnManageReports = findViewById(R.id.btn_manage_reports);
        btnAdminLogout = findViewById(R.id.btn_admin_logout); // Ánh xạ nút đăng xuất


        setupNavigationListeners();
    }

    private void setupNavigationListeners() {
        // Chuyển đến màn hình Quản lý Truyện
        btnManageStories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, ManageStoriesActivity.class);
                startActivity(intent);
            }
        });

        // Chuyển đến màn hình Quản lý Người dùng
        btnManageUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, ManageUsersActivity.class);
                startActivity(intent);
            }
        });

        // Chuyển đến màn hình Quản lý Thể loại
        btnManageCategories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, ManageCategoriesActivity.class);
                startActivity(intent);
            }
        });

        // Chuyển đến màn hình Quản lý Báo cáo & Bình luận
        btnManageReports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardActivity.this, ManageReportsActivity.class);
                startActivity(intent);
            }
        });

        // Xử lý hành động Đăng xuất
        btnAdminLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Triển khai logic đăng xuất tại đây (ví dụ: Firebase Sign Out)
                // Sau khi đăng xuất, chuyển về màn hình Login hoặc Main
                // Ví dụ tạm thời:
                Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
                startActivity(intent);
                 finish();
            }
        });
    }


}
