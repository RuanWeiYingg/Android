package com.example.doctruyenver2app.Model;

public class Password {
    private int id;
    private String hash;
    private String createdAt;

    public Password() {}

    public Password(int id, String hash, String createdAt) {
        this.id = id;
        this.hash = hash;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getHash() { return hash; }
    public void setHash(String hash) { this.hash = hash; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
