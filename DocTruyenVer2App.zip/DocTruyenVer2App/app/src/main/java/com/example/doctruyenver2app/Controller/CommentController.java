package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Comment;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class CommentController {
    private static final String TAG = "CommentController";
    private DatabaseHelper dbHelper;

    public CommentController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // =========================================================
    // =============== HÀM TIỆN ÍCH CHUẨN HÓA ==================
    // =========================================================

    private String removeVietnameseAccents(String s) {
        if (s == null) return null;
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(temp).replaceAll("").toLowerCase();
    }

    // =========================================================
    // =============== 1. CREATE (Thêm Bình luận) ===============
    // =========================================================

    public long addComment(Comment comment) {
        // Kiểm tra chống spam trước khi thêm
        if (isCommentContentExists(comment.getUserId(), comment.getContent())) {
            Log.w(TAG, "Potential spam detected: Nội dung tương tự vừa được gửi.");
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_COMMENT_USER_ID, comment.getUserId());
        values.put(COLUMN_COMMENT_STORY_ID, comment.getStoryId());

        if (comment.getChapterId() > 0) {
            values.put(COLUMN_COMMENT_CHAPTER_ID, comment.getChapterId());
        }

        values.put(COLUMN_COMMENT_CONTENT, comment.getContent());

        long result = db.insert(TABLE_COMMENTS, null, values);
        db.close();
        return result;
    }

    // =========================================================
    // =================== 2. READ (Đọc Bình luận) =================
    // =========================================================

    public List<Comment> getAllComments() {
        List<Comment> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_COMMENTS +
                " ORDER BY " + COLUMN_COMMENT_CREATED_AT + " DESC";

        Cursor c = db.rawQuery(query, null);

        if (c.moveToFirst()) {
            do {
                list.add(new Comment(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_COMMENT_ID)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_COMMENT_USER_ID)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_COMMENT_STORY_ID)),
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_COMMENT_CHAPTER_ID)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_COMMENT_CONTENT)),
                        c.getString(c.getColumnIndexOrThrow(COLUMN_COMMENT_CREATED_AT))
                ));
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public List<Comment> getCommentsByStory(int storyId) {
        List<Comment> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_COMMENTS +
                " WHERE " + COLUMN_COMMENT_STORY_ID + " = ?" +
                " ORDER BY " + COLUMN_COMMENT_CREATED_AT + " DESC";

        Cursor c = db.rawQuery(query, new String[]{String.valueOf(storyId)});

        if (c.moveToFirst()) {
            do {
                list.add(new Comment(
                        c.getInt(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getString(4), c.getString(5)
                ));
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    public Comment getCommentById(int commentId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Comment comment = null;
        Cursor c = db.query(TABLE_COMMENTS, null, COLUMN_COMMENT_ID + " = ?",
                new String[]{String.valueOf(commentId)}, null, null, null);

        if (c != null && c.moveToFirst()) {
            comment = new Comment(c.getInt(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getString(4), c.getString(5));
            c.close();
        }
        db.close();
        return comment;
    }

    // =========================================================
    // =============== 3. UPDATE & DELETE ======================
    // =========================================================

    public boolean updateCommentContent(int commentId, String newContent) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COMMENT_CONTENT, newContent);
        int rows = db.update(TABLE_COMMENTS, values, COLUMN_COMMENT_ID + " = ?", new String[]{String.valueOf(commentId)});
        db.close();
        return rows > 0;
    }

    public boolean deleteComment(int commentId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.delete(TABLE_COMMENTS, COLUMN_COMMENT_ID + " = ?", new String[]{String.valueOf(commentId)});
        db.close();
        return rows > 0;
    }

    // =========================================================
    // =============== 4. KIỂM TRA TRÙNG LẶP (SPAM) =============
    // =========================================================

    public boolean isCommentContentExists(int userId, String content) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        boolean exists = false;

        String query = "SELECT 1 FROM " + TABLE_COMMENTS +
                " WHERE " + COLUMN_COMMENT_USER_ID + " = ? " +
                " AND " + COLUMN_COMMENT_CONTENT + " = ? " +
                " AND " + COLUMN_COMMENT_CREATED_AT + " >= datetime('now', '-60 seconds')";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId), content});
        if (cursor != null) {
            exists = cursor.getCount() > 0;
            cursor.close();
        }
        db.close();
        return exists;
    }

    // =========================================================
    // =============== 5. SEARCH ============================
    // =========================================================

    public List<Comment> searchCommentsByContent(String query) {
        List<Comment> commentList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String normalizedQuery = removeVietnameseAccents(query);
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_COMMENTS, null);

        if (cursor.moveToFirst()) {
            do {
                String content = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COMMENT_CONTENT));
                if (removeVietnameseAccents(content).contains(normalizedQuery)) {
                    commentList.add(new Comment(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2), cursor.getInt(3), content, cursor.getString(5)));
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return commentList;
    }
}