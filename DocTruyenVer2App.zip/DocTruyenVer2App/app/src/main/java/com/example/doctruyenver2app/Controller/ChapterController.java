package com.example.doctruyenver2app.Controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.doctruyenver2app.Database.DatabaseHelper;
import com.example.doctruyenver2app.Model.Chapter;

import java.text.Normalizer; // <<< IMPORT MỚI
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern; // <<< IMPORT MỚI

// Import các hằng số từ DatabaseHelper
import static com.example.doctruyenver2app.Database.DatabaseHelper.*;

public class ChapterController {
    private static final String TAG = "ChapterController";
    private DatabaseHelper dbHelper;

    public ChapterController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // =========================================================
    // =============== HÀM TIỆN ÍCH CHUẨN HÓA ==================
    // =========================================================

    /**
     * Loại bỏ dấu tiếng Việt (chuẩn hóa) và chuyển về chữ thường.
     * Dùng cho mục đích tìm kiếm linh hoạt (ví dụ: "chuong 1" -> "Chương 1").
     */
    private String removeVietnameseAccents(String s) {
        if (s == null) return null;
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(temp).replaceAll("").toLowerCase();
    }

    // =========================================================
    // =============== 1. CREATE (Thêm Chương) =================
    // =========================================================

    // Cần thêm logic kiểm tra trùng lặp trước khi gọi hàm này
    public long addChapter(Chapter chapter) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STORY_ID_FK, chapter.getStoryId());
        values.put(COLUMN_CHAPTER_TITLE, chapter.getTitle());
        values.put(COLUMN_CONTENT, chapter.getContent());
        values.put(COLUMN_ORDER_INDEX, chapter.getOrderIndex());
        long result = db.insert(TABLE_CHAPTERS, null, values);
        db.close();
        return result; // Trả về ID hoặc -1 nếu thất bại
    }

    // =========================================================
    // =============== 2. READ (Đọc Chương) ===================
    // =========================================================

    // Đã có: getChaptersByStory (Giữ nguyên)
    public List<Chapter> getChaptersByStory(int storyId) {
        List<Chapter> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Sắp xếp theo thứ tự order_index (quan trọng cho đọc truyện)
        String query = "SELECT * FROM " + TABLE_CHAPTERS +
                " WHERE " + COLUMN_STORY_ID_FK + "=" + storyId +
                " ORDER BY " + COLUMN_ORDER_INDEX + " ASC";

        Cursor c = db.rawQuery(query, null);

        if (c.moveToFirst()) {
            // Lấy index của các cột
            int idIndex = c.getColumnIndex(COLUMN_CHAPTER_ID);
            int storyIdIndex = c.getColumnIndex(COLUMN_STORY_ID_FK);
            int titleIndex = c.getColumnIndex(COLUMN_CHAPTER_TITLE);
            int contentIndex = c.getColumnIndex(COLUMN_CONTENT);
            int orderIndex = c.getColumnIndex(COLUMN_ORDER_INDEX);

            do {
                if(idIndex != -1 && storyIdIndex != -1 && titleIndex != -1 && orderIndex != -1) {
                    list.add(new Chapter(
                            c.getInt(idIndex), // ID
                            c.getInt(storyIdIndex), // STORY_ID_FK
                            c.getString(titleIndex), // CHAPTER_TITLE
                            c.getString(contentIndex), // CONTENT (Nên tránh lấy nội dung nặng ở đây)
                            c.getInt(orderIndex)  // ORDER_INDEX
                    ));
                }
            } while (c.moveToNext());
        }
        c.close();
        db.close();
        return list;
    }

    /**
     * Lấy chi tiết một chương (bao gồm nội dung) (Giữ nguyên)
     */
    public Chapter getChapterById(int chapterId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Chapter chapter = null;
        Cursor c = null;

        try {
            c = db.query(TABLE_CHAPTERS,
                    null, // Lấy tất cả cột
                    COLUMN_CHAPTER_ID + " = ?",
                    new String[]{String.valueOf(chapterId)},
                    null, null, null);

            if (c.moveToFirst()) {
                chapter = new Chapter(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CHAPTER_ID)),    // ID
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_STORY_ID_FK)),    // STORY_ID_FK
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CHAPTER_TITLE)), // TITLE
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CONTENT)), // CONTENT
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_ORDER_INDEX))     // ORDER_INDEX
                );
            }
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Lỗi lấy cột: " + e.getMessage());
        } finally {
            if (c != null) c.close();
            db.close();
        }
        return chapter;
    }

    // =========================================================
    // =============== 3. UPDATE (Cập nhật Chương) ================
    // =========================================================

    /**
     * Cập nhật thông tin và nội dung của một chương. (Giữ nguyên)
     */
    public boolean updateChapter(Chapter chapter) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_CHAPTER_TITLE, chapter.getTitle());
        values.put(COLUMN_CONTENT, chapter.getContent());
        values.put(COLUMN_ORDER_INDEX, chapter.getOrderIndex());

        // Cập nhật dòng có ID tương ứng
        int rows = db.update(TABLE_CHAPTERS,
                values,
                COLUMN_CHAPTER_ID + " = ?",
                new String[]{String.valueOf(chapter.getId())});
        db.close();
        return rows > 0;
    }

    // =========================================================
    // =============== 4. DELETE (Xóa Chương) ==================
    // =========================================================

    /**
     * Xóa một chương khỏi cơ sở dữ liệu. (Giữ nguyên)
     */
    public boolean deleteChapter(int chapterId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Xóa chương, các Comment liên quan (nếu có) sẽ bị xóa theo CASCADE DELETE (trong DBHelper)
        int rows = db.delete(TABLE_CHAPTERS,
                COLUMN_CHAPTER_ID + " = ?",
                new String[]{String.valueOf(chapterId)});
        db.close();
        return rows > 0;
    }

    // =========================================================
    // =============== 5. KIỂM TRA TRÙNG LẶP ===================
    // =========================================================

    /**
     * Kiểm tra xem đã có chương cùng tên (title) trong cùng một truyện chưa.
     * Sử dụng so sánh chính xác (PHÂN BIỆT DẤU và chữ hoa/thường).
     */
    public boolean isChapterTitleExists(int storyId, String chapterTitle) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        // Bỏ COLLATE NOCASE để so sánh CHÍNH XÁC (bao gồm cả dấu)
        String selectQuery = "SELECT 1 FROM " + TABLE_CHAPTERS +
                " WHERE " + COLUMN_STORY_ID_FK + " = ?" +
                " AND " + COLUMN_CHAPTER_TITLE + " = ?";

        try {
            cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(storyId), chapterTitle});

            if (cursor != null && cursor.getCount() > 0) {
                exists = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking chapter title existence: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return exists;
    }

    /**
     * Kiểm tra xem đã có chương cùng số thứ tự (orderIndex) trong cùng một truyện chưa.
     * Lưu ý: Trong DatabaseHelper, bạn đã đặt UNIQUE cho (story_id, order_index),
     * nhưng nên kiểm tra ở tầng ứng dụng để cung cấp thông báo lỗi thân thiện hơn.
     */
    public boolean isChapterOrderIndexExists(int storyId, int orderIndex) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        boolean exists = false;

        String selectQuery = "SELECT 1 FROM " + TABLE_CHAPTERS +
                " WHERE " + COLUMN_STORY_ID_FK + " = ?" +
                " AND " + COLUMN_ORDER_INDEX + " = ?";

        try {
            cursor = db.rawQuery(selectQuery, new String[]{String.valueOf(storyId), String.valueOf(orderIndex)});

            if (cursor != null && cursor.getCount() > 0) {
                exists = true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error checking chapter order existence: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return exists;
    }


    // =========================================================
    // =============== 6. TÌM KIẾM (SEARCH) ====================
    // =========================================================

    /**
     * Tìm kiếm chương trong một truyện theo tiêu đề (linh hoạt, không phân biệt dấu).
     * @param storyId ID của truyện.
     * @param query Chuỗi tìm kiếm (có thể có dấu hoặc không dấu).
     * @return Danh sách Chapter khớp với truy vấn.
     */
    public List<Chapter> searchChaptersByTitle(int storyId, String query) {
        List<Chapter> chapterList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;

        // Chuẩn hóa chuỗi tìm kiếm của người dùng
        String normalizedQuery = removeVietnameseAccents(query);

        // Lấy tất cả chương để lọc ở tầng Java (SQLite không hỗ trợ hàm loại bỏ dấu)
        // Đây là cách tiếp cận đơn giản nhất và tránh lỗi mất dấu.
        String selectQuery = "SELECT * FROM " + TABLE_CHAPTERS +
                " WHERE " + COLUMN_STORY_ID_FK + " = ?";

        String[] selectionArgs = new String[]{String.valueOf(storyId)};

        try {
            cursor = db.rawQuery(selectQuery, selectionArgs);

            // Lấy index của các cột
            int idIndex = cursor.getColumnIndex(COLUMN_CHAPTER_ID);
            int storyIdIndex = cursor.getColumnIndex(COLUMN_STORY_ID_FK);
            int titleIndex = cursor.getColumnIndex(COLUMN_CHAPTER_TITLE);
            int contentIndex = cursor.getColumnIndex(COLUMN_CONTENT);
            int orderIndex = cursor.getColumnIndex(COLUMN_ORDER_INDEX);

            if (cursor.moveToFirst()) {
                do {
                    if (idIndex != -1 && titleIndex != -1) {
                        String storedTitle = cursor.getString(titleIndex);
                        String normalizedStoredTitle = removeVietnameseAccents(storedTitle);

                        // So sánh chuỗi đã được chuẩn hóa (không dấu)
                        if (normalizedStoredTitle.contains(normalizedQuery)) {
                            Chapter chapter = new Chapter(
                                    cursor.getInt(idIndex),
                                    cursor.getInt(storyIdIndex),
                                    storedTitle,
                                    cursor.getString(contentIndex),
                                    cursor.getInt(orderIndex)
                            );
                            chapterList.add(chapter);
                        }
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error searching chapters: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return chapterList;
    }

    /**
     * Lấy chi tiết một chương (bao gồm nội dung) dựa trên ID truyện và số thứ tự chương. (Giữ nguyên)
     */
    public Chapter getChapterByOrder(int storyId, int orderIndex) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Chapter chapter = null;
        Cursor c = null;

        // Xây dựng truy vấn để tìm chương theo cả STORY_ID và ORDER_INDEX
        String selection = COLUMN_STORY_ID_FK + " = ? AND " + COLUMN_ORDER_INDEX + " = ?";
        String[] selectionArgs = new String[]{String.valueOf(storyId), String.valueOf(orderIndex)};

        try {
            c = db.query(TABLE_CHAPTERS,
                    null, // Lấy tất cả cột
                    selection,
                    selectionArgs,
                    null, null, null);

            if (c.moveToFirst()) {
                chapter = new Chapter(
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_CHAPTER_ID)),    // ID
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_STORY_ID_FK)),    // STORY_ID_FK
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CHAPTER_TITLE)), // TITLE
                        c.getString(c.getColumnIndexOrThrow(COLUMN_CONTENT)), // CONTENT
                        c.getInt(c.getColumnIndexOrThrow(COLUMN_ORDER_INDEX))     // ORDER_INDEX
                );
            }
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Lỗi lấy cột: " + e.getMessage());
        } finally {
            if (c != null) c.close();
            db.close();
        }
        return chapter;
    }
}