package com.example.doctruyenver2app.Adapter.Admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.R; // Phải đảm bảo có import này

import java.util.List;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.ChapterViewHolder> {

    private final Context context;
    private final List<Chapter> chapterList;
    private final OnChapterActionListener listener;

    // Interface để truyền sự kiện Sửa/Xóa về Activity
    public interface OnChapterActionListener {
        void onEditClick(Chapter chapter);
        void onDeleteClick(Chapter chapter);
    }

    public ChapterAdapter(Context context, List<Chapter> chapterList, OnChapterActionListener listener) {
        this.context = context;
        this.chapterList = chapterList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Giả định layout item_chapter_admin.xml tồn tại
        View view = LayoutInflater.from(context).inflate(R.layout.item_chapter_admin, parent, false);
        return new ChapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
        Chapter chapter = chapterList.get(position);

        // Gán dữ liệu
        holder.tvChapterTitle.setText("Chương " + chapter.getOrderIndex() + ": " + chapter.getTitle());
        holder.tvChapterId.setText("ID: " + chapter.getId());

        // Thiết lập Listener cho các nút thao tác
        holder.btnEditChapter.setOnClickListener(v -> {
            if (listener != null) listener.onEditClick(chapter);
        });
        holder.btnDeleteChapter.setOnClickListener(v -> {
            if (listener != null) listener.onDeleteClick(chapter);
        });
    }

    @Override
    public int getItemCount() {
        return chapterList.size();
    }

    // Hàm cập nhật danh sách
    public void updateList(List<Chapter> newList) {
        chapterList.clear();
        chapterList.addAll(newList);
        notifyDataSetChanged();
    }

    public static class ChapterViewHolder extends RecyclerView.ViewHolder {
        TextView tvChapterTitle, tvChapterId;
        ImageButton btnEditChapter, btnDeleteChapter;

        public ChapterViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ánh xạ Views (Cần đảm bảo các ID này có trong item_chapter_admin.xml)
            tvChapterTitle = itemView.findViewById(R.id.tv_chapter_title);
            tvChapterId = itemView.findViewById(R.id.tv_chapter_id);
            btnEditChapter = itemView.findViewById(R.id.btn_edit_chapter);
            btnDeleteChapter = itemView.findViewById(R.id.btn_delete_chapter);
        }
    }
}