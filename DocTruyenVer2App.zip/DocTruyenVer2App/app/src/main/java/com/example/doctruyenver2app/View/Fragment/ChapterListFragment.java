package com.example.doctruyenver2app.View.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.doctruyenver2app.Adapter.User.ChapterAdapter; // Cần tạo Adapter này
import com.example.doctruyenver2app.Controller.ChapterController;
import com.example.doctruyenver2app.Model.Chapter;
import com.example.doctruyenver2app.R; // Đảm bảo import R

import java.util.ArrayList;
import java.util.List;

public class ChapterListFragment extends Fragment {

    private int storyId = -1;
    private RecyclerView recyclerView;
    private TextView tvNoChapters;   // Hiển thị khi danh sách rỗng
    private ProgressBar progressBar; // Hiển thị khi đang tải

    private ChapterAdapter chapterAdapter;
    private ChapterController chapterController;
    private List<Chapter> chapterList;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Nhận STORY_ID được truyền từ PagerAdapter
        if (getArguments() != null) {
            storyId = getArguments().getInt("STORY_ID", -1);
        }

        // 2. Khởi tạo Controller và List
        chapterList = new ArrayList<>();
        if (getContext() != null) {
            chapterController = new ChapterController(getContext());
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // 1. Liên kết với layout XML (fragment_chapter_list)
        View view = inflater.inflate(R.layout.fragment_chapter_list, container, false);

        // 2. Khởi tạo Views (Sử dụng các ID đã thống nhất trong layout)
        recyclerView = view.findViewById(R.id.recycler_chapters); // ID từ layout bạn cung cấp
        tvNoChapters = view.findViewById(R.id.tv_no_chapters);
        progressBar = view.findViewById(R.id.progress_bar_chapters);

        // 3. Thiết lập RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Khởi tạo Adapter
        chapterAdapter = new ChapterAdapter(chapterList, getContext());
        recyclerView.setAdapter(chapterAdapter);

        // 4. Tải dữ liệu
        loadChapters();

        return view;
    }

    /**
     * Tải danh sách chương từ ChapterController và cập nhật RecyclerView.
     */
    private void loadChapters() {
        if (storyId == -1 || chapterController == null) {
            tvNoChapters.setText("Lỗi: Không tìm thấy ID truyện hoặc Controller.");
            tvNoChapters.setVisibility(View.VISIBLE);
            return;
        }

        // Bắt đầu tải, hiển thị ProgressBar
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        tvNoChapters.setVisibility(View.GONE);

        // Lấy dữ liệu (Thao tác DB nên cân nhắc dùng Thread/Coroutines)
        List<Chapter> newChapters = chapterController.getChaptersByStory(storyId);

        // Kết thúc tải, ẩn ProgressBar
        progressBar.setVisibility(View.GONE);

        if (newChapters != null && !newChapters.isEmpty()) {
            // Có dữ liệu
            chapterList.clear();
            chapterList.addAll(newChapters);
            chapterAdapter.notifyDataSetChanged();
            recyclerView.setVisibility(View.VISIBLE);
        } else {
            // Không có chương nào
            tvNoChapters.setText("Truyện chưa có chương nào được đăng tải.");
            tvNoChapters.setVisibility(View.VISIBLE);
        }
    }
}