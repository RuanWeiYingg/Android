package com.example.doctruyenver2app.Model;

public class Comment {
    private int id;
    private int storyId;
    private int userId;
    // THÊM: chapterId
    private int chapterId;
    private String content;
    private String createdAt;

    public Comment() {}

    // Constructor đầy đủ
    public Comment(int id, int storyId, int userId, int chapterId, String content, String createdAt) {
        this.id = id;
        this.storyId = storyId;
        this.userId = userId;
        this.chapterId = chapterId; // THÊM
        this.content = content;
        this.createdAt = createdAt;
    }

    // Constructor không có id (dùng khi thêm mới)
    public Comment(int storyId, int userId, int chapterId, String content, String createdAt) {
        this.storyId = storyId;
        this.userId = userId;
        this.chapterId = chapterId; // THÊM
        this.content = content;
        this.createdAt = createdAt;
    }

    // Getter & Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStoryId() {
        return storyId;
    }

    public void setStoryId(int storyId) {
        this.storyId = storyId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    // GETTER & SETTER cho chapterId
    public int getChapterId() {
        return chapterId;
    }

    public void setChapterId(int chapterId) {
        this.chapterId = chapterId;
    }
    // END GETTER & SETTER cho chapterId

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}